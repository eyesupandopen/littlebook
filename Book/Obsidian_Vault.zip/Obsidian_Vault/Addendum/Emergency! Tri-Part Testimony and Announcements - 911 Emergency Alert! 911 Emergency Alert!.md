---
Order: "103"
Date: 2025-09-11
Image: "[[emergency-tri-part-testimony-and-announcements.webp]]"
---
# Emergency! Tri-Part Testimony and Announcements: 911 Emergency Alert! 911 Emergency Alert!
![[emergency-tri-part-testimony-and-announcements.webp]]
[[Addendum]] | September 11, 2025

**Judgment On Secret Babylon/America/United States**

### Behold! Judgment On Secret Babylon: Charges and Prophetic Declarations Given Before Judgment Falls
(Given June 26, 2025)

>**Amos 2:4-8**  
Thus saith the Lord, For three transgressions of Judah, and for four, I will not turn to it, because they have cast away the Law of the Lord, and have not kept his commandments, and their lies caused them to err after the which their fathers have walked. Therefore will I send a fire upon Judah, and it shall devour the palaces of Jerusalem.
>
Thus saith the Lord, For three transgressions of Israel, and for four, I will not turn to it, because they sold the righteous for silver, and the poor for shoes. They gape over the head of the poor, in the dust of the earth, and pervert the ways of the meek: and a man and his father will go in to a maid, to dishonor mine holy Name. And they lie down upon clothes laid to pledge by every altar: and they drink the wine of the condemned in the house of their God.
>
**Amos 3:7-8**  
Surely the Lord God will do nothing, but he reveals his secret unto his servants the Prophets. The lion hath roared: who will not be afraid? the Lord God has spoken, who can but prophesy?

#### Preamble
This document is a declarative judgment on Secret Babylon issued on June 26, 2025, as commanded by Yeshua HaMashiach and YHVH. These judgments are drawn from The Little Book of Revelation Chapter 10, which is also The Everlasting Gospel of Revelation chapter 14; revealed from March 2, 2024, to March 20, 2025. They are given by Yeshua HaMashiach and YHVH through the Spirit of Prophecy. The declarations serve as a warning for repentance before the full judgment falls, and they also function as a guide for events that will imminently occur.

Be it know, that in this capacity, I function as a judicial agent and messenger sent from the throne of Yahweh himself, under authority of Christ Jesus, who is also Yeshua HaMashiach, whom I serve. I am who and what the Lord has made me, and I am his Biblaridion, his little book, even the messenger described by the message that is bitter sweet and in my hand is an open little book. Selah. I do not come under my own authority or volition, and I have not self deployed, but I am sent with the Words the Lord has sown into my Spirit by his mighty hand to be released at his will and beckon call to be read and declared to both the Church, and also to Israel, but also to this sin filled and judged and dying world and especially to be given into the bosoms of the fallen ones for their times have come. Selah!

#### Key Declaration given by Yeshua HaMashiach, who is also Christ Jesus
(Given June 26, 2025)

Hear, Hear one and all and bow your eyes, ears, and hearts in obedience to the Words of Adonai-YHVH, and Yeshua HaMashiach, who is also Christ Jesus. Hear my Words! Following are direct declarations concerning Secret Babylon, identified as the United States of America, and the unfolding of end-time events from both Yeshua HaMashiach, and especially Yahweh The Great I AM, for Strong is Adonai YHVH who judges the great harlot and her judgment has come!

Be it known, even so, which judgments are sent by way of Yeshua HaMashiach who is also Christ Jesus by the Spirit of Prophecy, given in the heart of my messenger, and servant whom I have commissioned and sent, and even hidden in my quiver for such a time as this, Selah!

Hear my Words my Body, My Church, and even my Bride! Hear my voice and stop yourselves at the sounds of my Words and hear their resonant authority echo into this world, for the earth is the Lords and the fullness thereof! Hear my Words my mighty 144,000 and understand my speech and ready yourselves for the appearing of your Lord, King, High Priest, and Messiah! For you will be taken into the heavens at that approaching trumpet blast, even that same mighty trumpet given into my might hands to sound so suddenly and unexpectedly now, Selah! Therefore, ready yourselves my wise virgins, because I am coming for you, and who is it who can stop me, I SAY WHO!

And you, O' defeated prince, even you who stands in defeated silence for you are a toothless lion. Hear my Words O' you Satans and understand my speech, for I will not be denied my possession and you are powerless and toothless to stop me, therefore, I rebuke you Satan, even the Lord of Lords and King of Kings, for you are allowed to do only what is permitted under my might hand and authority, even given by Adonai-Yahweh himself, therefore, silence yourselves and sit in rebuke at my voice, for you are ever rebellious, and yet you are subdued, defeated, and the times of your judgment has come, and you will not escape! Selah, little prince, Selah.

Behold! I am Yeshua HaMashiach, even the same Lord of Lords and King of Kings, for I am Christ Jesus, even the Lion of The Tribe of Judah who sends these Words by my messenger and servant, and by my messenger and servant have my Words been sent, Selah!

Even Words given by way of the Spirit of Prophecy via my messenger and servant by whom these Words have been sent to declare, even also in the mouths and by the hands of MY Little Flock! Selah.

Behold! A trumpet I hold in hand, given to sound at my command and at my signal a mighty shout!

And the world will go dark as the light of my appearing shines over the earth, for I will not share my glory with another!

Behold, I come! Behold, I come! Behold! I Come! Hear my declarations and hear my speech and tremble O' Secret Babylon. For as my light shatters the thick darkness, for darkness cannot overcome my light nor the lights of the world, who are empowered by Christ Jesus and sent in great authority by the Father of Lights and your times of full redemption have come. Therefore, look to me, Christ Jesus and keep your eyes up and open focused on your Lord Jesus Christ in all readiness and obedience. Arrange your affairs, for it will now be that suddenly on the earth, you are not.

And so I command you my loves, fill your lamps, and trim your wicks and take my fire and light your lamps ablaze to illumine yourselves in my Words, and understand that you are to wait by the wayside, for the Bridegroom does approach for both his Bride, and our guests. Selah.

Selah! My Loves, Selah, my Doves, for I do love you and I am coming and the hour is upon you.

Signed by my mighty hand, and in my own love and given in hand by my Messenger directly from me to the eyes, ears, and hearts of those to whom these Words are sent. Even Words I send to my Church, my Body, and even my Bride, and especially for my 144,000 because the times of your sealing has come, and a new song will I create within you that no man can learn. Selah.

Signed,

*Yeshua HaMashiach*  
*King of Kings, and Lord of Lords.*

#### Key Declaration given by Adonai-YHVH, even The Great I AM
(Given June 26, 2025)

Behold! Hear my Words oh you inhabitants of the earth, even the Words of YHVH the great I AM, and understand my anger and my wrath is upon you oh dwellers of the earth, and if it were not for the sacrifice that I have eternally accepted, once all and forevermore, even that perfect passover offered by the high priest forever after the order of Melchizedek, even that son of man who offered his own sinless blood who is also that lamb of God, surely you would be as Sodom and Gomorrah and your judgment would have been instant and swift and sudden, Selah!

Behold Now! Look! Look and see he whom I send, even he who will now rise in great wrath bringing swift judgment on secret Babylon, even as suddenly on earth the faithful in Christ are not! Even that mighty Son of Man that I have made a life giving spirit and into whose mighty hands I have placed all things for fulfillment and the times of fulfillment have come and are now! Selah.

Nevertheless, judgment must begin at the house of Adonai-YHVH and will fall fully in the wrath of the lamb that will so suddenly now overtake the earth in great shaking and great judgment, even so as my wheat will be threshed and separated from the tares during Jacobs trouble and especially, so to will my wheat be separated eternally and forevermore from that serpent's tares, Selah!

For now are the times of harvest, and the times of harvest are now! Behold! Look! I have already declared and sent my Son, even that Son of Man who is also the Lord of Harvest; even with that mighty trumpet in hand, even as announced and declared previously in the Everlasting Gospel!

And even at that exact and specific moment etched eternally in my everlasting heart (for that moment has always been marked in my own heart which works all things after the counsel of my own will), even in my own heart where I hid the mystery of Yahweh!

Behold the times have come and we approach even that exact intersection where time and season meet, resulting in the faithful in Christ standing newly born into my throne room, clothed in brilliant glory and born again into everlasting lives of never ending reward, joy and glory for their love and faithfulness they have showed to Christ Jesus in their times of testing. Selah!

Therefore, know that the day of the Lord is about to fall hard upon you, oh inhabitants of the earth, even all you who think it but a light thing to reject my peace treaty, even Jesus the Nazarene, who is that lamb of God, even he who intercedes for you to this very second for all of you and so mightily have I accepted his Words of intercession as a sweet savor of sacrifice, wholly acceptable and accepted by YHVH the Great I AM forevermore! Selah!

Or you all would be as Sodom and Gomorrah and you all would be a sealed memory of judgments past, so understand my Love for I AM love and I AM the Father of Lights, and I do save by a mighty hand, even the mighty hand of the lamb of God, who is also the Lion of the Tribe of Judah who does roar in his intercession for those he loves, Amen.

Therefore, be it known, and tell them that the Great I AM is he who has sent these Words by my mighty messenger and servant and by my mighty messenger and servant have my Words been sent!

I AM he who sends my Words, even the Words of the Great I AM, even by way of Christ Jesus who is also Yeshua HaMashiach even by way of the Spirit of Prophecy so that judgment may be fully declared, even before sudden judgment suddenly falls.

So tell them The Great I AM, AM HE WHO sends these Words instead of sudden judgment, even gracious and life giving words for the obedient who will call on the name of Jesus as their Lord, even to their ends, Selah!

I AM Adonai YHVH, and I AM HE who sends these Words given in testimony against you, Oh Secret Babylon, even that great harlot of many states, even those United States that will suddenly fall to double judgment so suddenly now at the command of Christ Jesus who is also Yeshua HaMashiach.

Therefore, kiss the son lest he be angry and you perish from the way. You have no time for debate, except for quick obedience, so quickly Selah and repent, because you have no time!

#### Summary
Be it known, that Secret Babylon is the United States Of America, even that great whore who sits on many waters and is a nation that was made, so the beast from the sea and the beast from the earth could rise from her ashes in their times of revealing. Even an adulterous nation, even a nation of fornication, a nation that is indeed a great harlot claiming herself a righteous follower of Jesus the Nazarene. But in truth is a nation whose builders are free from the true Rock of Foundation, even that great cornerstone of which the faithless stumble, even Jesus the Nazarene who is also Yeshua HaMashiach.

### To The Fallen Ones: Heylel, The Satans, The Watchers, The Fallen Cherubim, The Fallen Seraphim: Now Comes Your Judgment!
(Given July 6, 2025)

>**Isaiah 14:12-15**  
How art you fallen from heaven, O Heylel, son of the morning? and cut down to the ground, which didst cast lots upon the nations?
>
Yet you said in your heart, I will ascend into heaven, and exalt my throne above beside the stars of God: I will sit also upon the mount of the congregation in the sides of the North. I will ascend above the height of the clouds, and I will be like the most high. But you shall be brought down to the grave, to the side of the pit.

#### Key Declarations from William Brooks, even Yeshua HaMashiach's Biblaridion
(Given July 6, 2025)

This document is a declarative judgment on The Fallen Ones collectively, but specifically Heylel, Satan, The Satans, the watchers, the fallen cherubim, the fallen seraphim, even all who have joined the Satans' rebellion: you will utterly burn, over and over again for all eternity, for so has been declared by YHVH the Great I AM, given by command of Christ Jesus, who is also Yeshua HaMashiach; given in an abridged, yet detailed and accurate list of offenses and judgments to be executed and fulfilled fully in their times and the times of fulfillment have come: Behold Judgment Falls! Even declarative judgments to be fully given into the bosoms of the fallen ones in full, even a multitude of times over and for all eternity and forevermore, you have no peace, even all you fallen ones: Selah.

And so I, William Brooks, even Christ Jesus' very own Biblaridion:144, I do give these judgments which are drawn specifically from the Seven Thunders, specifically, which thunderous judgments are to be read directly, and given for all to understand, and so these Words may be fully understood by these fallen entities themselves who have condemned themselves eternally and forevermore in senseless rebellion, of which condemnation they shall not recover, nor overcome!

Hear the Words of Yeshua HaMashiach even whose Words I come to declare, even he who is also Christ Jesus and hear and understand the resonant authority of the Lion of The Tribe of Judah, even whose roar he created in my heart and whose roar emanates from my mouth, even which roaring Lion of The Tribe of Judah I do love, and obediently serve, and do follow even, in all restraint, even of which Lion has placed his thunderous roar within the depths of my being because I am his messenger who comes in great authority, and I do raise my hand and swear that time shall be no more!

Behold! I am who and what the Lord Jesus Christ has made me, even he whom Yeshua HaMashiach raised from his youth, and even hidden in his quiver for such a time as this, Selah!

Behold! A command given in song from the throne of YHVH himself and so it was sung in great faith in times of old: Touch not mine anointed, and do my Prophets no harm! Went the musical cry now preserved in the holy writings.

Yet as it is written: Which of the Prophets have not your fathers persecuted? And they have slain them, which showed before of the coming of that Just, of whom you are now the betrayers and murderers!

For you! O' fallen serpent. You! Even You! Is he who has slain the innocent blood of that Just and righteous and holy Son of Man, even Jesus the Nazarene, that spotless lamb of God given for the full redemption of Adam, and so I declare in the full authority of my Lord, even Christ Jesus: You have failed little prince and your judgment lingers not, even the same judgment whose fingers are extended across your neck and you are held in defeated subjection, you have failed little prince, you have failed: Selah!

And so it is, even the very same messenger and servant who was fractured and split unjustly by your wiles, even blinded from his true self in his youth and who is now recreated, and freed and sent with your eternally binding and everlasting judgments in hand given from the throne of YHVH himself, even declared in full authority in that eternally beautiful face of his Everlasting Lord and savior, even whose face shines eternally as the Son!

You have failed little prince.

So, know and understand and hear my words Heylel, even Heylel: that failed little prince, even the same messenger and servant whom you sought to nullify in fractured shards of resonant light strewn across the crystal sea have been recovered, restored, and recreated as Christ Jesus' Biblaridion:144, even recreated with the same eternal intentions YHVH intended before the foundations of the World, and for his purposes have I been recreated and restored because I am even that mighty messenger described by that thunderous end time message which is governed by the voice and utterance of the Seven Thunders, even which Thunders Yeshua HaMashiach has sown into my Spirit forevermore by the Spirit of Prophecy which has fallen fully on the Lord's Biblaridion:144, even at my Lord's command. Selah!

Therefore, hear these Words one and all and understand their authority and every Word will come to pass exactly as written, even by the eternal hand and power of YHVH the Great I AM, given in the beautiful and shining face of Christ Jesus whom I love and serve in all obedience, even whose Words I carry and announce as commanded, even these Words that are now released from the inner depths of my spirit by command of Christ Jesus who is also Yeshua HaMashiach and the times of the full activation of these seven thunders has come upon this judged and corrupted World so suddenly and unexpectedly now. Selah.

#### Key Declaration from Christ Jesus who is also Yeshua HaMashiach
(Given July 6, 2025)

Hear my Words and understand their authority and understand the power placed in my hands by Adonai-YHVH, O' slithering lying serpent, even the mighty and eternal hands of he whom you pierced, even that same Jesus the Nazarene, who gave myself mightily and willingly into your evil hands of disobedience, even in all love and obedience to Adonai-YHVH the Great I AM, because I am the Lamb of God, even that Son of Man who will utterly crush your head!

Behold! Hear one and hear all that I am, Yeshua HaMashiach, even Christ Jesus who has sent these Words by messenger and servant and by my messenger and servant have my Words been sent, even my servant whom I have raised from his youth, and sanctified in my spirit, and purified and cleansed in much chastisement and purification, and truly have I forged him in my fires of affliction because I am he who sits with billows in hand stoking the flames of purification and I am he who has made his feet as pillars of fire and I am he who has clothed him with a cloud and the rainbow upon his head, and I am he who has put his right foot upon the sea, and his left on the earth, and I am he who causes his face to shine as the Son because I am Lord of Lords and King of Kings and truly has YHVH made me a life giving spirit, Selah!

Truly, truly I am he, who has sewn and crafted the utterances of The Seven Thunders into my Little Book's spirit because he is my Biblaridion:144 into whom these seven thunders that govern that Little Book that I have opened in his hand, which is also that Everlasting Gospel, with which I have called and readied my 144,000, even by these Words that are tuned by my mighty hand to find the eyes, ears, and hearts of all those to whom they are sent, so hear my voice given in the Words of my messenger and servant that I had hidden in my quiver for such a time as this!

Except now, have I lit my arrows sent by my messenger whom I have armed and released from my quiver in full authority and my arrows ring true, because I am he who causes my Biblaridion:144 to cry with a loud voice, as when a lion roars: and as he has cried and seven thunders uttered their thunderous voices against you Heylel, and even all of your fallen ones whose judgment has come and is imminent and none of you can escape my mighty hand! Selah!

Hear my Words Heylel, for I call you by name you defeated and vanquished and slithering serpent and I see your fear because you fear your full judgment more than anything, even that same judgment that lingers not because my hand is on your neck, Heylel, and your times have come!

Selah, little prince, Selah.

And you, Heylel, you are powerless to conceal, nor alter my Words O' great deceiver, because they are released from the heart of my messenger who sees through your lies because he is tuned to the same message in Victory, given fully by the full Spirit of Prophecy and it is impossible for you to seal, conceal, nor distort the thunderous shocks of the voice of The Seven Thunders that resonate from the heaven of the heavens into the deepest chasms of the deepest abyss in all vengeance, and truly there is nowhere in YHVH's presence to the deepest outer edges of nothingness in his creation (For YHVH is even sovereign over that which is yet to be created) where their thunderous voices do not resonate in full authority in these times of fulfillment, and the times of fulfillment are now.

Selah, little prince, Selah.

Judgment falls.

#### Key Declaration from Adonai-YHVH
(Given July 6, 2025)

Hear Hear, one and all the sound of my thunderous voice, even Jehovah-YHVH who is the same who has also saved the wild olive tree by the Works of Christ Jesus, even whose sacrifice have I accepted for all time!

Behold! The Lamb of God which takes away the sins of the world!

Behold! The Lion of The Tribe of Judah sent in righteousness to judge and make war!

Behold! My messenger who has been commissioned and sent and recovered and recreated by Christ Jesus and who is suddenly to be fully changed now at the sound of that mighty trumpet that is given in hand to sound so unexpectedly now, so rest in my Words my children and be at peace and Selah!!

And truly the world has beheld the Lamb of God and a mighty and great multitude has come to salvation by way of the wild olive tree and I have broken off the branches from the wild olive tree who accepted my peace treaty in faith and I have grafted them into the natural olive tree yet to be fully revealed, even the Israel of God, even that mighty Israel of God cleansed and purified by my mighty hand, even the hand of Christ Jesus who loved them and gave himself in sacrifice for the sins of Adam, Selah!

And truly, it is time for them to be gathered under the mighty hand of Christ Jesus at my command even so, because the very season of your redemption is upon you, O' mighty sons of Adonai-YHVH, even that same season that is about to unite in chronological unity with my seasonal kairos, triggered by my rhema and at the sound of that mighty trumpet given in hand now, to call and gather so suddenly even all whom I AM calling into my throne room and about to fully gather into the heaven of heavens at that exact and perfect time etched in my heart before the foundations of the World.

Behold! Your redemption has come, Children of Adonai-YHVH, even all those who have accepted Christ Jesus obediently as your Lord! And that trumpet is so surely about to sound so suddenly now even as promised in my holy writings! Are you listening my children for that shout and mighty trumpet blast given about to sound so unexpectedly now by your Lord and Savior, Christ Jesus?

Or are you listening to the voices of those who peep and mutter, and that Christ Jesus has not commissioned nor sent?

Selah.

Truly, the host of heaven stands at the ready because the command has been given and that last trumpet given in hand by my own hand to Christ Jesus himself who is also Yeshua HaMashiach and he it is who will give my command and my order at that exact perfect time (even which time is already casting its mighty shadow heavily upon my creation causing the fallen ones great fear) because Christ Jesus always does the will of his Father, even Adonai-YHVH: Selah!

Because. I AM the ancient of Days, even He who IS sovereign and even ancient even before days were made, and I AM HE who will eternally and forevermore remain sovereign when days on earth cease to exist, because chronology will eventually cease into an eternal and everlasting season of righteousness that has no end, and that is the hope of all the righteous that I have promised eternally and forevermore, Selah.

And truly, I AM he who will bring it to pass according to my eternal plans and purposes that I have worked after the council of my own will; and even though I AM surrounded by ten thousand times ten thousand of marvelous and perfect beings I have created by my own hand who excel in wisdom and righteousness, and are ever obedient in love to my voice. Because in my love for them I do care for them perfectly and I supply their every need even before there is a need, that I may glorify them and they may glorify me in their love and glorious brightness, for I have clothed them in eternally bright and perfect natures. Selah.

And I AM HE who does send these Words by my messenger and servant whom Christ Jesus has raised from his youth, and kept from great evil in the safety and strength of his mighty hand, and truly that wicked one has touched him not!

Because I AM HE who can literally accomplish all and everything instantly and effortlessly in my might! Yet, I AM also the same Everlasting God of Righteousness who is your creator, and as creator I create beings for my eternal plans and purposes to fulfill my everlasting and eternally righteous will.

Therefore, I AM HE who has created and prepared and commissioned and sent my messenger and servant who has faithfully returned to Yeshua HaMashiach in much chastisement, and repentance, and by his hand are these declarations sent from my throne, to Christ Jesus, into the heart of our mighty messenger and servant who has full judicial and declarative authority given by my hand by way of Christ Jesus even with the utterances of the seven thunders given directly into his heart by way of the Spirit of Prophecy for these Words are sown into his being by my command to be released by order of Yeshua HaMashiach even so that not a Word will be corrupted by the sins and disobedience of those who have abandoned their callings, whose judgments lingers not that will fall fully so suddenly now beginning at the house of God, that will happen so unexpectedly now, Selah!

**So be it known, that these judgments are given to be read on this day, on the profane Gregorian calendar date of September 11, 2025.**

And these Words will find the eyes ears and hearts of all those to whom they are sent, especially the disobedient and vile hearts of the fallen ones whose judgments have come. Even the fallen ones and weak and beggarly elements who follow them and have sworn themselves to follow Heylel. Even Heylel, the same who howled in defeat when he was hurled to the earth by my eternal hand in utter shame and defeat, even the same Heylel who was fully decimated and defeated by the Lamb of God who triumphantly declared as he hung in great victory on that rugged stake with those eternally reverberating Words of: IT IS FINISHED.

And so it is I, Adonai-YHVH, do declare that I AM he who sends these Words by way of Christ Jesus, even given and declared by that mighty messenger of Revelation Chapter 10 that I have sent at the command of Christ Jesus, even he who is described in Revelation Chapter 10 by that message that is sown into his heart given into him fully by the Spirit of Prophecy, and in his hand an open little book. Selah.

### 911 Emergency Alert! 911 Emergency Alert! 911 Emergency Alert! 911 Emergency Alert!
(Given August 31, 2024)

So declares your everlasting Lord! Truly, truly, I have called! Truly, truly, I have cried! Truly, truly, I have mourned! Truly, truly, I have warned! And so the voice of Yeshua HaMashiach has heralded forth the judgments to come in warning to all who had ears to hear and eyes to see and a heart to comprehend. And yet my remnant has heard my voice and made themselves ready for the appearing of their everlasting Lord and savior, who is both the Lamb of God and the Lion of the tribe of Judah, and in righteousness I do come to judge and make war.

Behold! The earth is the Lord's and the fullness thereof, and I, Christ Jesus, do possess the deed to the earth, for it is my inheritance. And I paid the price in my atoning blood, that the earth should not utterly perish in sin and unrighteousness, because Yahweh has preserved his creation so that all who are called and chosen, even all those born of red earth who are called to eternal life, should be born again of incorruptible seed, and they will stand in the throne room of Yahweh as newborns, even those born again into everlasting righteousness into eternity at the appointed time, and the time is now! Though babes they will not be, but powerful and everlasting kings and priests, for so is their inheritance, and in such manner will they serve Yahweh under my rule; for I am the Lord of Lords and King of Kings, and I am your everlasting high priest forevermore after the order of Melchizedek, and my rule has no end.

Hear my voice, and bow your hearts in obedience, and incline your ears to wisdom, and hear the words of your Bridegroom, my Bride! Truly, I am speaking to the faithful, and I ask your hearts in full obedience to my words. For the times of warning are closing and nearly completed, and the birth pangs are nonstop now. For I, Yeshua HaMashiach, am the last Adam and have been made a life-quickening spirit and have been changed forevermore, and after the flesh I am known no more.

Truly, truly, I was fashioned after the likeness of sinful flesh, but in the sinful blood of Adam I have no part nor lot, nor did I ever share in the corruption of corrupted, sinful flesh. I am the last Adam, and as mankind is fashioned after Adam at their natural birth, and as sin and death came through Adam's disobedience, so too shall righteousness and eternal life be created fully within you by me, Christ Jesus, suddenly as I gather the faithful to myself. Of a great truth, I am the last Adam, and I have been made a life-giving spirit, and in righteousness and true holiness will you now be born again into all eternity.

And even though all who have been born of a woman (except the Lamb of God) fully partake of the corruption sowed into the flesh by Satan on account of Adam's disobedience, so too will all who are born again of my incorruptible seed fully partake of righteousness and true holiness. For every last one of you will be re-created perfectly, sinless, and fully righteous as the everlasting and eternal sons of God, of whom I will ordain my kings and priests and of whom I will take to myself my bride in eternal, holy covenant, and evermore will they be with me, never to depart.

Yet, so was the son of God manifested that I might destroy the works of the Devil, for the Devil sins from the beginning. Yahweh himself is my Father, for he has created me for such a purpose, to be the last Adam, even he whom in the likeness the newly created man will be fashioned. So understand that I, Christ Jesus, am the head, and a new man will I re-create you all because you are my body, and you will all serve a vital function for which you all have been created. Understand that even though I took the likeness of sinful flesh, the sins of your fathers did not pass to me through the blood. For Yahweh himself created me in righteousness and true holiness, even that God was manifest in the flesh; for he who has seen me has seen the Father, yet after the flesh I am known no more.

And so I was given for your redemption and rescue. He that has seen me has seen the Father, and my Father and I are one in unity and purpose, except in his throne Yahweh is greater than I, for there is none like the great eternal God! Yet in the womb did I develop in like manner as any man, yet in the womb is no passing of blood from the mother to the child; and so was I sanctified and born sinless as the lamb of God, and so have I given myself as the perfect Passover as the high priest of Yahweh after the everlasting order of Melchizedek for remission of sins for all who choose to accept my offer of everlasting life.

And now I come as the lion of the tribe of Judah because once again I have been rejected by those to whom I turned. And as I was rejected by Israel, even my own to whom I was sent, and as a result turned to the Gentiles, so now the Gentiles have rejected me, and I return now to Israel, even back to my own land of promise, for I will yet save a remnant from Jacob that I may save some of all. And from the throne of David will the earth be ruled from the land of promise, promised long ago by Yahweh, and what Yahweh has promised will be fulfilled to the uttermost! And I am he who is given for the fulfillment of all things.

Behold! The times are now, the times are now, when the new birth will come to full completion and consummation in me, the Lord Jesus Christ, and I will fulfill Yahweh's eternal purposes of old, which he has prepared in times past (even of times so ancient you cannot comprehend at this time) because you have always been hidden away in Yahweh's heart. Nevertheless, the eternal and everlasting purposes of Yahweh are now set to be fulfilled, and the first-fruits harvest is at hand, and the hour is upon you. For the earth has now become as a woman in labor, ready to give birth, and her travail and her labor pains are nonstop now, and her deliverance draws near, and the hour of resurrection and gathering is here.

For suddenly will it happen when I, Christ Jesus, will descend from heaven with a shout, with the voice of the Archangel, and with the trumpet of God, and that last trumpet will sound, and at that sound my appearing will break across the sky in great brilliance (my glory is everlasting brightness), and the world will know there is a God in heaven and the world will understand the day of the Lord is upon them. And so the earth will give birth to all those who have fallen asleep in Christ and have returned to the dust of the earth, and whose spirits returned to God, and whose souls have been in sweet rest since the day they closed their eyes to sleep in red earth. For the old man of red earth will spring forth in newness of life, and the earth shall deliver up at my command those who have fallen asleep in Christ, and you who are alive and remain will be caught up in the clouds with them to meet me in the air. And it will happen suddenly, and you all will be born into everlasting splendor and re-created fully as a newborn creation of which everlasting power and splendor is woven into your pure white garments with which you will suddenly find yourselves clothed, and the times are now.

Woe to the inhabitants of the earth. Woe, woe, much woe to the inhabitants of the earth. Woe to you, natural man, because you have refused my call. 911 emergency alert have I warned, and call, and now the day has come upon you, and you are still ignorantly unaware of your impending destruction. You, natural man, have ignored the voices of those I sent, and I have sent many voices to you, and you have rejected my apostles and prophets and my ambassadors; and even the children did you reject, because in the mouths of babes have I perfected praise, and the little ones have dreamed dreams and been given visions, and they faithfully announce my appearing! And so it will be that sudden destruction will fall and the warnings shall cease. For this is not a warning but a declaration because the times of warning are about to suddenly cease, and in place of warning will fulfillment stand, and sudden destruction will fall suddenly, and you will not escape, oh, inhabitants of the earth who reject your creator.

Natural man, you go from sin to sin in your filthy sinful ways, and although I have showered the earth in my grace and mercy so that you may escape your impending judgment, you instead have chosen to bear your judgment and calamity, and so shall it be. And so now judgment begins with the house of God, and so will it be. Secret Babylon, even that great nation of United States, now stands chained, naked, and destitute and awaits her final destruction.

Because of her sins, fornications, adulteries, abominations, and utter filth and depravity with which she has corrupted the earth, she will now face her destruction. And the great harlot is now given fully into the hands of her enemies, yet the restrainer restrains until there is a restrainer to restrain no more, and suddenly will the restrainer be removed at the great gathering together of my saints! And at which time the restrainer is removed, they will execute their secret attack that they have planned and coordinated for many years now, for so is given into their hands to accomplish, and Secret Babylon will utterly be destroyed in one hour.

And the ten horns will destroy the great harlot because they hate the whore, and they shall make her desolate and naked and will eat her flesh and will burn her with fire. And great shaking will come on the earth, and she will be split, and the waters will cover her coasts, and the waters will cover her heart, and she will be divided asunder. For so it is written: her sins are come up into heaven, and God has remembered her iniquities. Reward her, even as she has rewarded you, and give her double according to her works: and in the cup that she has filled to you, you fill her double. Inasmuch as she glorified herself and lived in pleasure, so much give you to her torment and sorrow: for she says in her heart, I sit being a queen, and am no widow, and shall see no mourning. Therefore, shall her plagues come at one day, death, and sorrow, and famine, and she shall be burnt with fire: for that God which condemns her, is a strong Lord. Then a mighty Angel took up a stone like a great millstone, and cast it into the sea, saying, With such violence shall that great city Babylon be cast, and shall be found no more.

And so will it be that this once great nation, of which I have redeemed many, will now be taken in judgment, even as my Church and my Bride are taken into the heavens, where I have prepared for them a place of safety and refuge where they will receive their inheritance. And never again shall Secret Babylon be, and her greatest city that arrogantly sits as though nothing will ever change will fall completely along with her, never to rise again.

Truly, truly, all of her sinful and disgusting cities will fall, and her towers will tumble, and great fires and destruction will make her roads impassable. Then will the red armies, even the armies of the beast that he has imported for her destruction, be unleashed on what remains, and they will consume her flesh. And so it will be that whosoever calls on the name of the Lord shall be saved. Yet, those that remain are sold into slavery by usury because the leaders of Secret Babylon have betrayed her citizens and have given them as collateral, and payment is now due.

Understand what has happened, my people, and remember my words. The mangy shepherds have worked together for her destruction; the one mangy shepherd who rules in secret puppeteers the old stooge, while the other mangy shepherd who appears persecuted by the old stooge works hand in hand with the mangy shepherd who rules in secret. For they pretend they are enemies at the present time, but they are all from the same mangy flock, fulfilling the dragon's purposes, and so I told my Church, my Body, and even my Bride! And so the mangy shepherds have delivered Secret Babylon into the hands of her enemies, for so they are sent.

They have made the whore naked, for so was given them to accomplish, for even the enemies of Yahweh obey his voice. Understand they have purposely left her military might in foreign lands and given her secrets to the ten horns so they may rule in strength. It is the ten horns who will give their power to the beast, for so is given them to accomplish.

The great whore has fought endless and futile wars designed to wear down her strength. Secret Babylon has by design instigated war with the Bear in order to grind down her strength and might so that she is now left naked and defenseless, and into the red dragon's hands is she now given as spoil. And every facet of her empire that sits on many waters will likewise be given as spoil into their hands. Understand that they are at the ready and will move suddenly to execute in unison their worldwide attack, and on all fronts will they attack in swift destruction, and a very short victory will they have before judgment falls in great wrath on the earth.

Understand that the earth is now ruled by the Dragon, and he is now bound to the earth as he awaits his judgment, and so shall his kingdom be utterly destroyed and punished (for he is no king), and Satan will be bound in punishment with a great chain in the abyss for the appointed time, for a thousand years is so given for a day of rest for the redeemed, and many sabbaths will we have. And so his tentacles stretch and cover the kings of the earth like an octopus wraps its prey, and in the same way a spider weaves its web; so he takes his prey, and all that are taken are preserved for that great lake of fire.

For the spider sits in its lair, and the spider has hidden itself amongst the land of promise. And so are Satan's ways, for Satan's ways are cowardly. He has slithered on his belly and tried to hide himself amongst the garden of Yahweh, but nothing is hidden from Yahweh's sight, and nothing is hidden from my sight, for I am Yeshua HaMashiach, who is the promised seed of the woman. And I will bruise the serpent's head, and an everlasting wound will it be, of which he will never recover.

But so it is that his tares share of his evil nature, and so the spider has woven the world into its web through much evil, and the spider now sits at the ready, for its hour has come. And so the spider now moves with its many legs into position the pieces on the board, so that they are at the ready. It has lured the world into its web, falsely promising a new day; and a revival of their golden age they seek to have, but they never will have their golden age, but a great lake of fire that burns the hottest flames of blue is their inheritance.

And so the spider moves them across its web and positions them at the ready. The spider is the synagogue of Satan, who has invaded my lands of inheritance and promise, and they will be utterly rooted out and destroyed, and no root nor posterity will they have. Yet they will serve the eternal purposes of Yahweh for a short season, for a multitude of multitudes will be saved from destruction during Daniel's seventieth week. All who call on the name of the Lord shall be saved, says the Righteous Lord, even Yeshua HaMashiach, who is Jesus Christ in the English tongue; and in whatever language they call, they will be heard and saved and raised to newness of life, and into my righteous kingdom will they go in everlasting reward and everlasting splendor.

And so it is, the destruction of Secret Babylon is now at hand, and my faithful are to be removed. And I, Christ Jesus, no longer come to the dwellers on the earth in warning because I have warned them thoroughly and in many ways only to be denied on all points; and so it is, for so it is written. However, in spite of Yahweh's foreknowledge, Yahweh still warns those about to be taken in judgment of their impending fate, and in his love he has sent me for their salvation, and many were saved.

But now they have rejected me in favor of their false savior, for they now follow Barabbas, and they have now chosen the Dragon as their god. And so I no longer come to warn natural man but to instruct and prepare my people so that they are at the ready for their departing, because there is no more time. Yahweh, in spite of knowing all of this in eternities past, and in his justice and love, has warned the unrepentant anyway, even knowing that many will not repent at this time, yet a multitude of multitudes will be saved through the refiner's fire of Jacob's trouble. And all who call on the name of the Lord to the end shall be saved!

But many have turned to me, and it is to you, my Bride and my Church and my Body, that I now come to gather and prepare for your departing into the heavens, for now are the times and the times are now. Understand, my children, that this is no longer the world you are used to living in, and the days of old are now past, and the day of the Lord is here. So I counsel and instruct all in my Church, even as many as who will hear my voice to fill their lamps with the oil that I have provided and to trim your wicks as I have instructed, for the day of your redemption has come. Truly, truly, I no longer warn but am here to declare on behalf of Yahweh, the great eternal God, that the times have come; and what Yahweh declares can no man alter, nor change even in the slightest, and all will come to pass as written.

And so, my children, understand the times in which you live because you can no longer live careless lives. Events are already underway and the times are perilous. Hide yourselves, my little ones, from the judgments that are not for you, and understand that even the waters are starting to turn bitter. I ask you, my children, to remain in the safety that I have provided for you and come out from amongst them now and be fully separate so that you do not share in their plagues. These events I speak of are not for you, my children, but are given to wake the last of those who will come to salvation before Yahweh closes the door of the ark at the gathering of my Church at the last trumpet, and very few there are that remain.

So hearken to my voice, my children, and come out, come out, come out from among her. Emergency 911 alert, for the day is at hand. Calamities are already unleashed on the earth, yet I have provided safety and peace for those who await my shout, and the trumpet is about to sound. Therefore, remain in the safety of the havens I have prepared for you, and calamity that is not intended for you will pass over you in the same way the angel of death passed over the children of Israel in Egypt. Except, suddenly on the earth you will no longer be, and in a fallen state will you never be again, for your redemption no longer draws near, but is fully upon you. Therefore, stay at the ready.

I am speaking to the faithful and I ask your hearts in full obedience to my words.

I am known after the flesh no more.

I am the last Adam.

I am a life-giving spirit.

I am Yeshua HaMashiach.

I am Lord of Lords and King of Kings.

I am your everlasting high priest forevermore after the order of Melchizedek.

I am who the Great I AM has sent for the fulfillment of all things.

I have sent these words by my servant, and by my servant have these words been sent.

I counsel all who hear these words to listen fully to my instruction and understand that now is the time and suddenly will fulfillment fully come. I require the full hearts of my faithful, so continue to purify yourselves in my atoning blood and confess your sins to me so that I may fully purify you in my atoning blood. Do not be fooled by your senses, because Secret Babylon is blind and deaf and willingly ignorant of her impending judgment, which is already underway and cannot be stopped. Therefore, share not in her blindness that you suffer not of her plagues, and be separate from among them so you are fully ready for the appearing of your everlasting Lord. Behold, my Bride! The Bridegroom approaches, so keep your lamps filled, wicks trimmed and lit, in earnest expectation of your approaching Lord, for now are the times of gathering, and the times of gathering are now.