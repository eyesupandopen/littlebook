---
Order: "119"
Date: 2026-02-18
Image: "[[a-declaration-of-war.webp]]"
---
# A Declaration of War
![[a-declaration-of-war.webp]]
[[Addendum]] | February 18, 2026

I, Yeshua HaMashiach, by these Words NOW released fully into the earth by full command of Adonai-YHVH in full resonant authority NOW declare WAR on the Nations of the Earth, and all of Heylel Ben Shachar's kingdom and any and all of the fallen ones, and any and all who continue in their ways of rebellion.

Behold! I Yeshua HaMashiach who is also Christ Jesus I NOW declare war as the Lion of The Tribe of Judah on the earth and I declare war specifically on you secret Babylon, even that great harlot who is NOW to fall fully at one hour with the beast never to rise again. Because you are the first strike where I will demonstrate fully my wrath on this harlotry nation and all who traffic and merchandise with her according as their trafficking and merchandising has been in my full wrath, authority, and power and her times of judgment and destruction are NOW.

Behold! I Yeshua HaMashiach prophecy fully against you secret Babylon by these Words of resonant authority given into and released by my command from within my mighty messenger and servant who has been taken into the heavens and crowned by my hand in my full authority, crown, and throne and by my power and might and truly the seven thunders NOW fully resonate and reside within Biblaridion144 given to NOW strike the earth in all righteous judgment and utter condemnation on these United States of AmeruKa because you are a chained nation NOW set for its final judgment and decimation by the hand of Yeshua HaMashiach that is NOW set to fall so suddenly and unexpectedly NOW!

And so by my hands, YES directly by my hands fully into Biblaridion144: I Yeshua HaMashiach have directly sewn and given into Biblaridion144 eternally by direct command of Adonai-YHVH, full command of the seven thunders that have already been activated and launched fully into the earth to be given to strike at command by Biblaridion144 at convergence, for execution in all obedience to The Lion of the Tribe of Judah, who cut him free from the web and canceled all contracts between Biblaridion144 and you all.

Behold! Biblaridion144 is my main agent of judgment and executive wrath, even my left hand, who by extension is the left hand of Adonai-YHVH, fully by Yeshua HaMashiach and therefore, the wrath of Adonai-YHVH and also Yeshua HaMashiach embodied and personified, a living sword and multifaceted weapon created and curated for these exact and appointed purposes with full artistic license by Adonai-YHVH and Yeshua HaMashiach.

Woe to all you fallen ones who attacked my chosen vessel, because especially you will be given into his capable hands without mercy before you are bound violently and without mercy and eternally cast to the flames of punishment, especially you who was once named by Elohim Kokabel but is NOW a nameless and judged worm that is to be given to the flames eternally and your punishment is severe.

Behold! They are the seven thunders, and they are in Biblaridion144 fully, and I am Yeshua HaMashiach who has given him full executive authority in all wrath for a time, times, and half a time x 2. Then eternally and forevermore in guardianship and custodial care of Adonai-YHVH creation that is NOW given fully to Yeshua HaMashiach who is the Lion of The Tribe of Judah who NOW declares full and total war NOW by these Words to be governed exactly by that little book of righteousness and by direct and full command of Yeshua HaMashiach.

I see your fear Heylel Ben Shachar you defeated and foolish little prince, and I see you quake and tremble in the greatest eternal fear that has ever been feared by any being ever in all of Elohim creation.

Tick tock little prince, tick tock...

Open your eyes at my command and give me your ears fully and HEAR my Words and understand my anger and full authority that I command in these Words that NOW resonate fully into the earth in all authority given in full authority by Biblaridion144 who is my mighty messenger and servant who has released into the earth in full authority and force the activated seven thunders and NOW this declaration of war that is NOW given within and released by command of Yeshua HaMashiach by the hands and works of Biblaridion144 in all power and authority!

HEAR HEAR the Words of Adonai-YHVH given by command and in full authority in Yeshua HaMashiach because I am the Lion of The Tribe of Judah!

NOW HEAR my Words and stop your tongues and silence your thoughts at the sounds of my Words, sit in silence and understand my anger that is upon you AmeruKa and your hour has come fully upon you NOW, so that truly truly it will be said Babylon the Great is Fallen is Fallen!

Even so that the world will NOW learn that when Adonai-YHVH speaks in full authority given fully by command of the Lion of The Tribe of Judah who is Yeshua HaMashiach and also Christ Jesus who NOW stands in full resonant authority given by Adonai-YHVH to silence yourselves in all righteous obedience or else fall to eternal judgment because the great judgment is NOW.

Even so that all the world will NOW KNOW that the earth is mine and the fullness thereof, and I will NOW SMITE this harlotry nation off the face of the earth for your disobedience AmeruKa and your days as a harlotry nation are NOW ENDED.

I Yeshua HaMashiach will NOW SMITE the nations in full wrath and authority with the full authority and power and strength of the seven thunders that will NOW be fully unleashed to strike Secret Babylon, for you are AmeruKa the land of the plumed serpent and the days of your slithering are NOW terminated fully at one hour with the beast that will be given so suddenly and unexpectedly NOW at my command and who is there who can stop my mighty power and might or who can stand against my mighty messenger and servant who is a sheathed sword in my left hand that I will NOW unsheathe and unleash my Biblaridion144 to strike at command and even all of my 144,000 at my command and in their orders of purpose because WAR is NOW HERE AND DECLARED INTO ALL THE EARTH NOW!

Woe to you inhabitants of the earth and all you nations!

In my hand a trumpet, a polished trumpet. A trumpet to gather the faithful that is tuned by mighty hands to pull the faithful in Christ Jesus straight from the earth into the heaven of heavens by my power and might alone because I am the Lion of the Tribe of Judah and I will NOW smite the nations fully when those mighty seals are loosed that will unleash fully those seven trumpets and many, many woes, and even many things that are not written by design of Adonai-YHVH will come to pass in full fiery vengeance given fully and without mercy, yet in the wrath of the lamb mercy will be given to all who call on the name of Jesus till their ends and especially for Jacob after the flesh whom I will NOW move to redeem as their kinsman redeemer and protect and save alive by the hands of my 144,000. Selah.

All of you fallen ones and especially you fallen watchers hear and understand the Words of Elohim who is also El Shaddai given to you: YOU HAVE NO PEACE!

HEAR MY WORDS AND UNDERSTAND MY ANGER!

WAR IS NOW!

I YESHUA HAMASHIACH I NOW DECLARE WAR ON THE EARTH, HEYLEL BEN SHACHAR AND ALL OF HIS KINGDOM AND ALL THE NATIONS OF THE EARTH!

WAR IS UPON YOU OH NATIONS OF THE EARTH!

AND BY MY POWER AND MIGHT AND BY THESE WORDS OF RESONANT AUTHORITY I NOW LAUNCH ONE HOUR WITH THE BEAST TO BE FULFILLED EXACTLY AS WRITTEN IN THAT LITTLE BOOK OF RIGHTEOUS JUDGMENTS THAT IS SCRIPTURE TO BE FULFILLED EXACTLY WRITTEN AND COMMANDED BECAUSE WAR HAS NOW COME TO THE EARTH BY COMMAND OF ADONAI-YHVH AND BY FULL FORCE AND AUTHORITY OF THE LION OF THE TRIBE OF JUDAH WHO ALSO HOLDS THE SEVEN THUNDERS FULLY IN ALL AUTHORITY IN MY MIGHTY HANDS AND I WILL NOW STRIKE SECRET BABYLON WITH FULL FORCE AND MIGHT AND IN FULL RESONANT AUTHORITY THAT ALL MAY KNOW TO SILENCE THEIR TONGUES FULLY AT THE SOUNDS OF YESHUA HAMAHSIACH’S WORDS WHO IS SENT BY COMMAND OF ADONAI-YHVH ALONE NOW REVEALED BY THE HANDS OF BIBLARADION144 WHO I HAVE CROWNED IN THE HEAVEN OF HEAVEN NOW IN MY FULL AUTHORTY: NOW HEAR MY WORDS!

Therefore, understand in my hand a trumpet, a mighty trumpet that will NOW sound so suddenly and unexpectedly NOW because the sound of that trumpet will gather the faithful in Christ Jesus, even MY Church and MY Body, and even MY Bride who are my mighty 144,000 even the children of Yeshua HaMashiach for I am Father to you all! And at the sound of that trumpet that is an invitation of eternal love expressed fully in your inheritance that is in my mighty hands for you all to be distributed according as your faithfulness has been you will all appear in the twining of an eye into the heaven of the heavens when a child is born. Selah.

Wherefore understand in my hand a trumpet, a mighty trumpet that will NOW suddenly and unexpectedly sound into the earth that will be devastating in consequence of righteous judgment on the earth. Because this polished trumpet that I hold in hand that is tuned by my hand to rescue the faithful in Christ Jesus mightily is a ALSO MY WAR TRUMPET that when blown will focus in full target and intent the seven thunders fully on secret Babylon who is AmeruKA and that great harlot will NOW violently fall to her double judgment and by the full resonant authority and full force of the seven thunders will NOW crash fully into this great harlotry nation that will NOW be fully burnt off the face of the earth never to rise again.

Understand my Words Secret Babylon, even these United States, because the beast from the sea and the beast from the earth will NOW be released fully by my command to remove all restraint and they will be inhabited by those who rise out of the abyss when it is opened violently and when the ice falls because I bring giants to fulfill my wrath and my wrath will NOW fall hot on you Secret Babylon because your hour has come.

WAR HAS COME!

Hide yourselves my people in all obedience to my voice, hide yourselves and quit your faithless reasonings and silence yourselves at the sound of my Words given in full authority by Biblaridion144 who will be given fully full command and executive authority at convergence, that truly truly, once my 144,000 are taken by my command into eternal covenant, where I will then seal them and write my name into their foreheads and I will then deploy wave after wave at my command alone, but I will especially release Biblaridion144 to fully execute all wrath and judgment on Secret Babylon according to my declarations given in this open little book and each and every declaration will be fully fulfilled with many, many woes and surprises therein that will utterly decimate the fallen ones for their full judgment is to be released NOW at my command!

Behold!

I am Christ Jesus who has saved the wild olive tree, and I will NOW graft fully these faithful branches eternally into the natural olive tree eternally and forever more, even the ISRAEL OF ADONAI-YHVH!

Behold!

I am Yeshua HaMashiach who is The Lion of the Tribe of Judah who will NOW give command so that mighty trumpet sounds at that exact perfect moment where khronos meets Kairos when this season of NOW is ended violently on the inhabitants of the earth and all of Heylel Ben Shachars defeated and worthless and weak and beggarly kingdom that will NOW be violently thrown down without mercy and with full and violent wrath!

Behold! I will NOW gather and release my 144,000 into the earth for full battle and war on the nations, and I do NOW declare that Israel, the very promised land of which I arose and sacrificed myself as the lamb of Adonai-YHVH will NOW stand as a safe zone for my people, who are the scattered tribes of Israel and will NOW be called and gathered to their home in their lands where Enoch the Scribe and Elijah the Tishbite have already prepared for their arrival, and they stand at the ready with the resources I have given them and they are at the ready and will gather from the sea and air all that I will lead them to and save from judgment that is not intended for them and I am NOW removing partial blindness from Israel. Selah.

Behold!

I am Yeshua HaMashiach and I am the Lion of the Tribe of Judah who now stands in full authority, and I do give and make and release in all authority given in my by my Adonai-YHVH this declaration of war exactly as declared and that will be executed according to this open little book that I have opened in my messenger and servants hands who NOW stands in my full authority and by the full authority given by Yeshua HaMashiach into Biblaridion144 are my Words now released and sent.

WAR IS NOW!

Therefore, I do NOW close this declaration in full authority and by my signature given in full authority as I signed myself by Biblaridion144.


Yeshua HaMashiach / Christ Jesus

The Lion of The Tribe of Judah, whose roar has now sounded.