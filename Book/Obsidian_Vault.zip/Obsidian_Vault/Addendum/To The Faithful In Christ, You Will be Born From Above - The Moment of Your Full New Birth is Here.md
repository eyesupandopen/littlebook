---
Order: "108"
Date: 2025-10-11
Image: "[[To The Faithful In Christ, You Will be Born From Above - The Moment of Your Full New Birth is Here]]"
---
# To The Faithful In Christ, You Will be Born From Above - The Moment of Your Full New Birth is Here
![[to-the-faithful-in-christ-you-will-be-born-from-above.webp]]
[[Addendum]] | October 11, 2025

Hear Hear, the Words of Yeshua HaMashiach and bow your hearts to the sound of my Holy Words and understand the times you live my loves, because none of you have ever lived these times, and neither these events that are now lined up for sudden and swift judgment and destruction on Secret Babylon, even these United States, to be released so suddenly and unexpectedly now at the sound of that trumpet blast that is set to sound so suddenly and unexpectedly now. Even at the sound of that mighty shout because the times are here my loves, and these times are upon you even as announced and promised. I will gather you to myself so suddenly and unexpectedly now, to meet me in the air as promised, so I command you: BE READY!

Ready yourselves my Bride, because the hour of your full redemption is charging towards you with full force and expectation is here! Therefore, come fully to Christ Jesus and confess yourselves fully to your Everlasting Lord of Righteousness, that truly truly, I may cleanse you fully from all of your sins and that I may cause you to overcome all things in great victory of this sin filled world, even as I overcame all things of this sin filled world in great victory.

And as these final birth pangs intensify, understand that they are nearing completion, even at that exact moment where this Kairos season of Harpazo will culminate when a holy child is re-birthed alive into the heaven of heavens, even delivered and birthed eternally alive and incorruptible forevermore into the throne room of Adonai-YHVH, even as announced and promised previously by the Words of my mighty messenger and servant, even by whose hands these Words are given and sent in announcement and for the further preparation and readying of my wise virgins, so that you all may be separated from those foolish virgins who mock and ignore my Words, and so that I may connect you fully with your full reward that is prepared in full for you all in my hands, readied for you to be given from me to you in fulfillment of promise of the down payment to the purchased possession.

Nevertheless, one hour with the beast approaches and is here and there are many unholy voices who peep and mutter utter foolishness! Truly, truly, many false voices currently cry loudly, giving false words in the wilderness for those with itching ears. Truly, truly these Jezebels are used to the wilderness like a wild ass in heat inviting to her demonic passersby, and in her season who can pass her by without jumping into these inverted vessels, whose judgment lingers not.

Yet so are these spirits of Jezebel who prophesy lying words of deceit and falsehood, even counterfeit words that so many prefer instead of my pure Words of Righteousness given from the heart of Adonai-YHVH himself, in the face of Christ Jesus, who is also Yeshua HaMashiach! Nevertheless, let this separation stand because it is caused by the sword of my spirit, only do not allow yourselves to fall to the left side of my sword or you will partake in their judgments, having refused to separate yourselves fully at my command!

YOU ARE WARNED FULLY NOW!

Therefore, I command you all, come out from among them my people SO you DO NOT partake of their judgments and I have warned many times over, and over now to come out and separate yourselves fully from Secret Babylon, because the judgment of that great harlot is now set to explode across the earth as one hour with the beast is set to be unleashed with great violence and wrath: Except, only when, and only at that exact perfect time that has been appointed in eternities past by Adonai-YHVH, the Great I AM Himself! Therefore, faint not in your expectations because many of you have become weary in your expectations, although I have commanded you to Be of good cheer, and FAINT NOT!

So I ask this silly question: What Bride sits somber by the wayside as if she's been jilted, even and especially as her Bridegroom approaches?

Yet so it is, many of you who now sit by the wayside long of face and heavy of heart, have taken your single-minded focus away from Christ Jesus onto the words of those who peep and mutter and who do not speak for Yeshua HaMashiach! Even so, because many of you who are closest to me in relationship, and closest in time to your full redemption have become double minded by the false words of lying fools.

Behold! Hear my Words and believe!

Behold! You are to be redeemed and snatched alive from the earth and the times are NOW!

Therefore, ready yourselves, and prepare yourselves fully because you are about to and will absolutely see the shining face of your Everlasting Lord of Righteousness, even He who has purchased you with a priceless and ever redeeming price, even my own sinless and priceless blood and your full redemption is NOW!

Behold! The earth will suddenly go pitch dark on a day you do not expect! And out of that pitch darkness the eternal light of my everlasting glory will break across the darkened skies and the world will know and understand, that Christ Jesus has appeared for his faithful, and it will be undeniable, although, they will spread many foolish lies saying that aliens have arrived and stolen you away. Even lies that will be overthrown in violent and harsh judgment, Selah!

O' that my western minded Bride would allow herself to rejoice in this season of righteous redemption that is upon you!

_(Rejoice my Bride, for your Bridegroom approaches, even as promised and announced!)_

O' that my western minded Bride would allow herself to understand that the season of your full redemption is here, and none of you shall escape this season unredeemed!

_(Rejoice my Bride, for your Bridegroom approaches, even as promised and announced!)_

O' that my western minded Bride would allow herself to understand that there is nothing that can stop what is already underway!

_(Rejoice my Bride, for your Bridegroom approaches, even as promised and announced!)_

O' that my western minded Bride would allow herself to rejoice because the hour of your redemption and full rescue has come for you, if you will yet be obedient to my Words and my voice. Selah.

_(Rejoice my Bride, for your Bridegroom approaches, even as promised and announced!)_

Yet, so many of you foolishly focus on that chronological moment of completion, even robbing yourselves of your full joy in righteous expectation, even allowing Heylel Ben Shachar to steal your righteous expectation by the many false voices and words of those who peep and mutter and proclaim counterfeit words of unrighteousness! Selah.

And this because so many of you prefer the many and polluted and polluting voices given by false prophets sent to defile my wise virgins who still seek to remain amongst the foolish virgins, although I do seek to separate you fully from their lying words given to distract and divide your minds from my clear voice and even my pure Words of your Everlasting Lord of Righteousness, and I do approach to gather you my Bride and our guests so faint not, and trust my Words my Loves and rest in my love for you because my burden is easy and my yoke is light.

Come to me fully my loves, come fully to me without fear and with your full hearts in full expectation and with full open face, holding nothing back. Behold! I see fully the inner recesses of your hearts and minds, and I understand the inner workings of your minds and even your many unrational fears, and so I say to you once again fear not!

And just who is there that you should fear my loves? Of an eternal truth I do hold you all so firmly in the palms of my hands, that there is not one entity in all of the fallen ones kingdom, (no, not even Heylel Ben Shachar himself that great dragon of old), who can even loose my eternal grip ever so slightly with which I protect you fully! Because there are none in all of Adonai-YHVH creation who can pluck you from my mighty hands of eternal power and strength.

Truly, truly, there are none who can stand against you when you remain obedient to your Everlasting Lord of Righteousness, and so I ask you again, who is there you should fear? I SAY WHO!

Understand just who I am, my beloved, because I am the lamb of Adonai-YHVH, even an eternally sinless and spotless lamb without imperfection, spot, nor blemish. And in my strength of will and unbreakable love for you my faithful beloved, I did lay down my life in agonizing sacrifice for your sins, even so, that I would redeem mankind fully from the hand of Heylel Ben Shachar, even that failed little prince. And in his brutish ways, did Heylel Ben Shachar sacrifice the lamb of Adonai-YHVH in his brutish and unwise and lustful hate of all things good. And in so doing Adam was redeemed fully by my sinless blood, and Adonai-YHVH has raised me from the dead, eternally to die no more because it is impossible that death should hold me.

Yet so it is, that I presented myself to Adonai-YHVH as the High Priest forever after the Order of Melchizedek and Adonai-YHVH has so mightily accepted my sacrifice that he has changed Jesus the Nazarene into a life giving spirit who will recreate all of you so suddenly and unexpectedly now at that mighty shout and that mighty trumpet blast is set to sound so suddenly and unexpectedly now!

Where I will recreate you as one new man, where there is neither Judean nor gentile: there is neither bond nor free: there is neither male nor female: for you are all one in Christ Jesus, who is also Yeshua HaMashiach! And since you are Christ Jesus', then are you Abraham's seed, and heirs by promise and righteously freed forevermore from the hands of your enemies in Christ Jesus your eternal Lord, King, High Priest, and Messiah, therefore your redemption is completely, completely, completely complete!

Yes, so total and complete is your redemption that you literally lack nothing and you are all bought with an eternally priceless price! And so I ask, which of you can provide sinless blood to atone for the sins of Adam, who sinned when he was sinless? Yet your Father in heaven, even Adonai-YHVH, the Great I AM has given his only begotten son once, all and forevermore to atone for all sins of mankind!

Therefore, you are brought with a price, so glorify Adonai-YHVH my loves because he has already given command to gather you fully at that exact perfect time, and so I command you: REJOICE!

Yet, so many of you do not understand the magnitude of this event, thinking instead your redemption is the only thing to be accomplished of significance. Yet so it is, that many of you instead focus solely on the culmination of your gathering where you will stand fully redeemed and fully changed forevermore in the heaven of heavens when that trumpet blast sounds, because it is about to sound!

And even as these Words are given as encouragement, the voice of the Hebrews stands in witness against so many of you: For when as concerning the time you ought to be teachers, yet have you need again that we teach you what are the first principles of the word of God: and are become such as have need of milk, and not of strong meat.


So I say it again, exactly as stated so my Words may be established:

And even as these Words are given as encouragement, the voice of the Hebrews stands in witness against so many of you: For when as concerning the time ye ought to be teachers, yet have you need again that we teach you what are the first principles of the word of God: and are become such as have need of milk, and not of strong meat.

So many of you have forgotten the first principles of the oracles of God that you are commanded to hold my Words of promise in mind and focus your sole and full attention on Christ Jesus, who is also Yeshua HaMashiach in singleness of heart and readiness of mind. That you would turn your minds and hearts and hold my Words of promise firmly and fully in your minds and hearts that I have given by my little flock who have heralded and announced and readied my people for this Little Book that is The Everlasting Gospel revealed in part, that I have opened in my messenger and servants hands, even as promised by John the Revelator all these jubilees ago even when the utterances of the seven thunders were sealed and withheld in Revelation chapter 10. Yet, announced again and established as The Everlasting Gospel in Revelation chapter 14. Yet, so many of you whom I love, foolishly reject my Words in favor of your lying theologians, whose lies will be stopped in sudden judgment. Therefore, come out from amongst them and you be separate in all things so you do not share in their judgment.

And this because the utterances of the seven thunders are the exact activation of the events heralded in the Apokalupsis of Jesus Christ, even that mighty concealed book of old: The Revelation of Jesus Christ; that was given purposefully in-part and purposefully incomplete. Even so, that mankind would come to Jesus Christ the Righteous Judge and Intercessor so that I would judge your lives in righteousness, even removing your sins should any become obedient in faith and love to obey the commandments given by my voice.

Therefore, understand that the seven thunders are revealed, and activated, and are now active and cannot be stopped nor hindered in the least. Nor is it possible to unring the thunderous shocks of the utterances of the seven thunders that have proceeded from the throne of Adonai-YHVH, given in the voice of El Shaddai and also by Yeshua HaMashiach who has inherited all things from my Adonai-YHVH's mighty hands that I will share fully with my faithful overcomers.

So understand, that I am The Lion of the Tribe of Judah who now stands for my people! And in righteousness I do come to judge and make war!

But first I will gather my warrior Bride and receive her to myself, even all whom has readied herself for her Bridegroom who does approach, and I do see your lamps ablaze that she has obediently trimmed and filled and lit with my fire by the wayside in righteous expectation as I approach!

So further understand just what this means my loves, because there is no more delay, and I, Christ Jesus, do declare in the person of my mighty messenger and servant, that time shall be no more!

Because my invitation has been heralded across the earth for an entire age of grace now, and many have responded, and many will accordingly be fully redeemed so suddenly and unexpectedly now. And my overcomers will fill fully the vacated orders left open in the heavens by Heylel Ben Shachar and so I will reveal these seven heads who are the seven satans, led by Heylel Ben Shachar. Although, in their judgment they are stripped of all personhood and are simply known as the satans, and these evil seraphim will be bound, and cast to the hottest flames of blue and their punishment is the most severe of all the condemned, who will be given to the flames of punishment, eternally bound for full recompense and fiery judgment for all eternity that they shall never escape, not have a moment's rest.

Nevertheless, I will reveal them since they seek to conceal themselves because they are all pretenders who pretend, and there is not one secret that shall not come to light.

There is **Heylel Ben Shachar**, that great rebellious dragon of old who started war in the heavens and attacked Adam's inheritance causing themselves and a third of their angels who followed their initial rebellion during the times Elohim created the heavens and the earth to fall forevermore to the eternal flames of fiery punishment.

There is **Yequn**: this is the one who led astray all the children of the Holy Angels, and he brought them down onto the dry ground, and led them astray through the daughters of men;

There is **Asbeel**: this one suggested an evil plan to the children of the Holy Angels, and led them astray, so that they corrupted their bodies with the daughters of men;

There is **Gadreel**: this is the one that showed all the deadly blows to the sons of men, and he led astray Eve, And he showed the weapons of death to the children of men, the shield and the breastplate, and the sword for slaughter, and all the weapons of death to the sons of men. And from his hand they have gone out against those who dwell the dry ground from that time and forevermore.

There is **Penemue**; this one showed the sons of men the bitter and the sweet and showed them all the secrets of their wisdom. He taught men the art of writing with ink and paper, and through this many have gone astray, from eternity to eternity, and to this day. For men were not created for this, that they should confirm their faith like this, with pen and ink. For men were created no differently from the Angels, so that they might remain righteous and pure, and death, which destroys everything, would not have touched them; but through this knowledge of theirs they are being destroyed and through this power death consumes them.

There is **Kesbeel**, The names Akae and Biqa are names of holy oaths made by Yahweh which they sought to counterfeit. And this is the task of Kesbeel, the chief of the oath, who showed the oath to the Holy ones when he dwelt on high in glory.

There is **Kasdeyae**; this one showed the sons of men all the evil blows of the spirits and of the demons, and the blows that attack the embryo in the womb so that it miscarries. And the blows that attack the soul: the bite of the serpent.

And so are the names of these original rebellious seraphim, even those who are chief amongst them to this very day, because the beast that is rising has seven heads, and these are the names given initially by Elohim to these created beings who deny their creator and have all become pretenders who pretend.

Yet, in their judgment they have all been reduced to nameless adversaries, and they are denied person hood in their eternal judgment, even of which judgment they are eternally afraid and bound by their own words, oaths, and sins!

And I do see your fear little prince, and your times have come.

Tick, tock, little prince the final seconds are collapsing on you in real time and your judgment lingers not!

Even that same judgment you are so fearful, because you fear your own sins because you understand your own hate although you are consumed therein.

And in your judgment, even you Heylel Ben Shachar! You and all who have joined you by refusing to depart from your rebellion, will be bound and cast to those hottest flames of punishment where each and every sin (no matter how small) will be given into the flames by Elohim so that the same actions are recompensed in your own bosoms in those flames of punishment a multitude of times over, and over again, where your worm will never die. And so it will be, that the second death is conscious and eternal destruction according as your own worthless actions have been, and none of you will ever escape, and Elohim will set the seal, and never again will you come to mind and you will be eternally forgotten in your unending prison of eternal torment.

Tick, tock, little prince, tick, tock.

Time is running out, and you will never have more time, and your judgment lingers not!

Tick, tock, little prince, tick, tock.

Therefore, rejoice all you faithful in Christ for your full redemption has come and you will fill the vacated orders in the heavens that the satans have vacated in their senseless rebellion.

Nevertheless! Behold! A double inheritance will you all have, even all the faithful in Christ Jesus who have overcome all things even as I overcame! And I will share all things that I have inherited from Adonai-YHVH, and I will share all things with my faithful Bride and I will hold nothing back from you, my faithful whom I love dearly!

Understand just what is about to happen my loves, and understand the eternal purpose of my Words of announcement, for I do come to ready you my Loves to be gathered, and changed, and rewarded in eternal inheritance, and you will all take your places in the orders in the heavens that are prepared for the Israel of God and you will all take your places in your assigned tribes, for you all are to be grafted fully into the natural olive tree, even though many of you are branches broken off from the wild olive tree, yet you will be eternally grafted, yea, eternally adopted with full double honor as Sons of Adonai-YHVH and nothing has been created ever in all of Elohim's creation that will compare to the glory and splendor you are about to be clothed in eternal righteous and full glory. Therefore, Look up in full expectation because that trumpet blast is about to sound!

Understand my Loves, that your gathering will be known worldwide on the earth and will serve to inspire great faith in the hearts of Jacob after the flesh, who will have their partial blindness removed from them in great chastisement and love by my two witnesses, even Enoch the Scribe, and Elijah the Tishbite, whom Adonai-YHVH has preserved alive, and even taken and hidden away in the heavens from their own generations. And this because Adonai-YHVH has never left himself without witness, and they will surely preserve the righteous remnant amongst Jacob after the flesh, so that I may preserve them alive to repopulate the earth in my millennial kingdom. Selah.

Prepare yourselves my mighty warrior bride, yea, prepare yourselves because you are my 144,000! Understand just who you are, because you are my warrior bride and there is nothing that has been created that will compare to you my faithful Bride, with whom I will share all things in my eternal inheritance. For one of you will truly chase a thousand and there is nothing and no being who can stand against you, nor hinder you, nor hurt you, nor stop you in the least because truly, truly you will be fully invincible, so much so that you will all be sealed mightily in your foreheads that even that full wrath of Elohim will not touch you not!

Understand that you will rescue alive my mighty remnant from Jacob after the flesh that you will save alive in the wilderness in places prepared beforehand ready to receive and nurture those whom I will save alive as their Kinsman Redeemer! And no force, nor ploy, nor effort, nor any such thing that the enemy would seek to hinder will matter in the least, but all of their efforts will collapse fully on their own heads as the full wrath of Elohim is poured out in full finality of judgment during the wrath of Elohim contained in those seven vials that are soon to be fully released in hand by my seven mighty angels, and they shall not escape!

And there, in the wilderness even hidden away, will Jacob be cared for, and fed, and nurtured fully with The Everlasting Gospel, even of which Gospel your Holy Bibles were only the down payment that was given to keep you all for full redemption reserved for that approaching day that has come upon the entire world now! Truly, truly, Jacob will be fed and cared for and fully prepared for their purposes in my Millennial Kingdom, where truly no evil thing will ever enter.

Ready yourselves my church, my body and even my bride for the full and final hour of your full and final redemption has come!

Ready yourselves my church my body and even my bride because so suddenly and unexpectedly now will you all find yourselves standing fully redeemed in the throne room of Adonai-YHVH himself where I will stand to present the Lights of the World to the Father of Lights, even a moment of excited expectation where Adonai-YHVH is more excited than all of you, and Adonai-YHVH has waited longer than you all combined! Therefore, I command you all to sit in excited expectation in full obedience to my commands, or I will strip rewards from the disobedient!

Therefore, I do command you, wherefore to stand firm and pass your final testing my loves, because even now I still stoke the flames of purification in your lives and I do fold you like metal in the hands of the perfect and righteous smith, because I am the smith who stokes the flames of purification, that truly my mighty and eternal works of salvation can root and strengthen into you fully, therefore, faint not my loves!

I am Yeshua HaMashiach, even Christ Jesus, and I do send these Words of announcement and expectation to my church, my body, and even my bride, so that you may understand that your expected gathering together to your excited Lord in the air is part of a larger plan of salvation, where your departure will happen exactly as announced to happen by my mighty hand and words given by my mighty messenger and servant, who is tuned to these same Words I have sewn into his spirit.

That as these Words are announced and given into this world for the first time ever, that truly their fulfillment begins as soon as they are announced and given into this world. Therefore, now, perhaps you can understand the foolishness of the unwise virgins who do not understand the Words of Adonai-YHVH! Because as these Words are given and spoken into the earth for the first time, their immediate fulfillment begins according to the everlasting will of Adonai-YHVH who works all things after the council of his own will, and who needs no counsellor.

Therefore, understand that while most mistake my messenger and servant's work as pastoral in nature, Biblaridion:144 is in fact an agent of declarative judgment and a chosen vessel to myself yet hidden in plain sight to call the faithful as my Shepherd whom I have commissioned and given full declarative and judicial authority over my church, my body, and even my bride and also Israel because I have placed his right foot on the sea and his left foot on the earth in all authority.

And I am Christ Jesus who is also Yeshua HaMashiach, even he who set apart and preserved my messenger and servant whom I have raised from his youth for my eternal purposes that are to be revealed fully at that mighty Harpazo, where I will rescue the faithful in Christ from one hour with the beast, and change you all eternally and forevermore for Adonai-YHVH's eternal purposes which he has placed in the face of Christ Jesus for full fulfillment within each and every one of you, my faithful, my dearly beloved and longed for!

And, so I give these Words, that perhaps you may understand how foolish many of you appear who are already in the process of being separated and redeemed, and yet who scream foolishly and faithlessly all the while demanding their own schedule of events, that is an impossibility to attain. Therefore, wait in all righteous expectation and peace, knowing full well that your full redemption is already underway and cannot be stopped, unless you apostatize in your impatience. Yet, I am persuaded better of my faithful, because I will redeem you just as promised, and not a Word given by my hand, nor by the hand of Adonai-YHVH, the Great I AM will fall to the ground unfulfilled.

I am Jesus the Christ, even Yeshua the Messiah and I am coming for you my loves, therefore continue to wait, and purify yourselves in all righteous expectation. Fill your minds and hearts with the Words of my Little Book that I have opened in my messenger and servants hands, even so that all of you may feast in great peace and comfort on the Words of The Everlasting Gospel that have been given to keep you in the way, because your full redemption has arrived. If you will only allow yourselves to receive all I have prepared, even given by Adonal-YHVH himself in the face of Jesus Christ in reward for the faithful, who have so faithfully waited in great faith so they will now inherit the promises made to faithful Abraham who is the Father of the just who live by faith.

I am your everlasting Lord of Righteousness, even the Lion of the Tribe of Judah, and I do come to judge and make war. Therefore, prepare yourselves my warriors and prepare yourselves even according to the instructions I have left in this open little book that has been prepared, received, given, and announced by my little flock, and especially by my mighty messenger and servant whom I have separated from the Church for my purposes. Truly, truly, I have hidden him in my quiver for such a times as this, except now have I lit his arrows and his arrows ring true. Because my might messenger and servant is to be changed so suddenly and unexpectedly now because he is an agent of declarative judgment that will command the power contained in the seven thunders that I have sewn into his spirit, even which thunders do roar in him fully, because I have placed the roar and heart of The Lion of the Tribe of Judah into his recreated mind and heart, Selah.

Therefore, understand just who you are my warrior Bride, even my 144,000 because I have placed that same roar and heart into each of you, except I have created it in you uniquely to you, and according as your faithfulness has been. And you are my mighty warriors and nothing has ever been seen on earth, nor in all of Elohim's creation that can compare to what is to be revealed in you and what is to be accomplished by you my loves, only faint not and allow my full redemption to take root in your minds and hearts, even by your obedient patience and love to keep my commandments in all diligence.

Fret not over the date setters, neither fret over fables given by your Jesuit indoctrinators, that somehow there is three days of darkness coming that would actually identify that appointed day, time, and exact moment that was hidden by, yet now revealed in the heavens by the hand of Adonai-YHVH himself, although the disobedient amongst my faithful will not cease to spin their thoughts in futility to figure out what their Father himself has hidden from view. Obey!

Behold! I am coming for you my loves, so stand fast and wait for me in all righteous expectation.

Behold! I am coming for you my loves, therefore, hide yourselves as commanded because the hour of your full redemption is here!

Behold! I am coming for you my loves, so stand fast in all obedience to my Words intended to keep and preserve you by the wayside as you wait in full expectation for my arrival, that is upon you my loves.

Therefore, I command you to depart from all of the cares of this world, knowing, that although you do not see me with your own eyes, I do physically visit and sit with many of you in your own homes because I love you, and I will certainly gather you to myself. Do I surprise you my loves? Do you not understand that the earth is the Lords and the fullness thereof? You are my fullness my Bride, and I am with you always, therefore, focus your hearts fully on me, Christ Jesus and conduct yourselves as if your Lord is standing directly beside you in righteous observation. Because: I am!

Wherefore, ready yourselves, and hide yourselves away in the havens I have prepared for you, because one hour with the beast is now set to fall so suddenly and unexpectedly on the earth now that will utterly decimate Secret Babylon. Therefore, separate yourselves fully, in full expectation because I will snatch you to myself, because that Great Harpazo has come!

Hide yourselves from the unrighteous and those of Secret Babylon who are under judgment, because that judgment is coming for them, my loves. Hide yourselves so you do not partake of judgment that is not for you!

Behold! In my hand a mighty trumpet. A polished trumpet. A specially created trumpet, that is tuned to a special frequency created to find the faithful in Christ.

Behold! The faithful in Christ Jesus, even all those whom I have now tuned to the special frequency of that specially created and finely polished trumpet given in my hand by Adonai-YHVH himself.

Behold! Suddenly on the on earth you are not!

Behold! Judgment Falls! One hour with the beast has arrived! Suddenly in the throne room of heaven you will all stand!

Signed in my Eternally abiding and fiery love!

_Yeshua HaMashiach, The Everlasting Lord of Righteousness!_