---
Order: "110"
Date: 2025-10-30
Image: "[[the-midnight-cry-ready-yourselves.webp]]"
---
# The Midnight Cry - Ready Yourselves!
![[the-midnight-cry-ready-yourselves.webp]]
[[Addendum]] | October 30, 2025

Hear Hear the Words of Adonai-YHVH, and have great faith and comfort in these Words that are given in faithful announcement because the midnight cry has now been given, and announced, and the Bride is prepared and has adorned herself in righteousness given to her in Christ Jesus, and our guests are clean and ready and stationed by the way side.

Behold! I AM Adonai-Yahweh, and I send this midnight cry in the hands of my mighty messenger and servant because I have released these Words from the depths of his spirit, where Yeshua HaMashiach has mightily and supernaturally sewn them forevermore.

Hear my Words, and understand what is to come!

So suddenly and unexpectedly now, you will all be changed and harpazoed into the heaven of heavens where you will be sealed and prepared for your full missions.

Behold! I AM the Great I AM and I do bring and announce the midnight cry because the Father of the Bridegroom has given announcement with trumpet in hand and he has arrived to gather his Bride at that exact and perfect time!

Prepare yourselves for the wedding feast!

The Midnight Cry is now active!!

That trumpet is to sound!

Ready yourselves and run to the wayside!!

Light your lamps now!!

Midnight is approaching!!

Do not leave your posts, nor the havens I have given you so that you may hide yourselves in preparation and that you may run to the wayside where The Bridegroom will snatch away his Bride, and our guests, into the safety of the heavens at command now!

Behold! Understand the excitement of the Father of the Bridegroom, because I AM more excited than any in my creation who expects your arrival, or who expects to arrive into the heavens even re-birthed eternally and forevermore as Sons of the Adonai-Yahweh, even recreated by Christ Jesus so suddenly and unexpectedly now.

I do so completely and utterly love you all my faithful children with a love that burns so deep that I will take all eternity to personally show each of you personally in my love and recompense and eternal love to all of my creation.


Signed with my own name and in my full love given by the hand of my mighty messenger and servant,
*The Father of the Bridegroom, The Great I AM: Adonai-YHVH*



Bow your ears and hearts and open your eyes and reveive fully the Words of Yeshua HaMashiach and prepare yourselves my Church my Body and Even my Bride, prepare and ready yourselves according to my holy Words and writings of the Everlasting Gospel and wait for me my loves for I am coming for you and you will not be disappointed in your expectations. Therefore, receive my reproof and chastisement and be obedient to my Words and warnings for I am coming for you my Loves, and I will never leave the faithful in Christ to the refiners fire, nor to the judgment of sinners that is not for you.

Ready yourselves my Loves, in all obedience and expectation, and immerse yourselves in the Words of the Everlasting Gospel, and hold them in your minds and hearts and understand the treasure of scripture that I have given into the earth to keep you in these times of revealing, even a revealing I started with the many prepared trumpets in my little flock that have sounded faithfully, even which trumpets prepared the way for my messenger and servant who is a chosen vessel unto his Everlasting Lord, even Christ Jesus, who is also Yeshua HaMashiach, even where I do reveal my Words into my set apart vessel who is in agreement and fully committed to the purposes I have commissioned him for, and it is by my command and power that his fingers find the keys even to reveal these holy Words that I have given into him to release into the earth for the first time, even Words that are tuned to find the eyes, ears, and hearts of all those to whom they are sent, Selah.

Therefore, hear the sound of my voice in this holy announcement that is given to draw the faithful to my command, and to tune you all in obedience to the sound of that trumpet, that you may be gathered to me at my command.

Therefore, hear my Words of glorious announcement! Hear and understand my call and invitation! Selah, because the marriage of The Bridegroom to his Bride has come, even as announced and heralded!

Come out from her my people, and obey my warning now before judgment falls!

Behold, the times are now!

Ready yourselves my people: Because the hour of your wedding has been announced and is here and my appearing is set to happen so suddenly and unexpectedly now!

Strengthen yourselves under my atoning blood (for I am the Lamb of God) in all humility in repentance and accept my forgiveness for your sins that I may indeed redeem you fully, and connect you fully with your reward!

Behold! It is established!

The day of your gathering has come my people, therefore ready yourselves in all excited and earnest expectation, because, truly truly, you are a generation who will never taste death even as promised of old, REJOICE!

Therefore, understand just what is about to happen my loves, for your redemption is HERE!

For many of you: It will happen on a day you do not expect and at a time you do not anticipate. Because many of you have refused my call to ready yourselves so suddenly and unexpectedly now, and instead have scheduled and planned your own gathering by the words of Heylel Ben Shachar and instead focus on his words instead of your Everlasting Lord of Righteousness.

Therefore, understand my loves, that no matter the day, time, or hour of my appearing (even if you guess correctly) you are commanded NOW to ready yourselves by the wayside with your lamps filled with MY oil, and your wicks trimmed exactly in the manner that I have instructed you so that you are ready for your approaching Bridegroom!

Because I do come without delay, and my journey to gather my bride is almost complete in full victory!

So why do you grow impatient, allowing yourselves to fall into pride and many temptations, when instead you should place your full undivided focus onto your Everlasting Lord of Righteousness who is coming for you NOW my Loves, only faint not!

Then shall it occur, and suddenly shall it happen in the chaos of the day. The world will go dark just before the brightness of my appearing breaks across the clouds in full radiant glory, because I will not share my glory with another!

Therefore, pitch darkness will immediately precede the brightness of my coming, so fear not the coming storms that rage, neither the shaking earth because the earth wobbles like a drunken man, drenched in sin that demands justice, and JUDGMENT FALLS!

Even the righteous judgments set to fall so suddenly when the faithful in Christ are gathered to me so suddenly in the clouds now, because the command will be given so quickly now and there is no delay!

BE READY!

Therefore, I do continue to tune my church, my body, and even my bride to the frequency of that mighty trumpet so that all the faithful in Christ will understand that shout, and will hear the sweet sound of that mighty trumpet!

And you will feel yourselves pulled upwards in loving peace while you are instantly pulled through the firmament into that great and mighty throne room of YHVH, The Great I AM Himself, even where I will stand to receive you!

Prepare yourselves to be presented to YHVH, The Great I AM, where your Everlasting Lord of Righteousness will present the lights of the world to the Father of Lights!

You will all be cleansed fully from red earth that are your bodies, contained in your coats of skins, and you will instantly be recreated as one new man fashioned after the last Adam, even Christ Jesus who has been made a life-giving spirit.

You will all be suddenly and forevermore changed and you all will find yourselves clothed fully with a bright nature, standing in wonderfully made and perfectly sinless bodies that will forever be powerful in ability, and incorruptible in nature, and mighty in holy abilities according as your faithfulness has been in carrying out the works that I, Christ Jesus, have given you to accomplish in faith to your Everlasting Lord of Righteousness.

Prepare yourselves to stand before your Lord!

Ready yourselves!

For the day of your redemption is at hand!

I come to ready you my loves and I ready you with these Words, an announcement and invitation to the faithful in Christ and also that you may know the deep evil that is present in the lands of Secret Babylon, even AmeruKa: That has contaminated the world in her fornication of filthiness with the kings of the earth with all they merchandise and traffic. Eve which lands are now set to fall suddenly in one hour with the beast that truly, truly have come upon the world in all wrath and righteous judgment! Selah.

I command you to separate yourselves fully from AmeruKa, or you will share in her judgments and there is no respecter of persons, be warned one and all and hear and understand my Words for they are unbending in righteous judgment yet they are life to the meek and peace to the penitent humble.

The hour of your full redemption is upon you and is so very close to you now my people; that to fret and worry over the affairs of this earth is truly a very foolish endeavor that I command you now to cease in faith and instead prepare yourselves because your departing has arrived!

You are about to be changed suddenly and unexpectedly now!

Some will be taken on a day that seems as any other day, thinking there is time. Some will be taken on a day on the earth that will seem a normal day, a day that perhaps will be like any other. As it is, some will naturally sleep, resting their bodies to be suddenly awakened by a mighty shout, and a beautiful trumpet blast. Yet, for many it will be a dark and stormy day because the storms of judgment are prepared fully now for the disobedient and for so many of them it will be a dark day of chaos and political upheaval and civil war will break across the lands.

It WILL be that his head will appear as it were wounded to death, but his deadly wound was healed, and all the world will wonder and follow the beast. And so this deceiver who is Donal John Trump will rise in the lands of promise seemingly from the dead after a false assassination so he can hide himself to rise as a supposed god and this event will fully ignite war from within Secret Babylon, and war from without on Secret Babylon, even AmeruKa, The Land of the Plumed Serpent for they are one and the same and there is no hope of forgiveness for this great harlot in her stubborn rebellion because the hour of her judgment has come!

And at his faked death the beast from the sea will rise in great fury! Even Barack Hussein Obama, because the war against the saints will happen even as the faithful in Christ are departed into the safety of the heavens.

READY YOURSELVES MY BRIDE!

Because the faithful in Christ Jesus are to be snatched away into the safety of the heavens, because my pure and wise virgins (who are my Bride) have readied themselves by the wayside with your lamps filled and your wicks trimmed!

Behold! I see your lights as I draw near!

Behold! Hear my Words my Bride, Your Bridegroom Approaches!

Because my call and announcements are powerful and many, and are tuned by my hand to find the eyes, ears, and hearts of all those to whom these Words are sent, and they do ring into all the earth in resonant authority by my command because who can stop the Words of the Everlasting Gospel of my New Testament of Righteousness!

Because the Little Book of Revelation chapter 10 is accompanied by many mighty and powerful signs, miracles, and wonders, (that the faithless call weather modification) that are done by my mighty hand through these Words spoken into the earth at my command and timed in release by my messenger and servant, that are now decoded, unveiled, and revealed and given in announcement and command for the faithful in Christ Jesus!

Hear the Words of your Bridegroom! I am approaching, hear my call my Bride, the Father has given command!

Behold! The Words are given and announced!

Because the faithful in Christ, even all those who have been obedient to my commands will be gathered by the power of YHVH, even the Great I AM, even the same Great I AM who raised me from the dead. Even this same power given into my hands and born mightily within you, even reserved in down payment that is to be fully paid now, because your times have come!

I am coming to redeem you my Bride, wait for me in faith, I love you greatly and will keep you in the palms of my hands where no being could ever remove you, so rest in my power and might, and in my love and chastisement even, so that I may present you without blemish, spot, nor wrinkle, nor any such thing in full reward as prepared for you and waiting for you, prepared in my hand!

And many in Secret Babylon who are now fully committed to Barabbas lies, while preaching the image of a false martyr in all idolatry of the heart, who love and follow his good words and fair speeches, who are captivated and ensnared by his false peace where they imagine that their delicious and sinful lives will continue where today is as yesterday and tomorrow will be the same as today will scream, howl, and lament that their hope is now taken from them as they fight their countrymen to the death, all the while their full surprise attack is to be fully unleashed, (even as my restrainer is lifted from the earth) and Secret Babylon will fall to a double portion of judgment in one hour as many calamities fall.

Judgment falls! Behold the millstone judgments approach!

Hear me now! Many vast multitudes in AmeruKa are about to fall in eternal judgment, because they ignored the Voice of the Seven Thunders thinking it but a light thing to scoff at the voice of YHVH, the Great I AM, given in the face of Christ Jesus and sent in my messenger and servant now released into the earth and announced by my Little Flock.

Except the sinful and profane have confused the Words of Christ Jesus, even Yeshua HaMashiach and also the voice of YHVH, the Great I AM as an entertainment stream to be tuned out in sin, and mocked with great scoffing. Instead of immediately repenting, you instead ignored the last warnings many of you will ever hear from Christ Jesus and you will be taken into eternal judgment!

Because The Lion of The Tribe Of Judah now stands in full authority and great wrath, and the earth is about to understand by way of one hour with the beast my anger, and the anger of The Everlasting God of Righteousness who has given all things into my hand and my mighty trumpet is tuned fully now and is going to shake the foundations of the earth as the dead in Christ rise to life mightily, even birthed from restful sleep and the faithful in Christ shall not precede the dead in Christ!

The trumpet to awaken them is to sound!

The faithful in Christ will be so suddenly caught up with them to meet me in the clouds as you are pulled mightily, in all peace and love into your eternal inheritance and double restoration of the ages reserved for my faithful Bride, and all who have readied themselves in such fashion in all obedience, love, and humility.

It is going to happen exactly as I say! Then shall it happen and suddenly shall they strike, that those who worship their black cubes will exhaust themselves in slaughter, even a slaughter that is brought about purposefully by great deception. Then from the ashes they will rise. Then shall it happen, even as foretold, that sudden destruction will fall on Secret Babylon: And so it will be, even as declared and written!

Her coasts will be covered, she shall be split along the middle from the gulf to the lakes, great fire will fall and their missiles will be launched, and my mighty Angel will cast a great stone into the sea and Secret Babylons greatest city shall not escape, nor the city of Angels because truly, truly, will her sinful cities burn and be overthrown.

The armies of the beast will be released and they shall hunt every person and will cull multitudes, and they have orders to eliminate all who do not suit their purposes, or who could rise to fight them another day. Hear my Words, my people, even all whom I am calling, and understand the times in which you live. For the world you now know will cease to exist, and in its place many wastelands will remain, even the ashes and ruins of Mystery Babylon, for war has come.

For as I snatch my Bride into the heavens, great calamity will engulf Secret Babylon, and she shall be destroyed in one hour, and in one hour shall she be destroyed, and nothing can change her fate, for Yahweh has so declared. And so that finality will fully arrive when I gather the faithful of my Church to me in the clouds and when their departing shakes the entire world. It will literally shake the earth, and great shaking will consume Secret Babylon, and she will be rent up the middle as my saints depart.

She will be utterly burned with fire from the sky and their missiles will fall. Her skirts will be covered with waters from the east and from the west! For a mighty angel will take up a stone like a great millstone, and cast it into the sea, saying, Thus with violence shall that great city Babylon be thrown down, and shall be found no more at all. For thus is it written and thus shall it be done!

I am Christ Jesus, and I have sent these Words by my messenger and servant and by my messenger and servant have these Words been sent.

I am Christ Jesus, even he who is coming in the clouds, even as promised in my holy writings, even as recorded in scripture.

I am Jesus the Christ, even he who holds that mighty trumpet in hand, and at that exact time a mighty shout, and a musical blast at whose mighty voice the faithful in Christ will be gathered.

I am your Bridegroom, my loves, and I am approaching for my bride because the Father has given command to go and gather my beautiful and faithful bride, and our guests.

I am coming for you my loves, and I will gather all of the faithful in Christ to me at that exact and perfect time given and chosen and decided upon by Yahweh, the Great I AM of whose plan of salvation I obediently follow, and administrate in all authority, because I am one in unity and purpose with The Great I AM, and I do have my own will that I could still go and follow. However, I am also he who always does the will of my Father in all righteous obedience, because I am that son of man!

And so it is. Ready yourselves my Bride, and even all you faithful. Because you have no time, and you are already separated from those who will remain to the refiners fire, and especially from those who will fall to this incoming double judgment, that will fall heavily and eternally on AmeruKa, even the land of the plumed serpent, even that great whore who sits on many waters. Because this land will be fully cleansed in fiery judgment from all that Heylel Ben Shachar has done to defile and pollute, and truly truly, all of his unrighteous ways and all of that brood of vipers who follow him will be removed from the earth in fiery judgment forevermore.

Therefore, prepare and ready yourselves. You have no time. I have commanded you to hide yourselves my people. Not that you would hide yourselves away from an imagined three days of darkness that will not happen and is a Jesuit fable invented to speak contrary to the Words "no man knows the day nor the hour", because for three days to occur before a day and hour that is unknown that time would then be identified by the start of the three days. Even a falsehood and foolish fable that shall not occur!

Wherefore, prepare and ready yourselves my loves, for I am coming for you. And I will not leave you to the judgment of sinners and you all will so suddenly find yourselves standing in the throne room of YHVH, where the host of heaven await your presence in much glory, reward, joy, and everlasting life given fully from Adonai-YHVH, in the face of Jesus Christ, directly into your everlasting bodies of glory that you are about to stand fully redeemed.

Are you ready my Loves?

Because in my hand, a trumpet. A polished trumpet. A glorious trumpet. A special trumpet. A trumpet prepared for the ears of the faithful, that is polished pure and clean. Even a trumpet tuned to the frequency only to be understood by the faithful in Christ, even all those I have tuned to hear and receive its life altering frequencies that will change you all so suddenly and unexpectedly now, and forever changed will you all be, never to corrupt or be altered from this astounding perfection that I will recreate you all so mightily and finally now. And you will marvel eternally and forever more at the mighty new creation you will all be made in great and holy and righteous and creative power forevermore.

Behold! Hear my Words and believe!

Behold! You are to be redeemed and snatched alive from the earth and the times are NOW!

Therefore, ready yourselves, and prepare yourselves fully because you are about to and will absolutely see the shining face of your Everlasting Lord of Righteousness, even He who has purchased you with a priceless and ever redeeming price, even my own sinless and priceless blood and your full redemption is NOW!

Behold! The earth will suddenly go pitch dark on a day you do not expect! And out of that pitch darkness the eternal light of my everlasting glory will break across the darkened skies and the world will know and understand, that Christ Jesus has appeared for his faithful, and it will be undeniable, although, they will spread many foolish lies saying that aliens have arrived and stolen you away. Even lies that will be overthrown in violent and harsh judgment, Selah!

Come to me fully my loves, come fully to me without fear and with your full hearts in full expectation and with full open face, holding nothing back. Behold! I see fully the inner recesses of your hearts and minds, and I understand the inner workings of your minds and even your many irrational fears, and so I say to you once again fear not!

And just who is there that you should fear my loves? Of an eternal truth I do hold you all so firmly in the palms of my hands, that there is not one entity in all of the fallen ones kingdom, (no, not even Heylel Ben Shachar himself that great dragon of old), who can even loose my eternal grip ever so slightly with which I protect you fully! Because there are none in all of Adonai-YHVH creation who can pluck you from my mighty hands of eternal power and strength.

Truly, truly, there are none who can stand against you when you remain obedient to your Everlasting Lord of Righteousness, and so I ask you again, who is there you should fear? I SAY WHO!

Understand just who I am, my beloved, because I am the lamb of Adonai-YHVH, even an eternally sinless and spotless lamb without imperfection, spot, nor blemish. And in my strength of will and unbreakable love for you my faithful beloved, I did lay down my life in agonizing sacrifice for your sins, even so, that I would redeem mankind fully from the hand of Heylel Ben Shachar, even that failed little prince. And in his brutish ways, did Heylel Ben Shachar sacrifice the lamb of Adonai-YHVH in his brutish and unwise and lustful hate of all things good. And in so doing Adam was redeemed fully by my sinless blood, and Adonai-YHVH has raised me from the dead, eternally to die no more because it is impossible that death should hold me.

Yet so it is, that I presented myself to Adonai-YHVH as the High Priest forever after the Order of Melchizedek and Adonai-YHVH has so mightily accepted my sacrifice that he has changed Jesus the Nazarene into a life giving spirit who will recreate all of you so suddenly and unexpectedly now at that mighty shout and that mighty trumpet blast is set to sound so suddenly and unexpectedly now!

Where I will recreate you as one new man, where there is neither Judean nor gentile: there is neither bond nor free: there is neither male nor female: for you are all one in Christ Jesus, who is also Yeshua HaMashiach! And since you are Christ Jesus', then are you Abraham's seed, and heirs by promise and righteously freed forevermore from the hands of your enemies in Christ Jesus your eternal Lord, King, High Priest, and Messiah, therefore your redemption is completely, completely, completely complete!

Yes, so total and complete is your redemption that you literally lack nothing and you are all bought with an eternally priceless price! And so I ask, which of you can provide sinless blood to atone for the sins of Adam, who sinned when he was sinless? Yet your Father in heaven, even Adonai-YHVH, the Great I AM has given his only begotten son once, all and forevermore to atone for all sins of mankind!

Therefore, you are brought with a price, so glorify Adonai-YHVH my loves because he has already given command to gather you fully at that exact perfect time, and so I command you: REJOICE!

Therefore, understand that the seven thunders are revealed, and activated, and are now active and cannot be stopped nor hindered in the least. Nor is it possible to unring the thunderous shocks of the utterances of the seven thunders that have proceeded from the throne of Adonai-YHVH, given in thevoice of El Shaddai and also by Yeshua HaMashiach who has inherited all things from my AdonaiYHVH's mighty hands that I will share fully with my faithful overcomers.

So understand, that I am The Lion of the Tribe of Judah who now stands for my people! And in righteousness I do come to judge and make war!

But first I will gather my warrior Bride and receive her to myself, even all whom has readied herself for her Bridegroom who does approach, and I do see your lamps ablaze that she has obediently trimmed and filled and lit with my fire by the wayside in righteous expectation as I approach!

Understand just what is about to happen my loves, and understand the eternal purpose of my Words of announcement, for I do come to ready you my Loves to be gathered, and changed, and rewarded in eternal inheritance, and you will all take your places in the orders in the heavens that are prepared for the Israel of God and you will all take your places in your assigned tribes, for you all are to be grafted fully into the natural olive tree, even though many of you are branches broken off from the wild olive tree, yet you will be eternally grafted, yea, eternally adopted with full double honor as Sons of AdonaiYHVH and nothing has been created ever in all of Elohim's creation that will compare to the glory and splendor you are about to be clothed in eternal righteous and full glory. Therefore, Look up in full expectation because that trumpet blast is about to sound!

Understand my Loves, that your gathering will be known worldwide on the earth and will serve to inspire great faith in the hearts of Jacob after the flesh, who will have their partial blindness removed from them in great chastisement and love by my two witnesses, even Enoch the Scribe, and Elijah the Tishbite, whom Adonai-YHVH has preserved alive, and even taken and hidden away in the heavens from their own generations. And this because Adonai-YHVH has never left himself without witness, and they will surely preserve the righteous remnant amongst Jacob after the flesh, so that I may preserve them alive to repopulate the earth in my millennial kingdom. Selah.

Prepare yourselves my mighty warrior bride, yea, prepare yourselves because you are my 144,000! Understand just who you are, because you are my warrior bride and there is nothing that has been created that will compare to you my faithful Bride, with whom I will share all things in my eternal inheritance. For one of you will truly chase a thousand and there is nothing and no being who can stand against you, nor hinder you, nor hurt you, nor stop you in the least because truly, truly you will be fully invincible, so much so that you will all be sealed mightily in your foreheads that even that full wrath of Elohim will not touch you not!

Ready yourselves my church my body and even my bride because so suddenly and unexpectedly now will you all find yourselves standing fully redeemed in the throne room of Adonai-YHVH himself where I will stand to present the Lights of the World to the Father of Lights, even a moment of excited expectation where Adonai-YHVH is more excited than all of you, and Adonai-YHVH has waited longer than you all combined! Therefore, I command you all to sit in excited expectation in full obedience to my commands, or I will strip rewards from the disobedient!

Therefore, I do command you, wherefore to stand firm and pass your final testing my loves, because even now I still stoke the flames of purification in your lives and I do fold you like metal in the hands of the perfect and righteous smith, because I am the smith who stokes the flames of purification, that truly my mighty and eternal works of salvation can root and strengthen into you fully, therefore, faint not my loves!

I am Yeshua HaMashiach, even Christ Jesus, and I do send these Words of announcement and expectation to my church, my body, and even my bride, so that you may understand that your expected gathering together to your excited Lord in the air is part of a larger plan of salvation, where your departure will happen exactly as announced to happen by my mighty hand and words given by my mighty messenger and servant, who is tuned to these same Words I have sewn into his spirit.

That as these Words are announced and given into this world for the first time ever, that truly their fulfillment begins as soon as they are announced and given into this world. Therefore, now, perhaps you can understand the foolishness of the unwise virgins who do not understand the Words of AdonaiYHVH! Because as these Words are given and spoken into the earth for the first time, their immediate fulfillment begins according to the everlasting will of Adonai-YHVH who works all things after the council of his own will, and who needs no counsellor.

Therefore, understand that while most mistake my messenger and servant's work as pastoral in nature, Biblaridion:144 is in fact an agent of declarative judgment and a chosen vessel to myself yet hidden in plain sight to call the faithful as my Shepherd whom I have commissioned and given full declarative and judicial authority over my church, my body, and even my bride and also Israel because I have placed his right foot on the sea and his left foot on the earth in all authority.

I am Jesus the Christ, even Yeshua the Messiah and I am coming for you my loves, therefore continue to wait, and purify yourselves in all righteous expectation. Fill your minds and hearts with the Words of my Little Book that I have opened in my messenger and servants hands, even so that all of you may feast in great peace and comfort on the Words of The Everlasting Gospel that have been given to keep you in the way, because your full redemption has arrived. If you will only allow yourselves to receive all I have prepared, even given by Adonal-YHVH himself in the face of Jesus Christ in reward for the faithful, who have so faithfully waited in great faith so they will now inherit the promises made to faithful Abraham who is the Father of the just who live by faith.

Behold! I am coming for you my loves, so stand fast and wait for me in all righteous expectation.

Behold! I am coming for you my loves, therefore, hide yourselves as commanded because the hour of your full redemption is here!

Behold! I am coming for you my loves, so stand fast in all obedience to my Words intended to keep and preserve you by the wayside as you wait in full expectation for my arrival, that is upon you my loves.

Therefore, I command you to depart from all of the cares of this world, knowing, that although you do not see me with your own eyes, I do physically visit and sit with many of you in your own homes because I love you, and I will certainly gather you to myself. Do I surprise you my loves? Do you not understand that the earth is the Lords and the fullness thereof? You are my fullness my Bride, and I am with you always, therefore, focus your hearts fully on me, Christ Jesus and conduct yourselves as if your Lord is standing directly beside you in righteous observation. Because: I am!

Wherefore, ready yourselves, and hide yourselves away in the havens I have prepared for you, because one hour with the beast is now set to fall so suddenly and unexpectedly on the earth now that will utterly decimate Secret Babylon. Therefore, separate yourselves fully, in full expectation because I will snatch you to myself, because that Great Harpazo has come!

Hide yourselves from the unrighteous and those of Secret Babylon who are under judgment, because that judgment is coming for them, my loves. Hide yourselves so you do not partake of judgment that is not for you!

Behold! In my hand a mighty trumpet. A polished trumpet. A specially created trumpet, that is tuned to a special frequency created to find the faithful in Christ.

Behold! The faithful in Christ Jesus, even all those whom I have now tuned to the special frequency of that specially created and finely polished trumpet given in my hand by Adonai-YHVH himself.

Behold! Suddenly on the on earth you are not!

Behold! Judgment Falls! One hour with the beast has arrived! Suddenly in the throne room of heaven you will all stand!

Therefore, ready yourselves as commanded because the Father has suddenly given command to the Bridegroom to gather his Bride... Rejoice!

Set you watch in all diligence and immediately prepare yourselves for the wedding of the Bridegroom to the Bride that has come and the hour of your full redemption is here!Because the Bridegroom has now arrived, and is arrayed in great power, and sits with so many of you, as you rush about your lives in worried expectation. Therefore, cease your worries now my loves because the hour of your redemption has come and is upon you now my loves.


Signed in my Eternally abiding and fiery love!
*Yeshua HaMashiach, The Everlasting Lord of Righteousness!*