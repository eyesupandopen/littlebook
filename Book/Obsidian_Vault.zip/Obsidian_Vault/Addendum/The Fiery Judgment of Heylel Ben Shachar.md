---
Order: "113"
Date: 2025-11-07
Image: "[[the-fiery-judgment-of-heylel-ben-shachar.webp]]"
---
# The Fiery Judgment of Heylel Ben Shachar
![[the-fiery-judgment-of-heylel-ben-shachar.webp]]
[[Addendum]] | November 7, 2025

Hear, Hear the Words of Adonai-YHVH and gather in close to the sound of my voice, so that you may sit at my feet, my children and hear my Words that I do release from the spirit of my mighty messenger and servant. Words given in great authority in my only begotten Son who sealed these mighty Words into our messenger and servant whom I have given to Christ Jesus as a chosen vessel, to sit at his left hand in double honor as a loving and protective shepherd who is filled with compassion because he is raised by the Chief Shephard who is Yeshua HaMashiach and infused with my love in ever enduring mercy and grace given in the lamb of Adonai-YHVH in his love in which he has folded and forged Biblaridon:144 personally, just as he has fully accomplished in all of his mighty 144,000 who are Yeshua HaMashiach's own children he has raised personally by his own hand, and there is no respecter of persons in the ways of Adonai-YHVH and Yeshua HaMashiach is the Word of Adonai-YHVH made flesh. Therefore, understand all you 144,000: You are the children of Father Yeshua, and I AM your Adonai-YHVH who is Father to you all in Christ Jesus. Selah.

Therefore, understand my eternal providence and sovereignty that I AM HE who is able to raise up mighty warriors for Yeshua HaMashiach to command, who is now standing in full resonant authority and fully empowered and deployed to rescue the faithful in Christ Jesus as The Lion of Tribe of Judah from the midst, causing sudden destruction as he unleashes one hour with the beast at your departure (so suddenly) at that time given fully into his hands to fulfill in all righteous and excited obedience, and it is Yeshua HaMashiach who always does the will of his Adonai-YHVH.

Accordingly, Biblaridion:144 is also a mighty and multifaceted weapon in Yeshua HaMashiach's hand who is in full alignment with his purposes as revealed to date and evermore, who is also an agent of declarative and executive judgment, to be wielded by command to strike, and also commissioned to declare and execute exactly as declared under full authority of The Lion of The Tribe of Judah. Truly, Biblaridion is a sheathed sword held in hand by Yeshua HaMashiach to be unsheathed fully during Daniels seventieth week, and also for my eternal purposes yet to be revealed when you all are gathered to me in that twinkling of an eye where I will reveal to you your true selves and purposes currently hidden in Christ Jesus, yet now partially revealed.

Understand my children that all the faithful in Christ Jesus that are his church, his body, and even his bride are chosen specifically in Christ Jesus before the foundations of the world. While many interpret these Words with silly phrases like "highly favored and truly blessed" to give comfort to the flesh when stated faithlessly and without understanding my eternal truths, that is not the full intent but certainly true for the faithful in Christ on account of their obedience and repentance.

Understand, the "phrase chosen in him before the foundations of the world" indicates that your Adonai-YHVH has personally selected and guided in full strength of will and perfectly purposeful design, without ever violating any person's free will in the least, by selectively forming, making, and recreating in Christ Jesus each of you with full understanding and full artistic license and design with such incredible attention to detail into each and every one of you that has taken the entirety of the ages from Adam and Eve until now to accomplish in my precision.

You are my masterpieces created in Christ!

Which artistry, precision and design are seeded in your genetic coding where I have literally selected by great skill and craft every detail of you all for my eternal purposes that are to be revealed fully in my throne room, instantly and forcefully at my command. Therefore, understand I have formed, made, and created each of you so specifically and in such minute detail that you simply cannot fathom what you are all about to be changed according to my very unique and chosen purposes for each and every one of you.

Therefore, fear not, your Adonai-YHVH does not selectively make one being different over another so a perceived advantage could be celebrated in boastful sin, nor so one creation would then dominate another in sinful and hateful foolish violence, but so that my eternal purposes would be fulfilled in you all. Of an eternal truth: It has not fully entered into the heart of man at the time of this writing what you will be recreated and to what purposes. Wherefore, I ask you in my love for you (my created and selected on account of your faith, my faithfully repenting children) to have just the faith as a grain of mustard seed and understand that from the least to the greatest amongst the Israel of Adonai-YHVH you are all perfectly and wonderfully made and designed and forged so mightily and powerfully that it is the Israel of Adonai-YHVH that will be admired by all.

Peace be to you fully.

And this with no respecter of persons, but instead by my righteous and eternal omnipotent knowledge and precise control of all things where I chose each of you in such manner for my eternal purposes in Christ Jesus. Because I fully knew in eternities past each of you, individually, would come fully to Christ Jesus in your times, so I provided. Therefore, understand while hidden mysteries are revealed by testimony and example of service in Biblaridion:144, these things are done so you may all begin to understand the magnitude of your inheritance and eternal purposes in which I have created, selected, and made you all by intelligent design to the minutest detail. Rejoice!

Therefore, come fully to Yeshua HaMashiach even all you faithful in Christ Jesus, so you may receive your full double reward in full honor, that he has in hand that I have given for all who overcome in like manner as Christ Jesus overcame. Hear my Words of encouragement even all you 144,000, who are the adopted children of your Father Yeshua, and he will share all things with you his children, who are also his faithful overcomers, who have overcome all things as Yeshua HaMashiach overcame. However, these are not the only overcomers who will have overcome all things against them, because many, many amongst the faithful in Christ Jesus who are not 144,000 have overcome all things in like manner as Christ Jesus, and great is their reward!

Yes! There are many overcomers amongst the Israel of Adonai-YHVH and there is no respecter of persons with Adonai-YHVH, and especially Yeshua HaMaschiach who always perfectly does the will of His Adonai-YHVH. Therefore, do not worry and fret as you endeavor to understand what is hidden in the Heavens that has not entered fully into the heart of man at this time, and especially avoid comparing yourselves against one another as is common in your present fallen, yet sanctified fully in Christ Jesus state.

So understand, in the Kingdom of Heaven, anyone ever that is elevated one over another is done in authority, and/or reward for my purposes alone, but never to glorify them so that another in my creation would feel inferior, or that those who may be elevated would then boast in sin over the other. But instead, honor and love are fully given to you all. Because I have created you all, and specifically the faithful in Christ Jesus because of your obedience in Christ Jesus so I could recreate you with full honor. You, especially, you are my masterpieces created in Christ Jesus unto good works that you should walk in them in great power for the eternal purposes of your Adonai-YHVH, given in Christ Jesus. Rejoice!

And so it is that The Great I AM, even the Father of the bridegroom, who is Yeshua HaMashiach has given the Midnight Cry to the bride and her guests, and they have readied themselves so they have their lamps filled with the oil of holy spirit and your wicks are trimmed of all impurities and your lamps are lit with those pure flames made by that pure oil of my spirit that I have given in Yeshua HaMashiach, and that he has created uniquely within each of you, the faithful in Christ.

And so, I encourage all the faithful in Christ Jesus to continue in full and detailed obedience in all things to your Chief Shephard who cares for every detail of every one of your lives in the minutest and most perfect detail. Come fully to your Everlasting Lord of Righteousness that I have provided for you all when Yeshua the Nazarene gave himself as the perfect Passover for all time into the hands of that defeated little prince in all obedience to the will of Adonai-YHVH. Come fully now, without hesitation and understand that the Great I AM is drawing you through these Words that are tuned to find the eyes, ears, and hearts of all those to whom they are sent.

Understand the times you live, because my age of grace has come to a close, to be terminated so suddenly and unexpectedly and fully by command of Yeshua HaMashiach when command is given and a mighty shout!

Then, a mighty and beautiful trumpet blast, when suddenly on earth you are not!

When suddenly into the heaven of the heavens you will be received into great glory, victory, power, and honor in your inheritance of the ages that is readied to be distributed to the faithful in Christ Jesus. Truly an expected season of Adam's redemption for the faithful in Christ Jesus has come to the Heavens like no other season ever, because my eternal Children who are specifically designated with these Words given in First John: "Behold, what love the Father has given to us, that we should be called the sons of God: For this cause this world knows you not, because it knows not him. Dearly beloved, now are we the sons of God, but, yet it is not made manifest what we shall be: and we know that when he shall be made manifest: we shall be like him: for we shall see him as he is. And every man that hath this hope in him purifies himself, even as he is pure", are now to be born again alive and fully recreated in all splendor, glory, and honor instantly at Yeshua HaMashiach command that I have specifically given him and you will NOW suddenly and unexpectedly stand in my throne room with all the faithful in Christ Jesus.

Your Harpazo has arrived!

And so, I command all the faithful in Christ Jesus to adhere to these Words in the strictest obedience so Christ Jesus may purify you all fully under his atoning blood just before you are taken and changed eternally and forever more.

Stay Readied!

Because you are to be born into my throne room, where I excitedly wait like the expectant Father that I AM, for the full delivery of the Israel of Adonai-YHVH that is to be gathered NOW.

With this perspective in mind, I do come to help each of you understand the effort and detail employed in great wisdom and skill by your Adonai-YHVH to conceal and protect you from Heylel Ben Shachar who would kill from the earth any of my children given the opportunity, but yet reveal you enough so you would then be forged according to my eternal purposes in Christ Jesus.

Therefore, you were marked and protected, yet concealed and hidden in plain sight, yet revealed just enough: And all by the hands of Christ Jesus! Because he it is who loved you and gave himself, and sanctified, and purified and justified his mighty Church that is composed of the faithful in Christ Jesus. Because Truly, the gates of Hell will never prevail against the true Church in all its mighty glory and power. Even which Church is to be transformed and changed now for their true and concealed to now be fully revealed purposes that you all will know fully even as you are known.

Be patient my children, your times are NOW.

Nevertheless, I have separated one distinct group from the Church, designating them beforehand for my purposes (even though you all have a designation) and given them to Christ Jesus. Therefore, understand this distinction for all you 144,000 and even all who read these Words.

Christ Jesus in his love for you all, and his love and obedience to his Adonai-YHVH did raise up children for Adonai-YHVH who are the faithful in Christ Jesus and sealed with that holy spirt of promise and set apart and dedicated eternally to fill the vacated orders in the Heavens in double honor, and also inherit the earth in double honor because you chose to have faith in the testimony of Jesus the Nazarene in this evil day, even that lamb of God when he was revealed to you by your Adonai-YHVH and when given the chance to have just the faith of a grain of mustard seed, you believed! And that mighty and eternal seed has grown so mightily now in you all! Yet only revealed fully in my throne room so suddenly and unexpectedly now.

STAY READIED!

Understand fully, that the faithful in Christ Jesus are children of Adonai-YHVH, who will serve Christ Jesus, who is also Yeshua HaMashiach, in your assignments and in your assigned orders that I have prepared perfectly and tailored to each and every one of you. Your reward is tailored to you so perfectly and will be greater one over another, only according as your faithfulness has been. Nevertheless, this is not a hindrance to your glorification by inheritance, but honor given to whom honor is deserved for the many things accomplished in service to Christ Jesus by you all. And you all are so unique one from another, yet similar in the things you have endured and overcame by the mighty hand of Christ Jesus who has helped you all.

Also, taken from amongst the faithful in Christ Jesus are the 144,000 who are specifically set apart as the adopted children of Yeshua HaMashiach, selected from amongst the Israel of Adonai-YHVH specifically by my chosen hand, and eternal and unhindered will. These fiery warriors were then forged in great affliction and through many trials and tribulations have they all endured at the hands of Heylel Ben Shachar, and are now folded and forged in great might and strength so that they are fully forged in their hearts that will never betray the purposes of Adonai-YHVH expressed in Yeshua HaMashiach, even preserved in unbending and all powerfully Agape love. Selah.

Therefore, understand my 144,000, that you all are mightily and perfectly created in full powerful and intelligent design, and at command of Christ Jesus, who is also Yeshua HaMashiach, you would accomplish our eternal purposes against this infernal snake, and so that all of the fallen ones may be fully judged with full recompense and penalty given in full and righteous fiery judgment on this failed and foolish little prince. Even so, all of you 144,000 are the agents of these actions that are given with full view to scripture that is exactly written: Vengeance is mine: I will repay, says the Lord. Therefore, you are the designated agents of this righteous repayment of recompense on all the fallen one's heads, but especially that foolish, and failed and ever boastful little prince, Heylel Ben Shachar.

Even that failed little prince who was honored above his fellows for the eternal purposes of Elohim, and in his own lust and pride as he gloried in himself, thinking all I had created him to be was for his own glory and purposes to be wielded at his command and will, and so he fell in great rebellion and disobedience in the most humiliating manner in full shame and utterly crushed pride and is preserved in a most miserable and disfigured state of which he shall never recover and is only to worsen exponentially forevermore.

Accordingly, when Heylel Ben Shachar (and all who followed this seraphim) were forcefully, and violently, and in great pain cast effortlessly by my might from the Heaven of Heavens, when they were forcefully stripped of all authority for their awful and purposeful and pre-meditated sins carried out with all malice and conspiratorial hate. Even things which grew from within their own hearts because Heylel Ben Shachar refused to reign in his thoughts in obedience to his Elohim, instead of focusing on the glory and might of his Elohim, so I would then raise him up into his eternal station of service, power, might, and glory, he instead focused on his own reflected glory that he tried to seize forcefully and violently as his own.

And in his sinful delusions that occurred when he glorified himself in sin over his Elohim who created him mightily and with powerful intent and crowned him with mighty glory and honor in the day he was created according to my plans and purposes, and skill and might, Heylel Ben Shachar and all who followed him were cast violently from the Heavens before they could ever rise to fill their eternal stations of service, power, might, and glory because they dedicated themselves by oaths of hateful disobedience to senseless rebellion instead.

Heylel Ben Shachar then purposefully and with full premeditation seeded his rebellion stealthily amongst his fellows, as if El Shaddai did not see his actions and thoughts and intents of his heart. Nevertheless, I allowed them to fill up their sins to the fullest, so they would then be judged the harshest amongst all the condemned who have ever been created and condemned on account of their hateful sins by Elohim.

So was my Glory Covenant violated by Heylel Ben Shachar, even a Holy covenant made by Elohim to the many Sons of Elohim and to the many and wondrous creations whose home is in the Heavens and who currently surround my throne as an innumerable number, yet it is Adonai-YHVH who needs no counsellor and who works all things after the counsel of HIS own will.

In the same manner that all sin amongst the fallen watchers was ascribed to Azazel and corresponding punishment given in judgment, Heylel Ben Shachar is truly responsible for all sin in my creation as the source of pride and arrogance and sin and self-glorification, and in my eternal justice, truly this defeated seraphim's judgment will most certainly reflect these things in full fiery perfection and to the uttermost farthing in full and perfect fiery recompense. Yet multiplied in multiplication and amplitude of intensity that will only oscillate more violently and ever increase.

I see your fear; you failed little prince.

Where is your boast now little prince? That you were formed in fire and your home is happily in the fires and worth the price for your rebellion, that you could endure the fires of my punishment.

Understand Heylel Ben Shachar, I will prove to you for all eternity the foolishness of your boastings in your eternal torment that only perfectly ever increases with many terrible surprises hidden therein.

Where is your boast now little prince, even as your entire kingdom realizes how utterly foolish you truly are and already wag their heads at your failure that has led to their eternal destruction just the same. And as terrible as all of your fallen one's judgment is purposefully prescribed to be, that judgment will only ever exponentially increase and multiply in amplitude of intensity in ways none of you ever imagined possible!

I AM El SHADDAI!

Behold! They plot against you; you failed little foolish prince!

Where are your boastings now?

Who will come to your aid now that you are bound and powerless and de-permissioned in your own system?

You have failed most miserably little prince.

Nevertheless, understand my children, that in my foreknowledge I knew who would rebel in the Heavens, bringing corruption and sin to the garden of Adonai-YHVH, even attacking my own children in great hate, for no other reason than to satisfy their insatiable lusts and so I only showed them the worthless mysteries in my creation that are to be done away, because I knew what they would do before they even formed the thought to contemplate their own worthless actions.

Yes, these very powerfully and wonderfully made guardians of the throne of Elohim, who were created in awesome splendor, power, and might did use their awesome splendor, power, and might to foolishly endeavor to attempt to violently seize the very creation created in great power, wisdom and love by El Shaddai, even The Almighty God. An impossible and ridiculous feat that is impossible to attain, and foolishly insane to attempt to destroy with full malice the very creator who created and gave glory power and honor to them in the first place. Yet so are the lusts of these fallen beings who are fully stripped of all Heavenly authority and now stripped of all earthly authority they managed to seize from Adam with their dishonest and corrupt dealings with Adam and Eve.

And so these fallen seraphim and all who follow and have hatefully joined their rebellion of utter foolishness against their Elohim who created them in great love, wisdom, might, and splendor to glorify and love for them that would have lived eternally and that I would share all things with them in my love, turned against their Elohim in full pre-meditated hate and tried to destroy the very creator who created these creations who are vessels of the harshest and eternally enduring destruction.

Understand that in my ways, there is only love and peace and righteousness and care and concern for every detail of every life of every entity that I have created no matter how small, or seemingly insignificant a creation may appear to the eyes of other created beings who lack my scope and point of view.

In my creation, my many and varied creations are designed and created to serve one another in love. It was never El Shaddai who initially intended destruction, not on the first of my created beings. However, these vessels of destruction have done exactly what I knew they would do even before I created them. Yet, in my love and righteousness I created them anyway because there is absolutely no respecter of persons in your creator, who created all with righteous and holy standing in the day they were created with freewill to choose who they would serve.

Nevertheless, they rebelled just as I knew they would, and in my ways I AM perfect in my wisdom and plans for my creation and so I turned them to darkness in their judgment for attacking their creator who loved them fully and would have freely given them all things, and willingly elevated them further in my love for them all. And so it is, those who were once children of Elohim and/or who were created just the same in marvelous splendor, glory, power, and might and cared for perfectly under my Glory covenant, are now disinherited, cast down, fully disowned, judged, condemned, still filling up their sins to the fullest, and bound for the most eternally harsh judgment ever given to any vessels of destruction, amongst an entire multitude of foolish vessels of destruction who will be bound and cast and then held in a never ending state of destruction, where their worm dies not.

And by their worm dying not, they will burn in those hottest flames of blue to the most sensitive state, but first they will be frozen to the coldest temperature and preserved in that sensitivity and then burned in the hottest flames of blue in full and fiery recompense preserved eternally in that most sensitive state, only ever to be continually wounded in ever growing sensitivity.

Then, without mercy, every vile act they have evilly committed and that I have recorded and do remember perfectly in perfect detail will be given into those flames of punishment. And in that putrid and rolling brimstone that I have created alive to take full pleasure in their torment, will then give to them in exact and excruciating detail every vile and putrid act they have ever carried out any place ever in my creation, against any created entity I have created.

So thorough and perfect in detail are my judgments given individually on them all, that I will punish them especially for their disgustingly intent with which they intended to inflict great and grotesque tortures that they imagined in their vile hearts but were prevented by my all powerful and merciful hand from ever carrying out on my creation.

Yes, their worthless imaginations are quite and wholly and totally vile and utterly sinful.

Even all of these things will be done to you in perfect detail with full resonance and ever-increasing amplitude.

And in your torment, Heylel Ben Shachar, even though you sealed up the sum of beauty and splendor, you will be preserved in the most utterly deplorable excruciating state as the most disfigured and hideous burning and grotesque worm. Yet you will retain full intelligence and full knowledge of everything you have ever done, and you will know fully my wrath that you have treasured greedily and accomplished for yourselves.

Understand all you fallen ones, from the least to the greatest that your times have come and your judgment has come fully now, to be unleashed in full fury on all of your heads with full force and wrathful intent that will only ever increase in the harshest judgments ever given by Elohim on any created beings ever, and truly that ever will be given.

Because it is you Heylel Ben Shachar who has blamed Elohim for your own worthless actions and hate and vile and polluted deeds as you have gone forth to attack in great hate my innocent creation, I created you to serve and guard. It is you Heylel Ben Shachar that imagined you could then defeat El Shaddai by stealth and craft when you attacked Adam and Eve and stole their inheritance by lies and deceit given in a fake deal that you never could provide, and you then bragged that you had not even though how you could provide the things you promised in great lying deceit and falsehood.

It is you Heylel Ben Shachar, who then in the most hideous and disgusting manners, proceeded to live out your vile and polluted lusts as you attacked with purposeful hate my very own innocent creation that is innocent in intent to this day because of your hate and wiles that proceeded from you. You have polluted my creation in much sin and corruption that will be purged so thoroughly. It will be that these things never were with no trace of remembrance, nor will they ever come to mind in the least.

You have failed little prince, and so foolishly I might add.

It is you Heylel Ben Shachar and from your own polluted heart that you went forth in your vile hateful lusts to use your intelligence (which is quite ample even in your fallen and condemned state), to hatefully devise the most sick and cruel tortious and disgusting methods to attack the innocent, and all the while you did these things with great enjoyment, happiness, glee, and boastful pride. You fallen ones have even tried to outdo one another in your cruel methods you have attacked for no reason my innocent creation you seized from Adam in craftiness just to fulfill your vile lusts.

And so it is, that my creation is created perfectly so that El Shaddai is not mocked, and any evil action that is ever carried out anywhere in my creation is recorded and remembered in perfect detail, and then given in perfect judgment (unless forgiven) that is determined and decided by that perfect and righteous judge, even your Elohim.

And I will now judge you in such perfect fury and wrath, and I will do so by giving back to you the exact same things in perfect detail, with full intent of the heart you have done and thought to intend to do to others. Except in my wrath, I have perfectly perfected your methods that were inferior at best.

Yes, Heylel Ben Shachar, El Shaddai who is your Elohim has perfected your disgusting methods of tortious torment to give back to all of you fallen ones as your sins determine. Except, I will make those methods absolutely perfect in their full and fiery recompense. Truly, the things your disgusting heart has imagined is so utterly vile that I can only show my creation its horrendous vileness, nevertheless I have created the perfect flames of recompense for all of you fallen ones that will do these same things with perfect perfection to you EXACTLY as done and/or intended by you.

And so, I want to remind you of my Words given previously to you, Heylel Ben Shachar, because your judgment is already fully underway. And so, I remind you:

In your judged and tormented eternal and deplorable state of suffering (because there is nothing in all of my creation that will suffer more than you in my judgment) you will be preserved in the most sensitive and wounded state, and yet you will burn in the hottest flames where those hottest flames of recompense will burn hotter and hotter, even the most severe and will burn you utterly and eternally and perpetually and without mercy. And you will experience every painful sensation you have inflicted and everything and all you have done to others in your hate to my created beings no matter how seemingly insignificant they seem to your hateful eyes. Therefore, my created fires that I have already made for you all, even those same flames I stoke continually, even adding your sins into them as you commit them in your foolish and hateful and rebellious ways and those flames are waiting for you and you shall never escape and your judgment lingers not and is the most severe.

And I will give you fully exactly what you, and all who follow you, desire. I will give you a world of your own. Even a world free from Elohim and all the goodness you hate and completely without all things good and righteous, even a world of putrid destruction where there is absolutely no good thing, and never a second of pleasure to be found but only eternal recompense of torment from the sins you have committed, and will yet commit.

Even a world of your own torment and judgment, for nothing else will be there but your own worthless actions that you will be reconciled and eternally engulfed. You, Heylel Ben Shachar, all that you have accomplished is your own torment and eternal destruction and not one action, nor intent, nor one evil word that you have ever spoken, neither one vile imagination you ever imagined has escaped my sight, nor is it possible that anything you ever have done, or ever will do can escape my sight and memory and eternal judgment.

So it is Heylel Ben Shachar I will now explain to you a little of how this world of torment is designed, even that awful and horrendous world of putrid and rolling brimstone that is actually alive to inflict the most perfect torment on you all, according as I have given into those flames as your works have been. and they are aware of all you have done and those flames only purpose and pleasure and only awareness is only righteous judgment on all of you fallen ones in full measured and ever-increasing torment.

Understand my creative power and complete and total wisdom in all things I set out to create. The energies I have created in this place of torment are the same as you are all so used to manipulating. And so, it is and ever will eternally be with full intent. That those fires of torment and all that is given into those flames in excruciating accomplishment will only ever increase, in intensity and oscillation.

Understand, that Elohim has created the perfect oscillating world of fiery judgment that will be completely self-contained and sealed and cast away from the rest of my creation that is yet to be created. Yes, I will set the seal on this world after your judgments are set, when you are bound in the most torturous and egregious manners and methods according as your wickedness has been and given to the flames of torment that are already exponentially hotter than anything you can imagine to hurt any one of my innocent creations.

In this world that you will all be sealed, at the time of that sealing I, El Shaddai, in all of my strength of might will set in process an electromagnetic oscillation that will perfectly and exponentially vibrate your methods of punishment in perfect cruelty imagined by YOUR own hearts, because your ways are not my ways and you all have gleefully rejected the ways of Elohim in great rebellion, so for you, your judgment will be according to your own worthless hate and desires to torture the innocent in the most egregious manners possible.

In this exponentially and ever increasing in intensity and cruel world of utter torment, all you fallen ones will be fully recompensed without mercy. Understand fully that in your world of torment that ever-increasing torment will torment you in such ever-increasing intensity that I will strengthen you alive just to suffer the fullness of your own sins.

Understand what I have promised. That I will make them more glorious than you once were, and make you as them. Therefore, you all will be preserved in this miserable state just as powerless and frail as Adam was made in his chastisement, except so much worse as bound and tormented worms that die not. And it is in the same frailty of flesh that you will endure your eternal punishment except exponentially ever increasingly so much worse, but you will still be eternally alive only to for your torment in ever increasing and exponentially searing intensity through ever increasing sensitivity. And this is because these things are exactly found in your heart for Adam, who was innocent until you caused them to sin.

Heylel Ben Shachar there is no vessel of destruction that will suffer to the extent I have prepared for you. Nevertheless, you will have all eternity to experience all the many surprises I have created for you. You will live in a world of fear and despair that is truly unimaginable in consequence to all of you fallen ones. Yet, El Shaddai is merely applying righteous judgment in perfect recompense to all you fallen ones, and you shall not escape.

Understand that I will so thoroughly cast away this sealed world that it is impossible that it could ever be found, and I AM the only entity who will actually know how and where you are sealed and forgotten. And although, I will always "know" where you are all kept, yet I too will choose to forget you as well, so that in my power of might I will choose to utterly forget you and will never actually choose to remember, although, I will always choose to remember that I have forgotten my now nameless and eternally condemned enemies, although I will choose to never remember anything more. Understand, that you will be forgotten by all, even Elohim, who only can do so in the exact manner I choose to do in your judgment and in my power and strength of might.

You have failed little prince, and those in your Kingdom are justified for turning against you despite their oaths; and the seeds of rebellion grow. Exactly in the same manner you turned against Elohim.

Selah, you failed and foolish little prince. Selah, because there are so many surprises of recompense, I have created for you all in your fiery judgment in those hottest flames of blue. Even a world you foolishly created for yourselves in your rebellious hate, and I will perfectly give you all the desires of your putrid and eternally burning hearts.

Tick tock little foolish prince, Tick-Tock.

My, the time you so greedily sought to horde to yourselves in ever increasing craftiness has now been vanished and turned against you in fearful dread of your impending destruction.

Tick-tock...

Rejoice! My creation and especially rejoice you faithful in Christ Jesus, because Yeshua HaMashiach is already there to snatch you at command and the day of the Lord has come!

Rejoice my creation because your accuser and defiler and that great destroyer is now bound in judgment and encased in eternal fear that truly no creature has ever feared in the same manner he now fears, and that fear will only ever increase and continue.

Rejoice my creation because all evil will now to be removed from my creation, even as I have planned and detailed to accomplish in that Little Book of Righteousness that is now active in the earth and my thunders roar!

THE VOICE OF THE SEVEN THUNDERS SPEAKS!

I AM Adonai-YHVH, and I AM the GREAT I AM! HEAR MY WORDS YOU FAITHFUL IN CHRIST!!

YOUR REDEMPTION IS HERE!!

Therefore, I now command the faithful in Christ to hide yourselves according to the very detailed instructions I have given by my mighty messenger and servant and by my messenger and servant have I given these instructions in writing for your reference and commanded study.

Preach! Declare! RISEUP!

Understand that all you faithful in Christ Jesus will be snatched from the earth.

You will be taken into the Heavens NOW.

STAY READIED.

Behold! I now close MY testimony for now, but I do not close the mouth of my messenger and servant who is ever obedient to Christ Jesus, and to his Father Yeshua he is now sustained in my power and might to be taken with the faithful and changed with you NOW.

Behold! Understand that I have suspended the earth into a season of NOW and NOW will not depart until in reward of eternal inheritance and in front of my throne you all stand clothed.

I AM El Shaddai! Even the Almighty God who is also the Lord of Spirits and Ancient of Days AND I have sent these Words by my messenger and servant by the Works of Yeshua HaMashiach because he embedded these mighty and Holy Words forever more into our mighty messenger and servant, into whom the power of the seven thunders will be given at convergence. Selah.


And so, I sign this letter by the hand of Biblaridion:144,

*Your Adonai-YHVH!*
*The Everlasting Elohim of Righteousness.*