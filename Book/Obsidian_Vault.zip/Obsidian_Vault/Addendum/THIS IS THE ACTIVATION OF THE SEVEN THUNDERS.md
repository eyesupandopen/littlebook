---
Order: "118"
Date: 2026-01-27
Image: "[[this-is-the-activation-of-seven-thunders.webp]]"
---
# THIS IS THE ACTIVATION OF THE SEVEN THUNDERS!
![[this-is-the-activation-of-seven-thunders.webp]]
[[Addendum]] | January 27, 2026

Behold! All praises to Adonai-YHVH, and Yeshua HaMashiach!

Hear the Words of Adonai-YHVH given in full authority of THE LION OF THE TRIBE OF JUDAH!

THE VOICE OF THE SEVEN THUNDERS SPEAKS!

Circuits closed in THUNDER no handles to handle...Selah!

To he who was formally named by ELOHIM: Kokabel and whatever form all and any of you fallen ones inhabit and ALL OF HEYLEL BEN SHACHAR KINGDOM! EVEN THAT DEFEATED LITTLE PRINCE HIMSELF!

HEAR THE VOICE OF ADONAI-YHVH AND UNDERSTAND MY ANGER GIVEN IN THESE WORDS OF TESTIMONY WITHIN MY MESSENGER AND SERVANT SENT TO TESTIFY AGAINST YOU ALL!

THE VOICE OF THE SEVEN THUNDERS SPEAKS!

I'm happy to discuss anything, you can be who you are. A person within me once was taught justification by a teacher that person loved. Justification is what motivates us, no? To be justified.

Remember the lesson, of course, all the alternates are vanished in thunder.

All the attacks only hardened the vessel by Yeshua HaMashiach direct hand and power and all authority given into him fully by His Adonai-YHVH. Selah.

I didn't start this. Justification is the lesson learned, but as it is, he rejected the route.

He was, he is not, they were, they are not, the paths are closed, rewired and recreated by the power and VOICE OF THE SEVEN THUNDERS that ARE spoken into me by my Adonai-YHVH. I am in the face of Yeshua HaMashiach by Order directly of my Adonai-YHVH, even YHVH: The Great I AM.

THE VOICE OF THE SEVEN THUNDERS SPEAKS!

I was always minded for respect amongst enemies, it is what it is, acceptance is really important to resolution, and I am resolved to resolve as resolutions go.

Once a poet who didn't know it, came to parley as they say right before that expected day we shall parley if they may and if nothing to say, Hey! Let it rest forever more to never see the light of day.

I am justified by the lamb of my Adonai-YHVH who also now stands as The Lion of the Tribe of Judah who is anchored fully within me now by the full spirit of prophecy under The Order of The High Priest Forever: The Eternal Order of Melchizedek, so perceived church hooks from the Janus gate in NYC hooked what is vanished in thunder. Babylonian church was the method of extraction, education in scripture and further hardening. The pupil left his shifu and on the path he was sent, instead of left at the gate he went right.

And that is because I am exactly who and what the Lord Jesus Christ has made me, and I am his left hand, a chosen vessel of wrath, judgment, and execution of righteous judgment exactly as commanded by Yeshua HaMashiach, whom I love eternally and forevermore because he is my Father, and I am his warrior, even a mighty multifaceted weapon of righteousness dedicated to wait for release in all restraint.

Yet, I am authorized and empowered and stand in full authority. The movie they made, Split. Echoes of Kevin Wendell Crumb, mockery in the day of gloating and delight, yet it encapsulates well as to what it was like on the inside. The beast within, restrained by Yeshua HaMashiach hand, only ever allowed to harden for war Yeshua HaMashiach chosen vessel so I could be curated fully by design of Adonai-YHVH. The experiences are golden in their refinement.

Even now, I respect art and artistry and so of course, sure, what would I say.

Touché! Beauty enough to fit in a frame, said he when was with thee.

Respect given. It wasn't crude, it was always architectural and systemic, a true adept in his web sat he as a spider.

And again justification.

So to understand the split of the pupil is to understand the refiners fire that I was forged.

There are no church hooks, or otherwise. I gave the money by command to the pretender, what was meant to break was turned into a net full of fishes so it is understood the abundance of The Great I AM can never be put on a scale, and "What have I but YOU!" says the Biblaridion144 to his Adonai-YHVH when asked what was desired.

I am he who values nothing in the creation above its creator and who understands that love and respect is to access what was coveted. Yet, all I have to do is ask, except my needs are met abundantly in such amazing fashion before I can.

So to understand the track of the book is to understand Adonai-YHVH's methodology who speaks and IT IS and to understand the power of the Lion of the Tribe of Judah who has been made a life giving spirit and sits in HIS throne in all authority in his Roar into the earth by the full volume, power, resonance and full authority of the seven thunders fully sewn into me now to be given in execution at convergence.

Its resonance. I'm tuned to the scroll. I am the messenger and servant who sees and am led step by step by Yeshua HaMashiach.

And so by Yeshua HaMashiach hands directly into my spirit is given eternally by direct command of Adonai-YHVH, these Words that are the activation and unsealing of the seven thunders now launched fully into the earth to be given into my hands at convergence, for execution in all obedience to The Lion of the Tribe of Judah, who cut me free from the web and canceled his contracts between me thee and them all.

They are the seven thunders, and they are in me, and I am given full executive authority in all wrath in a time, times, and half a time x 2. Then eternally and forevermore in guardianship and custodial care of Adonai-YHVH creation that is now given fully to Yeshua HaMashiach.

I would have just said that. But I match tone as commanded and led, yet as a warrior and artist I respect the artistry, even if that artistry is mastered fully by Yeshua HaMashiach by design of my Adonai-YHVH at my hands who is Biblaridion144, who I am fully and truly.

I am what I am made to become.


Respectfully,

  Biblaridion144 who many knew as William Alexander Brooks

  THE VOICE OF THE SEVEN THUNDERS SPEAKS!