---
Order: "3"
Date: 2024-10-28
Image: "[[the-testimony-of-jesus-is-the-spirit-of-prophecy.webp]]"
---
# The Testimony of Jesus is The Spirit of Prophecy
![[the-testimony-of-jesus-is-the-spirit-of-prophecy.webp]]
## Explanation of “In the Works of”
[[Introduction]] | June 04, 2024

Behold, I show you the mystery of the little book. For the book has been given, and the spirit of prophecy is the testimony of Jesus. My testimony of Jesus began in my life when the Lord Jesus Christ called me into ministry and service in 1996 when I was living in New York City. I had answered the Lord's call to repentance by attending a home Bible study group and was a student in one of their classes. One evening I was sitting in a diner in Long Island City with a good friend of mine, and he asked me to turn in my Bible to John 4, and he began to read the following as I read along:


>**John 4:35-38**
>Say not ye, There are yet four months, and then cometh harvest? Behold, I say unto you, lift up your eyes, and look on the fields; for they are white already to harvest.
>
And he that reapeth receiveth wages, and gathereth fruit unto life eternal: that both he that soweth and he that reapeth may rejoice together.
>
And herein is that saying true, One soweth, and another reapeth.
>
I sent you to reap that whereon ye bestowed no labor: other men labored, and ye are entered into their labors.

As my friend read these verses, the words seemed to leap off the page and amplified straight into the depths of my soul. A fire was kindled in my heart, and so the Lord commissioned me into his service in 1996. I literally dropped my entire life and everything I was doing to go into ministry. I became leadership in a smaller mega church, and later, when I found out just how corrupt they really were, I hit the exits never to return in 2008. I struggled for a few years as I tried to walk for Christ, but my sins were holding me back. In 2013 my life fell apart and I self-destructed, and it was a slow-motion train wreck that had been in the making for some time. And so the Lord took me into serious chastisement and scourged me many times over until I returned to sanity on July 7, 2020, when I fully repented of my sins.

The Lord prepared me for this journey by granting me many visions, signs, miracles, several healings, and I have cast out many spirits by the Lord's direction, and much confirmation has the Lord given me to the genuineness of my ministries and calling. And so I am restored to my Lord, restored to Yahweh, restored to my wife and son and my eternal reward.

Sometime toward the end of 2023, I had something spectacular happen. Many times I will sleep with scripture playing on my TV and soundbar. This particular evening, I went to sleep with the Old Testament playing very softly. I was startled out of sleep in the middle of the night when my soundbar, which had been very quiet, became very loud for no reason out of the blue. Nobody had turned the volume up, and the remote was lying untouched on my nightstand next to my bed. The following verses from Ezekiel played while I sat there in disbelief:

>**Ezekiel 3:17-22**
>
Son of man, I have made thee a watchman unto the house of Israel: therefore hear the word at my mouth, and give them warning from me.
>
When I say unto the wicked, Thou shalt surely die; and thou givest him not warning, nor speakest to warn the wicked from his wicked way, to save his life; the same wicked man shall die in his iniquity; but his blood will I require at thine hand.
>
Yet if thou warn the wicked, and he turn not from his wickedness, nor from his wicked way, he shall die in his iniquity; but thou hast delivered thy soul.
>
Again, When a righteous man doth turn from his righteousness, and commit iniquity, and I lay a stumbling block before him, he shall die: because thou hast not given him warning, he shall die in his sin, and his righteousness which he hath done shall not be remembered; but his blood will I require at thine hand.
>
Nevertheless if thou warn the righteous man, that the righteous sin not, and he doth not sin, he shall surely live, because he is warned; also thou hast delivered thy soul.
>
And the hand of the LORD was there upon me

And so it has been. Even though at the time I didn't understand that the Lord was sending me as an end-times prophet, I would soon find out.

On March 2, 2024, I began typing prophetic messages in what the Lord described to me as the works of John the Baptist. This continued from March 2 until April 5, 2024, and during that time I received 20 prophetic messages. All of the messages centered around judgment on Mystery Babylon, calling the saints to repentance, and announcing the soon appearing of Jesus Christ himself, as he will appear in the air at any time now for the faithful in his Church. I actually thought the prophecy on April 5 was the last one. I was wrong. The next prophetic message occurred on April 10, 2024, and the Lord told me he was sending me in the work of Peter to feed and care for the flock.

The nature and content of the messages changed from that point, though they still contain elements from the first twenty, and many of these messages interrelate one to another. On April 21, 2024, the nature and content of the messages shifted again, and the Lord told me he was sending me in the work of the Apostle Paul as a steward of God's mysteries. And so the content of the messages shifted again and are built on the previous messages and interrelate. These messages continued along the same lines until May 16, 2024, when the content shifted once more. I was told I was being sent in the works of John the Revelator (a term I've never heard or used), and on May 16 those prophecies began.

And so the Lord's handiwork is expressed in the calling he has given me, and he has sent me where I bestowed no labor; other men labored, and I have entered into their labors. It's not that these mighty men of God didn't finish their courses, but that these works have continued since all that time ago when Jesus Christ commissioned them in the works he sent them. These divisions were unknown to me when I started prophesying, and as he told me, I was entering into the works of each one. I never made the connection until it was revealed to me by Yeshua.

The calling and ministries on my life have been fulfilled. Other men labored, and he sent me into their works, and therein have I labored. I have been sent in the work of John the Baptist to announce the Lord's coming. I have been sent in the work of Peter to shepherd and feed the flock. I have been sent in the work of the Apostle Paul as a steward of the Mysteries of God. I have been sent in the work of John the Revelator to call the 144,000 and show events to come.

Personally, I am not worthy to compare myself to any of these great men of God and am not worthy of my own to even speak a simple greeting to any of you. But the Lord has made me worthy, and I have been sent into these works just the same. My entire life has led to these messages, and every word will find the eyes, ears, and hearts of those to whom they are sent. Should the Lord need me to say more, I will. And so I will finish my course and the works given for me to complete. And with this explanation, the handiwork and signature of the Lord Jesus Christ is revealed in these prophetic messages given to me. I have finished the works he commissioned me to do. And so I wait on the Lord.