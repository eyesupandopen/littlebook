---
Order: "79"
Date: 2024-11-03
Image: "[[o-israel-i-am-calling-you.webp]]"
---
# O' Israel, I AM Calling You!
![[o-israel-i-am-calling-you.webp]]
[[The Bitter Sweet]] | November 3, 2024

#### From Yahweh, The Great Eternal God:
Hear the Words of Yahweh, the great I AM and consider my question. Why do rats run from a collapsing house, my children? An obvious answer is for their own survival, except the rats who are running from Secret Babylon do so to hide their crimes, and so they can make spoil of her fully so they may have the short rule that I do give them. Since natural man loves darkness, I will now give him the darkness he so loves. Yet, I have recorded (and will yet record) every deed of every entity in my creation that has freedom to choose because to whom much is given is much required.

And nothing is hidden from my gaze, and nothing is hidden from my sight, and I AM he who does see, record, and remember EVERY evil act ever carried out in my creation. And there is nothing that can happen of which I am not aware and allow! In my sight, all thoughts are laid bare. In my sight every intent of the heart is laid bare and there is nothing or no one that has been created or made that is not under my mighty hand, for I am the Everlasting God of righteousness with whom you have to do, O' Israel and I do see you fully, though you choose to disobey me in partial blindness because of the hardness of your hearts.

Because, when I came to you in the person of the only Messiah I have ever sent and the only Messiah I will ever send, I was rejected fully by your Fathers. Because, I AM he who created Yeshua HaMashiach in the flesh for the salvation of all who call on his mighty name, whom you ignorantly reject even arrogantly and blasphemously calling him an idol of the goyim. O' Israel, so many of you have joined yourselves to the Synagogue of Satan and you now wait expectantly for your false Moshiach that Esau has prepared for Jacob's slaughter.

So hear the voice of the GREAT I AM for my thunderous, eternal voice is calling to you in this last time and I do send my Son to you yet once again to redeem Jacob and a remnant who accepts my Everlasting Son, Yeshua HaMashiach, will be saved even by his mighty hand and there is no other choice for salvation. Nor will there ever be any other choice or name given for salvation because I have given him a name above every name, that at the name of Jesus the Nazarene should every knee bow. And of those who refuse, they will be made to bow to the Lion of the Tribe of Judah who I am sending to the earth that he may judge and make war even in everlasting righteousness, and he it is who shall bring my entire creation under righteous subjection and he will rule with a rod of iron and judgment, grace, and mercy are forever with him. Understand that wide is the way of destruction and many names and false gods do seek to take you to their inheritance of that everburning lake of fire, which burns with brimstone the hottest flames of punishment.

O' Israel, how you have broken Yahweh's heart in your disobedience and my heart still breaks for you from eternities past where I knew in my foreknowledge that in my plan of redemption your Father's would reject Jesus the Nazarene in favor of Barabbas, who was a murderer and leader of seditious rebellions in the lands at the time. And so I had him turn to the gentiles, and they did hear him for a season, yet blindness in part happened to Israel that a remnant of Israel might yet come to salvation at the proper time. Understand that many from Judea did make him their Lord and achieved eternal salvation in the Israel of God and they will be with my son forevermore. And I AM he who has sent Jesus the Nazarene amongst the nations to redeem your brethren who were scattered abroad on account of their rebellion, and even those who had no hope and many from the nations have achieved everlasting salvation and are now forevermore grafted into the tribes. So understand O' Israel that what the Everlasting I AM has cleansed do not call common or unclean!

But you O' Israel, you did reject and murder my son Jesus Christ and delivered him into the hands of sinful men who were determined to let him go in his innocence. But how else could my plan of eternal salvation come to pass except requirements of the eternal and unchangeable laws of Yahweh are met, of which laws I set for the righteous order of my entire creation to be ruled in perfect justice. And so Jesus the Nazarene did offer himself as the Lamb of God as your eternal High Priest forevermore after the order of Melchizedek to pay the penalty prescribed by Moses for the sins and transgressions of mankind and to redeem mankind fully from the curse of the law. Because Moses came as Israel's schoolmaster to take and preserve Israel for Yeshua HaMashiach and he has paid fully for your redemption, and although you are rebellious students a remnant will respond to my chastisement even the trouble coming to you during Daniel's seventieth week that is at your doorstep and will soon kick open your doors to an eternal choice.

So understand who you have rejected, O' Israel, whom I love with an eternal love, for you are those whom I promised your Fathers in many covenants in ages past that in these times of judgment I would preserve you for their sakes, and I am the same Everlasting God of Righteousness who changes not! And I AM HE who does remember the many intercessions made by your Fathers on your behalf and every intercession I do remember word for word and I will honor their request for those of you who are willing and obedient. And even now my Son, whom you ignorantly hate, makes intercession for you in his eternal love for his kinsman because Yeshua HaMashiach is Israel's kinsman redeemer, even he who has purchased the earth in his own atoning blood and he has ransomed you from the hands of the enemy should you chose to accept. Although, many amongst you have inherited your love of Egypt from your Fathers, do not allow yourselves to fall forevermore in the wilderness of the faithless.

Because Yeshua HaMashiach is he who will yet save a remnant from Jacob who will come to him fully, even during the trials of Daniels's seventieth week. So understand the times you live and awaken from your partial blindness at my command when you turn to Yeshua HaMashiach, whom I have sent for your salvation as your Messiah (when you no longer will be blinded by the hardness of your hearts). Because you will turn to the son of righteousness and he will receive you to himself, and he will take you to safety and hide you from your destruction from the hands of Esau's false Moshiach.

So understand he with whom you have to do because I AM a God of many covenants, and I AM a God of many promises, and I AM The Everlasting God of Righteousness who comes once again to call my people to return to their chief shepherd that I have sent for the salvation of Adam. And there are many aspects of who I am, and each name carries its own significance regarding The Everlasting God. So hear me and hear me well and understand Yahweh, who is calling you to myself that you may yet obtain salvation. And so I remind you and teach you as babes, when it is you in fact that should be teachers, O' Israel! So learn of your Everlasting God of Righteousness!

I AM Elohim! Even your mighty creator!

I AM El Elyon! Even The Most High God!

I AM El Olam! Even The Everlasting God!

I AM El Shaddai! Even The Almighty God!

I AM El Roi! Because there is nothing hidden from my sight!

I AM YHVH Jireh! Because I AM he who provides!

I AM YHVH Rapha! The Lord Your Healer!

I AM YHVH Nissi! Because I AM Your Banner!

I AM YHVH Shalom! And I have sent Yeshua HaMashiach as your peace treaty between you and I!

I AM YHVH Raah! For I AM he who has provided my perfect shepherd, even Yeshua HaMashiach!

I AM YHVH Tsidkenu! I am The Lord of Righteousness!

I AM YHVH Shammah! Because I AM The Lord Your God who is forever there for my creation.

I AM Adonai! Because I AM Sovereign over ALL!

I AM YHVH because I AM who I AM!

And many more names and attributes do I have, so hear my voice that roars as the thunders in the heavens, O' Israel, because I AM the God of your Fathers that you falsely worship in stubbornness.

I AM The God of Abraham that you have forsaken!

I AM The God of Jacob even whom you have left to go into the arms of another, and you have run to your false gods even proud of your rebellion. Understand Israel that you are in the grips of The Synagogue of Satan even those who say they are of Israel who lie and are not.

Hear my voice O' Israel, and come to Yeshua HaMashiach in this last time because I am calling you in my love for you and I do extend my grace and mercy to you in this time. But you are a stubborn nation and the stubbornness and hardheartedness of your Fathers you have made your own, and you have rejected the God of your Fathers whom you worship in an unlearned and false manner because my people are destroyed for lack of knowledge, so come to Yeshua HaMashiach and learn of him so that you may yet achieve salvation at his mighty hand.

O' Israel, how my heart breaks for you because I took you like a tender plant in a barren wilderness ready to perish and wither away evermore and gave you life and made you a peculiar people unto myself. I entered into many covenants with your Fathers, even covenants they were unable to keep because of the sin and corruption inherent in the blood of Adam. But I AM The Lord Your God who remembers and who has kept my promises and covenants and I will yet fulfill every promise and covenant ever made to mankind even in the face of Yeshua HaMashiach, who is my beloved son Jesus the Christ.

O' Israel, will you remain faithless and disobedient? Will you forever join your enemies in their eternal punishment? And so it is that you have been disobedient and you have walked in partial blindness, and I have taken your nation from you and you are no longer led by Yahweh The Great Eternal God. But in your rebellion you are led by the hand of your enemies who pretend and masquerade that they are Jacob when in truth they are Esau. Understand that all who reject Yeshua HaMashiach have turned from Yahweh to false gods and unbelief and many are enchanted and held in bondage to their black cubes that they worship ignorantly in unbelief. So understand, all those who are led astray by their false Moshiach or their false Mahdi in their false faithless religions that do not lead to Yahweh nor eternal life, will find everlasting destruction for all those who chose to remain therein.

O' Israel, come to me through my son Yeshua HaMashiach who is also Jesus the Nazarene, whom you do reject as did your Father's before you. Only perish not in the sins of your Father's and accept my love and the sacrifice that I gave on your behalf, even by which sacrifice all of Adam has been blessed and many from the lands and from the nations have come to their Lord in repentance and they are blessed and redeemed forevermore. And understand that I AM he who has placed all things into Christ Jesus mighty risen, and transformed hands because I AM he who has made him a life giving spirit and of his rule and kingdom there will be no end!

Therefore, all of my covenants from Adam to Moses, and even The Testament of Moses is now set to be fulfilled in the face of Jesus Christ by my New Covenant which is my New Testament that is given for the fulfillment of all things even from Adam to Christ. Because those who achieve eternal life must submit themselves and bow the knee to my only begotten son, in whom I am always well pleased. So come to me in the face of Yeshua HaMashiach in whose sinless blood did he ratify his New Covenant, which is The New Testament, that I have fully accepted and planned before the foundations of the world were laid. And I will send my 144,000, led by Yeshua HaMashiach, for your salvation and they will hide you away in a place that I have prepared for you and there you will be cared for and saved alive from Esau who is preparing for your destruction.

Yet Esau, who oppress my people, is deserting Mystery Babylon because they intend to cover their sins. A sin which rats deserting a collapsing house are not guilty. Therefore, they will attempt to their bury crimes and even their sinful shovels they used to cover their crimes and I will yet expose them, says The Lord of Hosts. For they have fully plundered Secret Babylon even as I have allowed to happen in my double portion of judgment on that great harlot! And so they have gathered to themselves all of Secret Babylon's military might and they will continue to spoil until Secret Babylon is destroyed shortly in one hour and never again will she rise. Understand that no weapon that is formed or fashioned against you will prosper if you yet call on your true Messiah, even Yeshua HaMashiach!

So understand that The Synagogue of Satan has a form of godliness in their outer appearances, but they are of their Father the devil and the lusts of their Father will they do because Esau corrupted his offspring forevermore. These evil tares, even your seemingly righteous leaders are evil tares and many are child molesters who prey on the young and who have gone astray in the sins of Sodom and Gomorrah, and they prey on children, and they are not virtuous shepherds but mangy. And the dragon who is their Father is he who leads them, even the same who has provided two mangy shepherds to rule and shepherd the earth in unrighteousness. Even the beast from the sea who will rise as their Mahdi and the beast from the earth, who is also their false Moshiach and will come to rule the land and indeed they will dominate the world in unrighteousness.

And the stain of their mange does stain through their entire being, and salvation can they never attain. Because all who modify themselves genetically in such manner or who are born of the fallen ones have no salvation because they are made in the image of the dragon and of that image they are through and through. That which is crooked cannot be made straight, and every abomination of the fallen ones can only do evil because they were made to bring about the destruction of mankind, and they would have been successful had I not stopped them in the days of Noah.

And yet they will rise again, because I bring giants to fulfill my wrath! And The Synagogue of Satan is working to cover all traces of who they truly are before calamity hits and their deception culminates in disaster because the fallen ones are allowed to destroy Secret Babylon. Yet every sin will be given fully into their bosoms and therefore, it is impossible to hide from Yahweh and my son Yeshua HaMashiach and our wrath will find them even as they try to hide themselves in the heart of the earth. There are none who are subject to the great judgment who can escape the lake of fire, save those written in the lambs book of life and there are none who can escape their sins save those whom salvation is intended even for those who accept my peace treaty. No matter how many nations they destroy and no matter how far they hide themselves in the earth, they will not escape the vengeance and wrath they have accumulated to themselves and I will repay them to the fullest says The Everlasting God.

Because I will change the earth from its current arrangement to its original glory, and the redeemed of the earth shall walk there in safety. And so what is, will be altered into what will be, and they shall not escape, even all those who are left to judgment where many calamities and disasters will occur, and the ice will melt, and the nations shall change, and the earth will be restored to its former glory. Of which glory the fallen ones changed into corruption to suit their own lusts.

And I am Yahweh, The Great Eternal God, even he who created the heavens and earth, even he who is from everlasting to everlasting, and of my own will and counsel did I speak into being the things that are even from that which was not. And so hear my voice, O' Israel, and even all those of you who seek to ignore my Words in hard-hearted stubbornness. Judgment is about to fully come upon the earth and I will expose all of Esau for who they truly are, and will even expose fully their Father's of whose lusts they are eternally bound.

Behold! Those of Esau claim their own righteousness, ignorantly thinking they are my chosen people, and their false Moshiach, even that little horn, will claim that he, himself, is God! (There is none like Yahweh, The Great Eternal and Almighty God!) And the fallen ones cannot deliver themselves out of my all powerful hands, and Yeshua HaMashiach will utterly bruise Satans head as I promised Adam. There are no depths in the earth where they can hide themselves, though they try, and they are now bound to the earth even under the firmament of which they cannot escape. There are no other identities they can assume where I will not see them for who they truly are. There are no forms they can take where I do not recognize and see them fully, all the way through to their polluted hearts. And every last one of the fallen ones from the least to the greatest and all those who follow their evil ways will have their eternal inheritance in those flames of punishment in that ever burning lake of fire where their worm dies not.

So take up a lamentation, O' Israel, for those of you who stubbornly refuse my invitation to eternal life, even all who will decide to follow the fallen ones and all who will join themselves to the dragon and all those who are of Adam who had the choice of salvation but instead chose their sins that will lead them to the second death should they not call on the name of Yeshua HaMashiach for salvation.

So I will explain the choices you now have left. You either accept your true Messiah, Yeshua HaMashiach that I have sent, and you will be saved into eternal reward and glory, of which your trials and persecution are not worthy to compare. Or if anyone continues with or joins the dragon in their new order, you will have refused eternal life and instead accepted fully your own damnation for the sins of the flesh, and you will rightfully bear your judgment when you were begged to escape by obedience, of which you will have refused.

Any and all who take the mark of the beast, will have forevermore altered the image of Yahweh of which they were created, leaving them in an irredeemable state. Therefore, I beg you to choose life that you may live in all eternity in the love and blessings of your creator expressed fully in the face of Jesus Christ, even Yeshua HaMashiach! Otherwise, you will join the fallen ones in their inheritance of burning brimstone in that eternal lake of fire, where punishment and recompense for sins are the only eternity you will ever know.

Understand, that my intent is not to be cruel nor unjust to my creation, but my laws of justice are unchanging and unalterable. And so the creation groans and cries to me mightily under the weight of the fallen ones sins and the sins of mankind, and the times to purge and cleanse the earth in judgment from evil has come; although the seeds of rebellion will remain but never again will the enemies kingdom rise. Although Satan will try his last attack in his little season before he is cast evermore to the fires because he is no king, yet his throne will be unquenchable flames of the hottest purity, and they will have no mercy.

For what do my eternal laws dictate for the disobedient, so call to remembrance that the wages of sin is death, and so Adam sinned and ended his own life in the wages of sin, which is death. Yet the burnt offerings and the sacrifices of old were not enough to fully redeem my prodigal son, and so a perfect sinless man is the only acceptable sacrifice because Adam was perfect and sinless when he sinned.

So I, even Yahweh The Great I AM, has sent Yeshua HaMashiach as promised as the lamb of God who shed his sinless blood voluntarily to pay the penalty of Moses by shedding his own sinless blood in utter agony that mankind might be redeemed from the curse of the law, even all those who choose to become a new creation in Christ Jesus eternally more because this same Christ Jesus is Yeshua HaMashiach!

I AM Yahweh, The Great Eternal God, and I AM that I AM.

I AM he who has sent Jesus the Christ, even Yeshua HaMashiach, for the salvation of my creation so hear him and obey his Words as Moses commanded.

I AM he who has sent these Words by my messenger and servant that my son Christ Jesus has commissioned and raised for such a purpose at my command because Yeshua HaMashiach always does the will of his Father and we are one in unity and purpose.

I AM The Living God who is calling you, O' Israel, even so that all who are ordained to eternal life may come to the safety of their chief shepherd.

So hear my words O' Israel and come to my son in full repentance and accept his sacrifice, for of a truth should you reject his call there remains no more sacrifice for sin but eternal judgment because you will have willingly and eternally chosen evil over righteousness, and I will give all who make such a choice the full consequences of their decision, yet understand all are free to choose.

I AM he who will make all things new!

I AM The Father of Lights who will make his abode with men in the new heavens and new earth that I will fully create in righteousness and nothing that is evil will ever enter therein. And I will give that holy city New Jerusalem to my overcomers and all those who come to Yeshua HaMashiach, who is also Jesus the Christ and they will eat of the tree of life and they will have entrance into that holy and perfect city and I will be their God, and they shall be my people forevermore, Yea and Amen.

Kiss the Son, lest he be angry and you perish from the way.

The times are now.