---
Order: "69"
Date: 2024-08-24
Image: "[[now-is-the-time.webp]]"
---
# Now is the Time
![[now-is-the-time.webp]]
[[The Bitter Sweet]] | August 24, 2024

It is time, my children, it is time. It is time to come home, when the trumpet sounds and my church is gathered, where Yahweh awaits with joy in his heart for your sudden arrival. It is time to come home, when the trumpet blast calls the children of the most high to go where the angels live and roam. It is time my children for me to gather you from the four corners of the earth, even all who have fallen asleep in Christ will rise first and you who are alive and remain will be caught up together with them in the clouds. For I Christ Jesus am your living Lord and Savior, and I am calling you to your home in the heavens where your rewards await, where I have prepared you a place in my Father's house, for in my Father's house are many mansions. I am calling you home to stand before your Lord, so all may receive of the things done in the body, whether good or bad, that all may receive of the Lord their reward, and that all may take their places in the orders of the heavens that are prepared for each of you.

Behold! I am Yeshua HaMashiach, and I am the bridegroom who is approaching to gather my bride for the times of our wedding has arrived, where I will enter into everlasting covenant with my chosen, even those who have made themselves ready, and I have cleansed in my atoning blood because they came to me fully and gave their entire hearts to me in love and commitment. Although they did not walk perfectly, and many overcame grievous sin, they did cleanse themselves fully in the blood of the lamb, and they now stand before me fully cleansed from their sins and are as pure as virgins who have committed no fornication and have kept themselves from the evil one. Behold! My over-comers that I have forgiven from all sin and have poured oil in their lamps because they came to me in their times of need and I showed them how to trim their wicks and I did heal them and set them apart for myself, even all that Yahweh has chosen from before the foundations of the world to stand as my bride and be with me forevermore, and they will reign with me as everlasting Kings and Priests for so they are called, sanctified and chosen in me, Christ Jesus their resurrected Lord.

And my 144,000 will be changed and sealed and fully recreated for the purposes that they have been called and prepared to accomplish. Truly, truly, every soul who has believed on my mighty name and made me their everlasting Lord will be changed fully and recreated newly as a new creation, and they will be fashioned as I am. And never again will they sin, either through pride nor ungodliness and never again will they be cursed, and never again will sickness or pain, or death or sorrow ever touch them again for the former things are passed away and the true light now shines. And it is I, Christ Jesus, who will now move to reveal himself to Jacob and whosoever calls on my mighty name to the end shall be saved, even all the dwellers on the earth who are ordained to eternal life and there will be a great multitude who will accept me as their Messiah and I will have saved them to the uttermost.

I am coming for you, my loves, and the times are now. I have waited an entire age of grace and have saved many, and many will be risen to newness of life in me, Christ Jesus their eternal Lord, and the dead in Christ will rise first, and the last trumpet is at the ready now. Many signs miracles and wonders have covered the earth in their splendor and the signs are non-stop around the world now that announce my appearing, that announce the marriage of the Lamb to his faithful bride, and the banquet halls in the heavens are prepared and at the ready.

And so it is, a heavenly celebration awaits my faithful, called, and chosen, and now is time for them to cease forever from their labors that they have labored in the earth in their houses of clay, and they have labored in the flesh as my fellow workers and have gathered and brought many to me, the Lord Jesus Christ that they may receive everlasting salvation forevermore. For though their flesh was corrupted in sin by Satan, I have given them a purpose and called them to leave forever the futility of which they were condemned by sin.

And so they have this treasure in earthen vessels that the power of God does live and dwell in them, and they did many mighty works in my name, and I am he who empowered them to become heirs of salvation and heirs of eternal life and I have redeemed them and given that eternal down payment in the new birth and I have sealed them all with that holy spirit of promise, even that unbreakable seal of promise. And now it is time to fully redeem the purchased possession, even all who have made me Lord from a faith filled heart knowing that Yahweh raised me from the dead to die no more. Now are the times of their full redemption where they will receive fully of their down payment received of me in the new birth of Christ in you the hope of glory!

Behold! Hear my voice and understand my words and know that your glorious future is not years away, nor is it set to arrive in Jubilees to come, but is upon you my loves and suddenly in an eternal instant will you all be changed and the times of change are now. You will find yourselves suddenly transformed into eternal glory, and I will clothe you in spotless garments that can never be soiled. Suddenly will you find yourselves standing in Yahweh's throne room, even in the Father of Light's eternal splendor and glory, and you will partake forevermore of his eternal nature for you are sons of the living God, even all who were taken from Adam and redeemed from red earth.

And it was my atoning blood that was poured out on the earth at Golgotha that secured your salvation once, and forevermore as I gave up my life with the words "It is finished!" And I Christ Jesus, am forevermore the resurrected and ascended Lord of Lords and King of Kings because Yahweh raised me from the dead to die no more! I am the last Adam, and I am the son of man who has redeemed the sons of men who called on my name and made them into eternal sons of God who will evermore live in everlasting glory and eternal splendor and forevermore will Yahweh be glorified in them, and them in Yahweh for in me, Yeshua HaMashiach does all fullness dwell forevermore, and Yahweh will be all in all and forevermore will we move as one new creation and one new man. And you, my called chosen and faithful, are forevermore redeemed, and you are about to understand your true lives for your lives are everlasting. So understand that you are dead, and your lives are hidden with me, Christ Jesus, in Yahweh. When I, Christ Jesus, who is your life, appears, then you will also appear with me in glory. Know you not that your true selves are hidden in me, Christ Jesus?

So why are you downcast my chosen, my faithful, my Church and even my Bride? I am coming for you and behold, I am approaching for you. And I will gather you suddenly to myself. And as the earth spins into judgment and war, the heavens will rejoice at your presence and great celebration will there be when the sons of God are forevermore united with their Lord of Lords and King of Kings in everlasting glory and newness of life will be had by all. And there will never more be a separation between those who are redeemed by the blood of the Lamb and their Father and their God.

For now is the time that Yahweh has chosen to begin to fully reveal himself to his creation and his revealing of himself fully starts with the house of God, and he is about to reveal himself fully to his chosen and faithful, even the first-fruits, for those whom I gather to myself at the sound of the last trump are the first fruits from the dead. And now it is time for them to fully know, even as all of you are fully known of me and my Father. And so I announce my appearing and I counsel you my faithful to continue to make yourselves ready for my appearing, for now are the times as judgment begins at the house of God. And suddenly, will it occur.

Behold! Fear not the coming storms that many of you see gathering: storms of war, storms of approaching calamity, storms of natural disasters that are surely about to take place. Understand that nothing will in any way harm you, though many live in temptations and spiritual warfare that is won fully in me, Christ Jesus. Behold! The time of my appearing for my faithful is here and as the birth pangs are non-stop and suddenly will they be gathered and snatched from judgment that is not for them.

I am calling you to your home in the heavens where your rewards await.

I am calling you home to stand before your Lord, so you may receive of the things done in the body.

I am Yeshua HaMashiach.

I am the bridegroom who is approaching to gather my bride for the day of marriage is at hand.

I am coming for you, my loves, and the time is now.

I am he has who empowered you to become heirs of salvation and heirs of eternal life.

I am coming for you to snatch you into the safety of the heavens and the times are now.

I Yeshua HaMashiach have sent these words by my servant, and by my servant have these words been sent.

Stay at the ready and do not leave your posts and continue to watch for me. Do not be faithless, but watch and understand that the signs of my appearing are worldwide, and then suddenly will you stand in the everlasting presence of the great I AM!

Are you ready?