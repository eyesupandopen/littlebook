---
Order: "97"
Date: 2025-07-15
Image: "[[behold-the-choice-is-yours-beast-revealed.webp]]"
---
# Behold! The Choice is Yours | Beasts Revealed | Prophetic Declarations Proclaimed
![[behold-the-choice-is-yours-beast-revealed.webp]]
[[The Bitter Sweet]] | July 15, 2025

Hearken to the words of your savior, Lord and King my Children and incline your ears to the Words of your Lord, even Jesus Christ the righteous, for I am the son of righteousness and I do rise in my glory, and you have grown as calves of the stall in relative peace and safety and I have raised you for a heavenly purpose that is about to be fully revealed in you, my faithful and chosen. Behold! I am he who tries the hearts of men so that you may know for a certainty whether you are truly in the faith, or if you are deceived and carried away by your sins and the current strong delusion that has captivated the World.

For I am he whom Yahweh has shared his throne, even Christ Jesus the risen and empowered Lord, and I am Lord of Lords and King of Kings and behold the Lion of the Tribe of Judah is coming in the clouds to receive my faithful to me so that they may be taken into the heavens for the marriage of the Lamb, for my Bride has made herself ready. And her lamps are full, and she has trimmed her wicks, and she awaits my appearing as a wise virgin, even those whom I have purified fully and are without fault before the throne of God. Even those whom have not been taken in craft by Barabbas, for Barabbas brings violent insurrection, war and calamity, for he is currently one head amongst several heads who work in collusion, but he will rise a false Moshiach, and he is chosen of the people of the land to rule the synagogue of Satan. For he is heir of whom their fathers chose, and they are making themselves ready to receive him as their King.

But you, oh Church of Laodicea, now comes your times of desolation and judgment. For you have chosen to yourselves another savior as your King, even he whose coming is heralded by lying signs and wonders and who currently has led you with enchantments and sorceries. I am Yeshua HaMashiach and I have purchased you in my own atoning, sinless blood, and I am he who would make you whole, and recreate you anew in my spirit, for I have been made a life giving spirit for so has Yahweh ordained all preeminence on his Son, even he who is the consummation of the lamb of God with the Lion of the Tribe of Judah! And in righteousness I will judge and make war for the lamb of God and the Lion of the Tribe of Judah are consummated in me, Christ Jesus, even Yeshua HaMashiach for so I am!

I will yet complete your salvation, oh Church of Laodicea, but you are not ready to enter into my Kingdom at this time because you have strayed from your single-minded purpose in Christ! I will show you your error, and you absolutely have an opportunity to repent from all sins, but you do not have any time remaining to argue with the voice of your Lord, for so this grievous sin is one of many Satan has used to bind you from coming fully to me in repentance that I may fully cleanse you in my atoning blood from your sins.

Behold! The times of the Gentiles are at an end and the wild olive tree that was grafted in amongst them, and with them partakes of the root and fatness of the Olive tree, will now be cut off. For you have ignored the Words of Christ Jesus, for I told you plainly not to boast against the branches that fell in unbelief: but if you boast, you bear not the root, but the root you. I am the Root of Jesse, and I am he who stands as a beacon of hope for all time, even he who brings salvation and the ways of Yahweh to the earth and I will rule my inheritance from the throne of David in righteousness and I have purchased the earth in my sinless blood and I will take what is rightfully mine forcefully from the hands of the squatters, even the fallen ones.

I am he who has given grace and mercy to the earth, for an entire age of grace was given to me by Yahweh for the salvation of the Gentiles. For Yahweh's purposes in Israel were always that the Gentiles would be blessed and come to salvation through Israel's obedience. But in the course of time they became prideful, and boastful, and they were cut out of the natural olive tree in unbelief. But you, my Laodicean Church, even you are the epitome of this same type of arrogance, unbelief, and blindness shown by the natural branches who were cut off in unbelief, and now you will be cut off from the natural olive tree. And I will now move to finish my work on the natural olive tree, even Israel my kinsman and people, even all those whom I have chosen to accept me as their Lord that I may recreate them as one new man and that the mystery of God should be finished, even the culmination of my atoning works of salvation.

And you, my Laodicean Church, have left your first love and are in the arms of a deceiver whom you have sworn fidelity. You have chosen for yourselves a new Barabbas even as your King and have rejected Jesus the Nazarene as your Lord and are in the arms of another false savior. Even he who poses as mystery Babylon's savior, who talks and acts as one of you, but speaks as a dragon. For mystery Babylon lives deliciously and in great material abundance, pleasure and wealth.

And mystery Babylon has made the entire world drunk with the filthiness of the fornication contained in her golden cup, but so are the ways of the fallen ones, who offer the worst filth, and you drink it willingly and with great delight because you are blinded by the golden cup to the utter filth you filthily consume. For even my Laodicean Church no longer gathers around my holy scriptures but at the rallies of Barabbas, in whom you trust. And so you choose a new savior because you love the world and the things of the world and cannot fathom the idea that you would loose your prized delicacies, except I will take all pleasures from you in my approaching wrath, and even now your losses multiply!

For you are blind and delusional in your arrogance that Yahweh would provide another savior than me, Jesus the Nazarene, for I am the promised seed of the woman and Dan is a lion's whelp of whom no Messiah shall arise. Hear me and hear me well, oh church of Laodicea, for now is either your repentance from your hearts offense or now is the time I will leave you to the refiners fire and all who call on the name of the Lord to the end will be saved and many who confessed my name faithlessly will fall away into oblivion, having wasted their opportunity on a form of godliness that denied the power thereof: My Laodiceans, I am the power thereof and in me Yahweh has placed all preeminence, and you have denied me, your Lord and savior, and I will spew you out of my mouth unless you repent now!

During my age of grace, salvation spread amongst the nations, and nation after nation shared and partook of the root of the natural olive tree. And now, the nations will no longer be a beacon of salvation and their time in the Son came about by the rejection of my kinsman and people for they shouted in unbelief release to us Barabbas! But as the mysteries of Yahweh were revealed by my holy apostles and prophets, I have restrained Barabbas and not released him fully, but only allowed the mystery of iniquity to progress. And now the times have come where I will fully release Barabbas as my restrainer is removed and as my faithful, called, and chosen are taken into the heavens where I have prepared their permanent dwellings, and they will be clothed in fine spotless linen that never can be soiled or tainted.

Are you so blind to your world, and so deaf of hearing that you no longer hear my voice oh Laodicean Church? You have believed the lies brought about by the mystery of iniquity, and you have allowed toxic leaven into your corrupted Bibles that have brought absolute corruption into your Churches that have contaminated your own hearts with fables in erroneous unbelief. You allowed the lies of dispensational wizards to enchant you with false texts and lying words. You no longer understand scripture, and you have heaped to yourselves great troubles that will come upon you suddenly. Every Word of God is pure and is intended for the obedience of faith and edification of the recipients. Understand the Words of my Words and understand the times you live. For I had John the Revelator write: And I saw a beast rise out of the sea, having seven heads, and ten horns, and upon his horns were ten crowns, and upon his heads the name of blasphemy.

And again John the Revelator wrote: I saw a woman sit upon a scarlet colored beast, full of names of blasphemy, having seven heads, and ten horns. And the woman was arrayed in purple and scarlet color, and decked with gold, and precious stone & pearls, having a golden cup in her hand, full of abominations and filthiness of her fornication.

And again: And the ten horns which you saw upon the beast, these shall hate the whore, and shall make her desolate, and naked, and shall eat her flesh, and burn her with fire. For God hath put in their hearts to fulfill his will, and to agree, and give their kingdom unto the beast, until the words of God shall be fulfilled. And the woman, which thou saw, is that great City which reigns over the kings of the earth.

My Children, understand that beast can refer to individuals and also to kingdoms, study to learn. The beast that carries the harlot will destroy the harlot and will be in subjection to the harlot no longer, for she has ruled the kings of the earth in her fornication. So the beast to rise out of the sea will produce their expected Mahdi, but will also utterly destroy Mystery Babylon, for God has given the great whore into the hands of her enemies who already utterly hate her.

Before the beast from the sea and the beast from the earth rise fully in the dragon's Kingdom, there are many rulers who are united in purpose to give their power and rule to the dragon, for God has put it in their hearts to accomplish. And they will destroy mystery Babylon. Do you think you have mastered my holy scriptures because you have believed your lying theologians? Understand and hear the Words of your Lord!

Again, I had John the Revelator write: And the beast which I saw, was like a Leopard, and his feet like a bear, and his mouth as the mouth of a lion: and the dragon gave him his power and his throne, and great authority. And I saw one of his heads as it were wounded to death, but his deadly wound was healed, and all the world wondered and followed the beast.

My Children, the words of Yahweh have multifaceted depth, of which no man can master. The beast described is an empire who will rise from the destruction of the harlot, and out of the old order will the new order rise! It represents the beast of the sea, for he will rise as their Mahdi, and it represents the nature of the kingship with he will rule the sea. Why do you not respect the words of my Word? It does not say that the beast from the sea himself was wounded, for what man literally has seven heads? But one of his heads as it were wounded to death. Oh, fools, and slow of heart to believe all that the Prophets have spoken! AS IT WERE wounded to death. The Words "as it were" should stop you in your tracks, but you don't even believe the least of my words any longer, and I am the Word made flesh. Is it not clear to you, AS IT WERE, is an age-old idiom? Is it not clear to you that "were" is subjunctive? Is it not clear to you that it is a shortening of, as if it were so?

But no, you believe the lies of the dragon, for Barabbas speaks as a dragon, but he is not Barabbas, but the beast from the earth. And so now all the world will wonder after the beast on account of his lying signs and wonders, and he will perform many more lying signs and wonders, and he has not risen fully for the harlot is not yet burned with fire, but he is now revealed in his time. He speaks as a dragon, saying "God alone saved him from his head wound" and this is a blasphemous lie. Yahweh, the great eternal God, has sent me Jesus the Nazarene as the savior of the world. I and my Father are one in unity and purpose and Yahweh did not save Barabbas and neither did I, Christ Jesus. You have been deceived and taken and ensnared in great deception, and I say to you repent and return to your first love and do so now, for there is no time!

For I am he who tries the hearts, and I am he who tests all who I call to salvation, for I purify all in the refiners fire! Behold! I am he who sits as a refiner and purifier of silver: and I purify the sons of Yahweh, and purge them as gold & silver, that they may offer unto the Lord an offering in righteousness. Do you not understand that I will make you priests and kings before my Father? Even though my gift of holy spirit, whereby you are born again of incorruptible seed is perfect and needs no refining, you are descended from Adam by blood and must fully allow my work to be accomplished in your lives, unless my seed has fallen on stony ground.

Now comes the times of judgment and the times of grace are complete. Even though many will scoff at my words and turn away in unbelief, it is already known by Yahweh the outcome. For Yahweh always proves to mankind his own corrupt ways and reproves mankind of sin, knowing in his love and eternal wisdom that he will save some. And as Yahweh hardened Pharaoh's heart, so to will he harden the hearts of many who hear but do not listen. Yahweh will try a person again and again. And some will be like Pharaoh and will harden their hearts further in unbelief but some will depart from the ways of Pharaoh and rise up to eternal life in Christ Jesus, yet through the refiners fire.

Understand that those who choose Barabbas will make themselves partakers of the crimes of Barabbas, and those who refuse to call on my name to the end will all be damned because they had pleasure in unrighteousness. For your new savior is no savior but a ravenous beast. And his system and kingdom are composed of those who hurt the children. Do you not understand the ways of the Dragon? For those who follow the ways of the dragon prey on children. They sacrifice children to Moloch, they seek their fountain of youth from the blood of tortured children, they molest children for their own sick gratification, and they practice the smiting of the embryo in the womb to murder the little ones before birth, and they have secretly led you into their ways, for so are the ways of the leaders of Secret Babylon and also the kingdom of the dragon. And now comes the judgment of God for these things and many more. For had you not seen these things you would have no sin, but now you see and your sin remains.

Have you not read? Thus, says the Lord, A voice was heard on high, a mourning and bitter weeping. Rachel, weeping for her children, refused to be comforted for her children, because they were not. For you have failed the charge given, and you were entrusted with my mysteries and stood as a light of salvation and a beacon of hope. But now you have joined the ones whom I sent you to stand against. And so now comes the times I will leave you to your future.

Hear me and hear me well all who would reject the voice of Yeshua HaMashiach, even the voice of Christ Jesus: you have no time! I counsel you to hear me in my love for you my children and repent now! For the refiners fire is about to fall fully on you, and it will cleanse the land of all the dragon's kingdom and the earth will be in subjection to Satan's ways no more and never again will his kingdom rise, for I am Lord of Lords and King of Kings, and I will utterly destroy the fallen ones. All who refuse repentance will have their part in the lake of fire and will share in the punishment of the devil and his angels in that great lake of burning brimstone. Likewise, all who repent by coming out of sin and calling on my name to the end will be saved and given great eternal reward in me.

Behold! Now is the time for the gathering of the faithful, and I will now leave those who refuse to Barabbas, for they have made their choice.

I am the son of righteousness and I do rise in my glory.

I am he who tries the hearts of men.

I am he whom Yahweh has shared his throne.

I am Lord of Lords and King of Kings

I am Yeshua HaMashiach and I have purchased you in my own atoning, sinless blood!

I am he who would make you whole, and recreate you anew in my spirit.

I am he who stands as a beacon of hope for all time.

I am he who has given grace and mercy to the earth.

I am the promised seed of the woman and Dan is a lion's whelp of whom no Messiah shall arise.

I am the power thereof and in me Yahweh has placed all preeminence.

I am he who tries the hearts men.

I am he who tests all whom I call to salvation.

I am he who sits as a refiner and purifier of silver: and I purify the sons of Yahweh.

I am Lord of Lords and King of Kings, and I will utterly destroy the fallen ones.

I am he whom the great I AM has sent and I come to judge and make war.

Behold! I Yeshua HaMashiach have sent these words by my servant, and by my servant have these words been sent!

Those who do not turn from this false messiah will either find salvation in the refiners fire, or fall away into oblivion for all time: The choice is yours!

Because They Received not the Love of the Truth, that they Might be Saved

(And it will yet be that his head will appear as it were wounded to death, but his deadly wound was healed, and all the world will wonder and follow the beast. And so this deceiver will rise.)

And many in Secret Babylon, even those who believe his lies and follow his good words and fair speeches are captivated and ensnared by a false peace where they imagine that their delicious and sinful lives will continue where today is as yesterday and tomorrow will be the same as today And many will scream, howl, and lament that their hope is now taken from them And they will fight their countrymen to the death and all the while their full surprise attack will be fully unleashed, even as my restrainer is lifted from the earth. And Secret Babylon will fall to a double portion of judgment in one hour as many calamities fall. And those who worship their black cubes will exhaust themselves in slaughter, even a slaughter that is brought about purposefully by great deception and from the ashes they will rise.

Prophetic Judgments Underway / Soon to Fall / Then shall it happen, even as foretold, that sudden destruction will fall on Secret Babylon: And so it will be, even as declared and written!

Her coasts will be covered, she shall be split along the middle from the gulf to the lakes and great fire will fall and their missiles will be launched, and my mighty Angel will cast a great stone into the sea and Secret Babylons greatest city shall not escape, nor the city of Angels because truly, truly, will her sinful cities burn and be overthrown. The armies of the beast will be released and they shall hunt every person and will cull multitudes, and they have orders to eliminate all who do not suit their purposes, or who could rise to fight them another day. Hear my Words, my people, even all whom I am calling, and understand the times in which you live. For the world you now know will cease to exist, and in its place many wastelands will remain, even the ashes and ruins of Mystery Babylon, for war has come. For as I snatch my Bride into the heavens, great calamity will engulf Secret Babylon, and she shall be destroyed in one hour, and in one hour shall she be destroyed, and nothing can change her fate, for Yahweh has so declared. And so that finality will fully arrive when I gather the faithful of my Church to me in the clouds and when their departing shakes the entire world. It will literally shake the earth, and great shaking will consume Secret Babylon, and she will be rent up the middle as my saints depart. She will be utterly burned with fire from the sky and their missiles will fall. Her skirts will be covered with waters from the east and from the west! For a mighty angel will take up a stone like a great millstone, and cast it into the sea, saying, Thus with violence shall that great city Babylon be thrown down, and shall be found no more at all. For thus is it written and thus shall it be done!

For great is her judgment, and judgment has begun at the house of God.

Hear, Hear one and all and bow your eyes, ears, and hearts in obedience to the Words of Adonai-YHVH, and Yeshua HaMashiach, who is also Christ Jesus!

Hear my Words! Following are direct declarations concerning Secret Babylon, identified as the United States of America, and the unfolding of end-time events from both Yeshua HaMashiach, and especially Yahweh The Great I AM, for Strong is Adonai YHVH who judges the great harlot and her judgment has come!

Be it known, even so, which judgments are sent by way of Yeshua HaMashiach who is also Christ Jesus by the Spirit of Prophecy, given in the heart of my messenger, and servant whom I have commissioned and sent, and even hidden in my quiver for such a time as this, Selah!

Hear my Words my Body, My Church, and even my Bride! Hear my voice and stop yourselves at the sounds of my Words and hear their resonant authority echo into this world, for the earth is the Lords and the fullness thereof! Hear my Words my mighty 144,000 and understand my speech and ready yourselves for the appearing of your Lord, King, High Priest, and Messiah! For you will be taken into the heavens at that approaching trumpet blast, even that same mighty trumpet given into my might hands to sound so suddenly and unexpectedly now, Selah! Therefore, ready yourselves my wise virgins, because I am coming for you, and who is it who can stop me, I SAY WHO!

And you, O' defeated prince, even you who stands in defeated silence for you are a toothless lion. Hear my Words O' you Satans and understand my speech, for I will not be denied my possession and you are powerless and toothless to stop me, therefore, I rebuke you Satan, even the Lord of Lords and King of Kings, for you are allowed to do only what is permitted under my might hand and authority, even given by Adonai-Yahweh himself, therefore, silence yourselves and sit in rebuke at my voice, for you are ever rebellious, and yet you are subdued, defeated, and the times of your judgment has come, and you will not escape! Selah, little prince, Selah.

Behold! I am Yeshua HaMashiach, even the same Lord of Lords and King of Kings, for I am Christ Jesus, even the Lion of The Tribe of Judah who sends these Words by my messenger and servant, and by my messenger and servant have my Words been sent, Selah!

Even Words given by way of the Spirit of Prophecy via my messenger and servant by whom these Words have been sent to declare, even also in the mouths and by the hands of MY Little Flock! Selah.

Behold! A trumpet I hold in hand, given to sound at my command and at my signal a mighty shout!

And the world will go dark as the light of my appearing shines over the earth, for I will not share my glory with another!

Behold, I come! Behold, I come! Behold! I Come! Hear my declarations and hear my speech and tremble O' Secret Babylon.

For as my light shatters the thick darkness, for darkness cannot overcome my light nor the lights of the world, who are empowered by Christ Jesus and sent in great authority by the Father of Lights and your times of full redemption have come.

Therefore, look to me, Christ Jesus and keep your eyes up and open focused on your Lord Jesus Christ in all readiness and obedience. Arrange your affairs, for it will now be that suddenly on the earth, you are not.

And so I command you my loves, fill your lamps, and trim your wicks and take my fire and light your lamps ablaze to illumine yourselves in my Words, and understand that you are to wait by the wayside, for the Bridegroom does approach for both his Bride, and our guests. Selah.

Selah! My Loves, Selah, my Doves, for I do love you and I am coming and the hour is upon you.

Signed by my mighty hand, and in my own love and given in hand by my Messenger directly from me to the eyes, ears, and hearts of those to whom these Words are sent. Even Words I send to my Church, my Body, and even my Bride, and especially for my 144,000 because the times of your sealing has come, and a new song will I create within you that no man can learn. Selah.

Signed,

*Yeshua HaMashiach*  
*King of Kings, and Lord of Lords.*

Behold! Hear my Words oh you inhabitants of the earth, even the Words of YHVH the great I AM!

And understand my anger and my wrath is upon you oh dwellers of the earth, and if it were not for the sacrifice that I have eternally accepted, once all and forevermore, even that perfect passover offered by the high priest forever after the order of Melchizedek, even that son of man who offered his own sinless blood who is also that lamb of God, surely you would be as Sodom and Gomorrah and your judgment would have been instant and swift and sudden, Selah!

Behold Now! Look! Look and see he whom I send, even he who will now rise in great wrath bringing swift judgment on secret Babylon, even as suddenly on earth the faithful in Christ are not! Even that mighty Son of Man that I have made a life giving spirit and into whose mighty hands I have placed all things for fulfillment and the times of fulfillment have come and are now! Selah.

Nevertheless, judgment must begin at the house of Adonai-YHVH and will fall fully in the wrath of the lamb that will so suddenly now overtake the earth in great shaking and great judgment, even so as my wheat will be threshed and separated from the tares during Jacobs trouble and especially, so to will my wheat be separated eternally and forevermore from that serpent's tares, Selah!

For now are the times of harvest, and the times of harvest are now! Behold! Look! I have already declared and sent my Son, even that Son of Man who is also the Lord of Harvest; even with that mighty trumpet in hand, even as announced and declared previously in the Everlasting Gospel!

And even at that exact and specific moment etched eternally in my everlasting heart (for that moment has always been marked in my own heart which works all things after the counsel of my own will), even in my own heart where I hid the mystery of Yahweh!

Behold the times have come and we approach even that exact intersection where time and season meet, resulting in the faithful in Christ standing newly born into my throne room, clothed in brilliant glory and born again into everlasting lives of never ending reward, joy and glory for their love and faithfulness they have showed to Christ Jesus in their times of testing. Selah!

Therefore, know that the day of the Lord is about to fall hard upon you, oh inhabitants of the earth, even all you who think it but a light thing to reject my peace treaty, even Jesus the Nazarene, who is that lamb of God, even he who intercedes for you to this very second for all of you and so mightily have I accepted his Words of intercession as a sweet savor of sacrifice, wholly acceptable and accepted by YHVH the Great I AM forevermore! Selah!

Or you all would be as Sodom and Gomorrah and you all would be a sealed memory of judgments past, so understand my Love for I AM love and I AM the Father of Lights, and I do save by a mighty hand, even the mighty hand of the lamb of God, who is also the Lion of the Tribe of Judah who does roar in his intercession for those he loves, Amen.

Therefore, be it known, and tell them that the Great I AM is he who has sent these Words by my mighty messenger and servant and by my mighty messenger and servant have my Words been sent!

I AM he who sends my Words, even the Words of the Great I AM, even by way of Christ Jesus who is also Yeshua HaMashiach even by way of the Spirit of Prophecy so that judgment may be fully declared, even before sudden judgment suddenly falls.

So tell them The Great I AM, AM HE WHO sends these Words instead of sudden judgment, even gracious and life giving words for the obedient who will call on the name of Jesus as their Lord, even to their ends, Selah!

I AM Adonai YHVH, and I AM HE who sends these Words given in testimony against you, Oh Secret Babylon, even that great harlot of many states, even those United States that will suddenly fall to double judgment so suddenly now at the command of Christ Jesus who is also Yeshua HaMashiach.

Therefore, kiss the son lest he be angry and you perish from the way. You have no time for debate, except for quick obedience, so quickly Selah and repent, because you have no time!