---
Order: "77"
Date: 2024-10-25
Image: "[[to-the-faithful-in-christ-jesus.webp]]"
---
# To the Faithful in Christ Jesus!
![[to-the-faithful-in-christ-jesus.webp]]
[[The Bitter Sweet]] | October 25, 2024

Hearken to the voice of your Everlasting Lord, even Yeshua HaMashiach, because I am he who has called you to glory and virtue by way of the new birth whereby you are sealed with my holy spirit of promise. Yes, I have made you children of the great eternal God, even Yahweh himself, and there is none like him! Therefore, understand, my loves that you are among those who I have sealed against that day of redemption whereby you will stand fully in the righteousness that I will clothe you and much reward will many carry away for their faithfulness, though some will suffer loss.

Continue to follow hard toward the mark, for the prize of the high calling of God in Christ Jesus, and so that you may realize your full reward for the courses I have set your feet, even the courses of service where I have ordered your steps in service to me on earth during my times of grace. And you are my workmanship, created in Christ Jesus unto good works, which God has before ordained, that you should walk in them.

And so it truly is, my loves, that I am he who has given you an eternal purpose in me, your eternal Lord. I am he who is in perfect unity and purpose with Yahweh, even the great I AM, so if God be for you, my loves, who is it that can stand against you? Why do you yield and submit your focus to the weak and beggarly elements who seek to draw you astray from my mighty eternal hand, of which drawing away is impossible if you keep the singleness of your eye focused on me, Christ Jesus your ascended Lord!

And so I still teach to this day for the obedience of all with ears to hear to lay not up for yourselves treasures upon earth, where moth and rust does corrupt, and where thieves break through, and steal. But lay up for yourselves treasures in heaven, where neither moth nor rust does corrupt, and where thieves do not break through, nor steal. For where your treasure is, there will your heart be also. The light of the body is the eye: If therefore your eye be single, then your whole body shall be full of light.

My loves, do you not understand my parable? Your treasures are your thoughts, and so I direct you to keep your thoughts on things above so that in your walk you are producing and walking in the good works that I have ordained for your feet to follow with singleness of heart. Therefore, I had Paul write to Corinth: But I fear lest as the serpent beguiled Eve through his subtlety, so your minds should be corrupted from the simplicity that is in Christ.

Therefore, set your affections on things which are above, and not on things which are on the earth. For you are dead, and your life is hid with Me in God. When I, Christ Jesus, which is your life, shall appear, then shall you also appear with me in glory. Wherefore, my loves, understand that you are the lights of the world, even all those who are children of the Father of Lights! Therefore, keep your full focus on me, your eternal Lord of Lords and King of Kings and I will work mightily in your spirit that my eternal light may shine from my body of which you are part, and so my earthen vessels do shine and show the glory of the everlasting God in the face of Jesus Christ!

And so I ask you my bride, and so I ask you my body, and so I ask my faithful in Christ, why do you allow your enemies to distract and divide your attention from my glory and splendor? Understand that the fallen ones understand fully that your full redemption is as near as your next breath, and so they seek to steal your joy because they know it is impossible to pluck you from my eternal hands, though they try.

Therefore, in nothing fear your adversaries, which is to them an evident token of perdition, but to you of salvation, and that of God. Do not divert your attention to the clamor of the fallen ones, my loves, neither turn to the right nor to the left. But remain on that straight and narrow way, even the way of salvation whereby you learn of me Jesus the Nazarene for I am he who teaches you the ways of salvation whereby you are saved to the uttermost as you are cleansed in my atoning blood from all sin that you may live the righteousness of God in Christ in you the hope of glory!

Understand that as you walk for me, Satan does attack you as he seeks to halt your efforts and divert you into his counterfeit works of futility. Even the counterfeit social gospel that ignores repentance and remission of sins in favor of good works. Yet so it is, that feeding the hungry, that clothing the naked, that housing the homeless and much more are good works suitable to meet the needs at hand.

But I, the Lamb of God did not offer myself once, all, and forevermore as the final sacrifice for sin on that rugged stake at Calvary to pay for good works, nor did Yahweh raise me from the dead to be a provider of this worlds goods to those in need, but I was hung on a tree and shed my last drop of blood in bitter agony in substitution and payment for sin and for the consequences of the sins of sinners.

I, Christ Jesus, have redeemed you from the curse of the Law, being made a curse for you, (for it is written, cursed is every one that hangs on a tree) and yet that was even a price that was not mine to pay, because I, Jesus the Nazarene, am he whose innocence stands to this day! And I am sinless for all times and forevermore because I always do my Father's will. Therefore, rest in the works that I have given you to do and take my yoke upon you fully, for my yoke is easy, and my burden is light.

Times of great judgment have come upon the entire world, even the times of Jacob's trouble. Yet before Jacob's trouble comes fully on the world it must needs be that my faithful will be snatched away from the wrath to come and I, Christ Jesus, am he who is coming in the clouds with the voice of the archangel and with the trump of God and the dead in Christ shall rise first and you which are alive and remain will be caught up in the clouds with them and into the throne room of Yahweh your everlasting Father you will now go.

And so the day is upon you, my children, even all those who are faithful in Christ Jesus. Therefore, leave the cares of this fallen world behind and focus your full attention fully on your everlasting Lord, even Yeshua HaMashiach. Yes, your full undivided attention because the devil seeks those who he may devour and as a roaring lion he goes about with his worthless roar but understand that he is a defeated enemy my loves because I have fully defeated him and full victory is fully mine right since my last words uttered in the flesh on that rugged stake: It is finished!

And so it is that I now move fully for your full redemption and I will complete that perfect work within each and every one of you where you will be instantly and fully recreated as a new and perfect and sinless creation. Even a perfect creation of which corruption can never corrupt, of whose glory shall never cease, and of whose brightness shall never fade. For you will be made like me, Christ Jesus, for I am the last Adam, and I am a life giving spirit who is also the captain of your salvation.

Therefore, mind the things of the spirit! Do not allow the fiery darts of the wicked to burn their way into your treasures. Understand that Satan would seek to destroy your single-minded focus on your everlasting Lord with his own worthless and putrid treasures that are many times a convincing counterfeit of the genuine. So refuse his thoughts and ideas and repudiate all of his rebellious ways for his are the ways of death and surely he seeks to share his inheritance in those hottest flames of putrid brimstone with any who choose that eternal lake of fire, but that end is impossible for you my loves and I have sealed you eternally with the everlasting seal of the living God.

So remain in me that I may make your paths plain, and that I may show you plainly the traps Satan would seek to ensnare my faithful. Remain in me, my loves, for in Christ no trap can be set and the fowler's snare can be set neither by craft nor by force. Wherefore, guard your thoughts and keep your heads and hearts saturated in my holy Words! (For the weapons of our warfare are not carnal, but mighty through God to the pulling down of strong holds.) Casting down imaginations, and every high thing that exalts itself against the knowledge of God, and bringing into captivity every thought to the obedience of Christ.

For we wrestle not against flesh and blood, but against principalities, against powers, and against the worldly governors, the princes of the darkness of this world, against spiritual wickedness, which are in the high places. For this cause take unto you the whole armor of God, that ye may be able to resist in the evil day, and having finished all things, stand fast.

Yes, stand fast in your everlasting Lord my little ones because the times are on you. Even though many of you seek to return to a state of slumber, even as this world's falsely soothing frequencies seek to lull you into the great deception. Do not fall for their enchantments, and turn away from their witchcraft and spells. Turn away from their so-called entertainment, because it is not proper that the holy children of the most high God who belong fully to Christ Jesus be entertained by sin any longer.

I have confirmed in my faithful the nearness and absolute reality of my approaching appearing to gather my faithful into the safety of the heavens. I have even given dreams, visions, and many words to the little children who are greatly loved. My loves, this event is hurling itself fully your way and is upon you and closer than you let yourself imagine. Therefore, ready yourselves for me. Continue to come out of all sin and confess your sins to me fully and confess your faults one to another.

I have sealed my faithful in that holy spirit of promise and so I have provided oil for your lamps, even all those who have freely received from me my eternal gift of salvation and eternal life and eternal inheritance in Christ Jesus the eternal Lord of Lords and King of Kings! Look to the heavens my loves and for those who are obediently and faithfully watching for my appearing they will see with their eyes the glory of my appearing, because this thing will not be done in secret and it is impossible for Satan to hide the glory of my appearing, though he will lie and seek to cover my appearing with fake aliens and world war.

Therefore, wait patiently for me and fully carry out the works that I have given you to finish that you may finish fully your courses of service in my eternal plan of salvation for each of your lives. Understand my loves that Yahweh's justice and reward and inheritance and wages are not reckoned as natural man reckons because natural man is unrighteous and unjust. Each of you have been given works to produce that you may further my purposes of salvation and I, Christ Jesus will judge your works that you have worked in sacrifice and service to your everlasting Lord.

Understand that you all will be rewarded greatly for your faithful works of service that you have faithfully worked in my holy name. And, I, Christ Jesus am he who sees every work carried out by the faithful in Christ and the hearts intent and I will reward you to the uttermost. As I beheld the rich men casting their gifts into the treasury I saw the rich men, which cast their gifts into the treasury. And I saw also a certain poor widow which cast in thither two mites: And I said, Of a truth I say unto you, that this poor widow has cast in more then they all.

And so I come to you my loves, even here in these last fleeting moments before I gather you to myself and I encourage you all by the eternal love of Yahweh himself to stand fast and look to the skies for your redemption is upon you. And each wave of calamity will increase in intensity and destruction will increase as each wave crashes across the earth. The birth pangs are non-stop now and the earth is to be delivered of her child for in the earth are the sons of Adam who have now become sons of God even by way of the last Adam. And suddenly will they all be changed eternally and forevermore into the glorious liberty of perfection and they will be clothed forevermore in eternal and everlasting glory and they do have an eternal future and an eternal purpose in Yahweh's eternal plans.

Understand that that great red dragon is allowed to set the stage and moves his pieces into place on the worlds board. Understand that events are already in play and that the current course of the world is unsustainable and will absolutely result in utter and sudden calamity and many of these events that are aligning will come together in perfect convergence.

For so is the timing of Yahweh's plans, and every Yod and thorn of a Yod will come together in perfect execution and harmony, for anything that Yahweh sets his hand results in eternal perfection and eternal righteousness because even those who choose corruption and the eternal flames of punishment are righteously and perfectly judged and sentenced.

And so I say my loves, keep your wicks trimmed and maintain yourselves at the highest purity in my righteous and cleansing atoning blood. Keep your wicks trimmed by keeping yourselves in the purity of thought that my eternal scripture brings for the eternal God, even Yahweh himself is he who has sent his Word and healed them.

I am he who has called you to glory and virtue.

I am he who has given you an everlasting purpose in me, your eternal Lord.

I am he who is in perfect unity and purpose with Yahweh, even the great I AM.

I am he who teaches you the ways of salvation whereby you are saved to the uttermost.

I am sinless for all times and forevermore because I always do my Father's will.

I am the last Adam.

I am a life giving spirit who is also the captain of your salvation.

And I am he who sends the words of my everlasting gospel by my messenger who I have raised and commissioned for this very purpose and by my messenger have the words of my everlasting gospel been sent.

Truly, truly, I am he whom Yahweh has shared his throne until my enemies be made my footstool, even until I hand the fully redeemed creation back into the hands of the everlasting God of righteousness, that truly Yahweh may be all in all and that all may be yea and amen.

And it is I, Yeshua HaMashiach who has sent the words of the everlasting gospel for the obedience of all who are heirs of eternal life and these words will be preserved through the coming calamities and judgments and these words will find the eyes, ears, and hearts of those they are sent. Surely, I come quickly. Amen. The grace of the eternal Lord Jesus Christ is abundantly poured out over all of the faithful in Christ, AMEN and Amen.