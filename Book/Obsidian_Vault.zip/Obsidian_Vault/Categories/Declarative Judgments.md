## Declarative Judgments
- [ ] [[Behold! A Synopsis of Declarative Judgments on Secret Babylon Before Judgment Falls in Full]]
- [ ] [[Behold! Full and Unabridged Declarative Judgments on Secret Babylon]]
- [ ] [[Behold! Judgment On Secret Babylon - Charges and Prophetic Declarations Given Before Judgment Falls]]
- [ ] [[To The Fallen Ones - Heylel, The Satans, The Watchers, The Fallen Cherubim, The Fallen Seraphim]]