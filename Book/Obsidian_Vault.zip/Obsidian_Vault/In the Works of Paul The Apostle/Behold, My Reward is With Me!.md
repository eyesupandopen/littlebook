---
Order: "14"
Date: 2024-05-15
Image: "[[behold-my-reward-is-with-me.webp]]"
---
# Behold, My Reward is With Me!
![[behold-my-reward-is-with-me.webp]]
[[In the Works of Paul The Apostle]] | May 15, 2024

To my faithful, beloved Bride, who have fully loved me with their entire heart. You are the apple of my eye, and soon I am coming for you, sooner than you imagine. For your faithfulness, there is great reward in the heavens that has been prepared for you. Behold! Eye hath not seen, nor ear heard, neither have entered into the heart of man, the things which God hath prepared for them that love him. And so are the amazing truths concerning you, my love, for you will share in my inheritance according as your faithfulness testifies at my judgment seat, even that great Bema, where I will judge the works of each of my called and chosen and faithful.

For those whose works burn, they will suffer loss, but they themselves shall be saved so as yet by fire; and for those whose works abide, they will receive much treasure, for the day will soon declare it. For this is not a foreign concept to you, but one you have learned from the witness of the Corinthians in Paul's second letter: For we must all appear before the judgment-seat of Christ, that every one may receive the things done in his body, according to that he has done, whether it be good or bad. Knowing therefore the terror of the Lord, we persuade men; but we are made manifest unto God, and, I trust also, are made manifest in your consciences.

For your conscience will testify with your words when you will soon give an account of yourselves before the righteous Judge, even me, Jesus Christ. Some will stand before me and present their own works that will be burnt up by the refiner's fire that will result in shame and loss. Some will stand before me upright, having washed themselves in my atoning blood, where you will present me the works that I gave you to do. For to enter into my rest is to rest from your own works. So for those who have rested in my works is great reward for the faithful. But you all will be saved, and not one of you has walked completely perfectly before me, and so the day shall declare it. Fear not, I will reward you to the uttermost, for all the mighty works you have done for me in secret will be made manifest, so the day shall declare it.

Why do your hearts trouble you at these sayings? Have you not read in the first letter of John, where I had him write? For if our heart condemn us, God is greater than our heart, and knows all things. Beloved, if our heart condemn us not, then have we confidence towards God. And again: If we say that we have no sin, we deceive ourselves, and the truth is not in us. If we confess our sins, he is faithful, and just to forgive us our sins, and to cleanse us from all unrighteousness. So, confess your sins to me daily and as often as you'd like, and wash yourselves in my atoning blood.

For I am your intercessor, and you were purchased by my sacrifice as the perfect Passover to make an end of sins, and to make reconciliation for iniquity, and to bring in everlasting righteousness. Behold, my Bride! The times of restitution are at hand, for Peter prophesied of this time when he healed the man at the Temple Gate Beautiful: And he shall send Jesus Christ, which before was preached unto you. Whom the heaven must receive, until the times of restitution of all things. And now comes the times of restitution, my beautiful Bride, for you are pure before me and are cleansed from all unrighteousness in the blood of the Lamb, for I am the Lamb of God! Therefore, confess your sins faithfully.

And so judgment, restitution, loss, and great reward all start with the house of God. For shortly, you will be gathered together in the clouds to meet me in the air, for I will descend from the heavens with a shout, and with the voice of the archangel, and the last trumpet shall sound! Continue to watch the skies and observe, for God has done many mighty signs in the heavens, even announcing the marriage of the bridegroom to his bride, even the eternal covenant between me and my bride, which is soon to occur. So confess your sins and ask me to show you the sins you have forgotten so you may confess those as well; and above all, stand firm in the love of God, for the love of God covers a multitude of sins. So fear not, because it is impossible for you to confess them all.

**Of judgment:** because you have passed from death unto life in me, your resurrected Lord Jesus Christ. For I gave my life; nobody took it. I willingly gave it and I would do it again if needed. But there is no need for such a thing, for what did I tell the Hebrews: For it is not possible that the blood of bulls and of goats, should take away sins. But this man, after he had offered one sacrifice for sins forever, sat down on the right hand of God. My Bride, I will not judge you according to your sins; for all that are in Christ are justified, yea sanctified, even made righteous in me, Christ Jesus, who will live and reign forever, for my kingdom has no end. So you are acquitted of your sins; therefore, you will not be in the judgment of sinners but the judgment of the righteous, for judgment begins at the house of God.

**Of restitution:** because I will repay, saith the Lord. So many of you have left houses, countries, families and sacrificed many, many things; and many among my Bride even gave their lives, they are my Martyrs. So there will be a restitution of the things sacrificed and even lost. For what was the end of Job: And the Lord turned the captivity of Job, when he prayed for his friends: also the Lord gave Job twice as much as he had before. And the voice of James my brother also states: Behold, we count them happy which endure. Ye have heard of the patience of Job, and have seen the end of the Lord: that the Lord is very pitiful and of tender mercy. And so is your Father, and so I am, for I am of the great I AM!

**Of loss:** for many will suffer loss, for I have stated regarding my judgment seat to the Corinthians: For we must all appear before the judgment-seat of Christ, that every one may receive the things done in his body, according to that he has done, whether it be good or bad. And again the Corinthians testify: Every man's work shall be made manifest. For the day shall declare it, because it shall be revealed by fire, and the fire shall try every man's work of what sort it is. If any man's work shall be burnt, he shall suffer loss: but he himself shall be saved: yet so, as by fire.

**Of great reward:** for the Corinthians speak again: Eye hath not seen, nor ear heard, neither have entered into the heart of man, the things which God hath prepared for them that love him. My faithful and chosen, you simply cannot comprehend the great celebrations and banquets prepared for you by my Father in the heavens; for you are coming in celebration, and great treasure is treasured up for you in the heavens. (For you are coming home to me, Christ Jesus, and our Father, Yahweh, the eternal God.) And again: if any man's work abide, which he hath built thereupon, he shall receive a reward. I have so many rewards to give, and my inheritance is with me; so fear not, for you will share in my inheritance; and where I am, so too shall you be, for the times of separation are over.

Crowns of reward and authority are waiting for you. I have listed some in scripture: the incorruptible crown, the crown of rejoicing, the crown of righteousness, the crown of glory, and the crown of life.

For those who have run the race, even the courses of service I set for them, will receive the incorruptible crown: for you will have had yourselves in subjection to my spirit, and you will have disciplined yourselves accordingly as any athlete would. For those who have won the race lawfully is the incorruptible crown.

There is a crown of rejoicing. For what is our hope, or joy, or crown of rejoicing? Are not even ye in the presence of our Lord Jesus Christ at his coming? For, ye are our glory and joy. And so we will have great joy, and you all will be in glory and glorified in me! For those who faithfully worked to convert and raise up your brethren is the crown of rejoicing.

There is the crown of righteousness for those who finish their courses and for those who love my appearing. So keep looking up, for I am near and have great expectation for my appearing. For great expectation for my appearing also brings great reward. For those with great expectation for my appearing is the crown of righteousness.

There is the crown of glory for those who have fed the flock of God. For Peter wrote: feed the flock of God which is among you, taking the oversight thereof, not by constraint, but willingly: not for filthy lucre, but of a ready mind. For those who didn't lord themselves over God's heritage and weren't motivated by filthy lucre and who have faithfully served me with humility and the proper heart of love is the crown of glory.

There is the crown of life that I will give to my martyrs, for those who suffer tribulation and persecution for my namesake and for those who have endured patiently the devil's wiles and schemes. For those who have faithfully overcome these things is the crown of life.

You will also be made like me, the last Adam and you will be like me, and you will see me as I am, and so too shall you be. Behold! I will re-create new bodies for you that are unlike anything you can imagine. See the records in scripture where I appeared to my faithful before being ascended into the heavens. I will tailor this body specifically to you, and it will carry your abilities, achievements, accomplishments; and you will be utterly amazed.

Do you not understand what I had Paul write to the Corinthians? There are also celestial bodies, and bodies terrestrial: But the glory of the celestial is one, and the glory of the terrestrial is another. There is one glory of the sun, another of the moon, and another of the stars: for one star is different from another star in glory. So also is the resurrection of the dead: it is sown in corruption, it is raised in incorruption. My children, you will have so many abilities you never dreamed of. Though each of you will be different from another, you will all move perfectly in me, for I will make you kings and priests before our God!

There will be so many things you will no longer be burdened with. There will be no more sickness, no more sin for you, no more death for you, no more fear, no worry; for you will all be re-created perfectly in me, Christ Jesus the Lord. So I say to you, my Bride, be an overcomer, for the rewards of the overcomer will I give, and it is beyond your wildest imaginations and dreams. For the tree of life, which bare twelve manner of fruits, and yielded her fruit every month: and the leaves of the tree were for the healing of the nations. And there shall be no more curse, but the throne of God, and of the Lamb shall be in it, and his servants shall serve him. And they shall see his face, and his name shall be in their foreheads. And there shall be no night there, and they need no candle, neither light of the sun, for the Lord God gives them light, and they shall reign forever and ever. So fear not, my faithful Bride, great reward is so soon to be realized for you. For God is not unrighteous, to forget your work and labor of love, which you have shewed toward his Name, in that you have ministered to the Saints, and do minister.

I am coming for you, sooner than you imagine.

I am your intercessor.

I am and so too shall you be, for you will see me as I am.

I am coming, and my reward is with me for the faithful.

I am he who will fully give you your inheritance, for so it is delivered to me.

I am he who will give you new bodies to replace the body of sin.

I am, for I am of the great I AM!

Look for my appearing in the clouds, as the signs will announce me before my brightness breaks across the sky. I, Yeshua HaMashiach, have sent these Words.