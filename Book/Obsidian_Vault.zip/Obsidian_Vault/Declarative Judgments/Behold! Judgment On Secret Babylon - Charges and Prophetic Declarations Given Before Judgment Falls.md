---
Order: "121"
Date: 2025-06-26
Image: "[[behold-judgment-on-secret-babylon.webp]]"
---
# Behold! Judgment On Secret Babylon: Charges and Prophetic Declarations Given Before Judgment Falls
![[behold-judgment-on-secret-babylon.webp]]
[[Declarative Judgments]] | June 26, 2025

**Judgment On Secret Babylon/America/United States**

>**Amos 2:4-8**  
Thus saith the Lord, For three transgressions of Judah, and for four, I will not turn to it, because they have cast away the Law of the Lord, and have not kept his commandments, and their lies caused them to err after the which their fathers have walked. Therefore will I send a fire upon Judah, and it shall devour the palaces of Jerusalem.
>
Thus saith the Lord, For three transgressions of Israel, and for four, I will not turn to it, because they sold the righteous for silver, and the poor for shoes. They gape over the head of the poor, in the dust of the earth, and pervert the ways of the meek: and a man and his father will go in to a maid, to dishonor mine holy Name. And they lie down upon clothes laid to pledge by every altar: and they drink the wine of the condemned in the house of their God.
>
**Amos 3:7-8**  
Surely the Lord God will do nothing, but he reveals his secret unto his servants the Prophets. The lion hath roared: who will not be afraid? the Lord God has spoken, who can but prophesy?

### Preamble
This document is a declarative judgment on Secret Babylon issued on June 26, 2025, as commanded by Yeshua HaMashiach and YHVH. These judgments are drawn from The Little Book of Revelation Chapter 10, which is also The Everlasting Gospel of Revelation chapter 14; revealed from March 2, 2024, to March 20, 2025. They are given by Yeshua HaMashiach and YHVH through the Spirit of Prophecy. The declarations serve as a warning for repentance before the full judgment falls, and they also function as a guide for events that will imminently occur.

Be it know, that in this capacity, I function as a judicial agent and messenger sent from the throne of Yahweh himself, under authority of Christ Jesus, who is also Yeshua HaMashiach, whom I serve. I am who and what the Lord has made me, and I am his Biblaridion, his little book, even the messenger described by the message that is bitter sweet and in my hand is an open little book. Selah. I do not come under my own authority or volition, and I have not self deployed, but I am sent with the Words the Lord has sown into my Spirit by his mighty hand to be released at his will and beckon call to be read and declared to both the Church, and also to Israel, but also to this sin filled and judged and dying world and especially to be given into the bosoms of the fallen ones for their times have come. Selah!

### Key Declaration given by Yeshua HaMashiach, who is also Christ Jesus
(June 26, 2025)

Hear, Hear one and all and bow your eyes, ears, and hearts in obedience to the Words of Adonai-YHVH, and Yeshua HaMashiach, who is also Christ Jesus. Hear my Words! Following are direct declarations concerning Secret Babylon, identified as the United States of America, and the unfolding of end-time events from both Yeshua HaMashiach, and especially Yahweh The Great I AM, for Strong is Adonai YHVH who judges the great harlot and her judgment has come!

Be it known, even so, which judgments are sent by way of Yeshua HaMashiach who is also Christ Jesus by the Spirit of Prophecy, given in the heart of my messenger, and servant whom I have commissioned and sent, and even hidden in my quiver for such a time as this, Selah!

Hear my Words my Body, My Church, and even my Bride! Hear my voice and stop yourselves at the sounds of my Words and hear their resonant authority echo into this world, for the earth is the Lords and the fullness thereof! Hear my Words my mighty 144,000 and understand my speech and ready yourselves for the appearing of your Lord, King, High Priest, and Messiah! For you will be taken into the heavens at that approaching trumpet blast, even that same mighty trumpet given into my might hands to sound so suddenly and unexpectedly now, Selah! Therefore, ready yourselves my wise virgins, because I am coming for you, and who is it who can stop me, I SAY WHO!

And you, O' defeated prince, even you who stands in defeated silence for you are a toothless lion. Hear my Words O' you Satans and understand my speech, for I will not be denied my possession and you are powerless and toothless to stop me, therefore, I rebuke you Satan, even the Lord of Lords and King of Kings, for you are allowed to do only what is permitted under my might hand and authority, even given by Adonai-Yahweh himself, therefore, silence yourselves and sit in rebuke at my voice, for you are ever rebellious, and yet you are subdued, defeated, and the times of your judgment has come, and you will not escape! Selah, little prince, Selah.

Behold! I am Yeshua HaMashiach, even the same Lord of Lords and King of Kings, for I am Christ Jesus, even the Lion of The Tribe of Judah who sends these Words by my messenger and servant, and by my messenger and servant have my Words been sent, Selah!

Even Words given by way of the Spirit of Prophecy via my messenger and servant by whom these Words have been sent to declare, even also in the mouths and by the hands of MY Little Flock! Selah.

Behold! A trumpet I hold in hand, given to sound at my command and at my signal a mighty shout!

And the world will go dark as the light of my appearing shines over the earth, for I will not share my glory with another!

Behold, I come! Behold, I come! Behold! I Come! Hear my declarations and hear my speech and tremble O' Secret Babylon. For as my light shatters the thick darkness, for darkness cannot overcome my light nor the lights of the world, who are empowered by Christ Jesus and sent in great authority by the Father of Lights and your times of full redemption have come. Therefore, look to me, Christ Jesus and keep your eyes up and open focused on your Lord Jesus Christ in all readiness and obedience. Arrange your affairs, for it will now be that suddenly on the earth, you are not.

And so I command you my loves, fill your lamps, and trim your wicks and take my fire and light your lamps ablaze to illumine yourselves in my Words, and understand that you are to wait by the wayside, for the Bridegroom does approach for both his Bride, and our guests. Selah.

Selah! My Loves, Selah, my Doves, for I do love you and I am coming and the hour is upon you.

Signed by my mighty hand, and in my own love and given in hand by my Messenger directly from me to the eyes, ears, and hearts of those to whom these Words are sent. Even Words I send to my Church, my Body, and even my Bride, and especially for my 144,000 because the times of your sealing has come, and a new song will I create within you that no man can learn. Selah.

Signed,
*Yeshua HaMashiach*  
*King of Kings, and Lord of Lords.*

### Key Declaration given by Adonai-YHVH, even The Great I AM
(June 26, 2025)

Behold! Hear my Words oh you inhabitants of the earth, even the Words of YHVH the great I AM, and understand my anger and my wrath is upon you oh dwellers of the earth, and if it were not for the sacrifice that I have eternally accepted, once all and forevermore, even that perfect passover offered by the high priest forever after the order of Melchizedek, even that son of man who offered his own sinless blood who is also that lamb of God, surely you would be as Sodom and Gomorrah and your judgment would have been instant and swift and sudden, Selah!

Behold Now! Look! Look and see he whom I send, even he who will now rise in great wrath bringing swift judgment on secret Babylon, even as suddenly on earth the faithful in Christ are not! Even that mighty Son of Man that I have made a life giving spirit and into whose mighty hands I have placed all things for fulfillment and the times of fulfillment have come and are now! Selah.

Nevertheless, judgment must begin at the house of Adonai-YHVH and will fall fully in the wrath of the lamb that will so suddenly now overtake the earth in great shaking and great judgment, even so as my wheat will be threshed and separated from the tares during Jacobs trouble and especially, so to will my wheat be separated eternally and forevermore from that serpent's tares, Selah!

For now are the times of harvest, and the times of harvest are now! Behold! Look! I have already declared and sent my Son, even that Son of Man who is also the Lord of Harvest; even with that mighty trumpet in hand, even as announced and declared previously in the Everlasting Gospel!

And even at that exact and specific moment etched eternally in my everlasting heart (for that moment has always been marked in my own heart which works all things after the counsel of my own will), even in my own heart where I hid the mystery of Yahweh!

Behold the times have come and we approach even that exact intersection where time and season meet, resulting in the faithful in Christ standing newly born into my throne room, clothed in brilliant glory and born again into everlasting lives of never ending reward, joy and glory for their love and faithfulness they have showed to Christ Jesus in their times of testing. Selah!

Therefore, know that the day of the Lord is about to fall hard upon you, oh inhabitants of the earth, even all you who think it but a light thing to reject my peace treaty, even Jesus the Nazarene, who is that lamb of God, even he who intercedes for you to this very second for all of you and so mightily have I accepted his Words of intercession as a sweet savor of sacrifice, wholly acceptable and accepted by YHVH the Great I AM forevermore! Selah!

Or you all would be as Sodom and Gomorrah and you all would be a sealed memory of judgments past, so understand my Love for I AM love and I AM the Father of Lights, and I do save by a mighty hand, even the mighty hand of the lamb of God, who is also the Lion of the Tribe of Judah who does roar in his intercession for those he loves, Amen.

Therefore, be it known, and tell them that the Great I AM is he who has sent these Words by my mighty messenger and servant and by my mighty messenger and servant have my Words been sent!

I AM he who sends my Words, even the Words of the Great I AM, even by way of Christ Jesus who is also Yeshua HaMashiach even by way of the Spirit of Prophecy so that judgment may be fully declared, even before sudden judgment suddenly falls.

So tell them The Great I AM, AM HE WHO sends these Words instead of sudden judgment, even gracious and life giving words for the obedient who will call on the name of Jesus as their Lord, even to their ends, Selah!

I AM Adonai YHVH, and I AM HE who sends these Words given in testimony against you, Oh Secret Babylon, even that great harlot of many states, even those United States that will suddenly fall to double judgment so suddenly now at the command of Christ Jesus who is also Yeshua HaMashiach.

Therefore, kiss the son lest he be angry and you perish from the way. You have no time for debate, except for quick obedience, so quickly Selah and repent, because you have no time!

### Summary
Be it known, that Secret Babylon is the United States Of America, even that great whore who sits on many waters and is a nation that was made, so the beast from the sea and the beast from the earth could rise from her ashes in their times of revealing. Even an adulterous nation, even a nation of fornication, a nation that is indeed a great harlot claiming herself a righteous follower of Jesus the Nazarene. But in truth is a nation whose builders are free from the true Rock of Foundation, even that great cornerstone of which the faithless stumble, even Jesus the Nazarene who is also Yeshua HaMashiach.

### Charges and Offenses

#### Operation War-seed / Mark of the Beast Development
1. O' Secret Babylon, with your witchcraft and enchantments you have seduced the world to accept poison, even a base layer and selective bio-weapon with which they have poisoned those who love the world with their sorceries and refuse repentance for I would heal them!

2. Understand that Operation War-seed and his snakebite was not the mark of the beast, but the mark of the beast will be disguised as medicine and is an full oath of allegiance to accept their technologies that will forever erase the name of Yahweh from who consents.

3. Even the serpents bite of which their system has already been rolled out and tested, and the masses have already been conditioned to accept their mark and their Operation War-seed was a success.

4. From you Mystery Babylon, have come these infernal technologies and by your lies and trickery have the masses been poisoned and your judgment lingers not.

#### Consent to evil

1. So many of you are so arrogant because you try to make me Lord while you still have a faithless heart, for with the heart man believes unto righteousness. So have faith that you may be saved; your faith will be indicated to all by your repudiation of sin and coming out of your filthy ways.

2. The wicked walk on every side, when the vilest men are exalted. But you still consent to the ways of the sodomite, and you help bring great evil on the land, to the point that you actually vote for child molesters to lead your lands. You lack even the most elementary level of discernment, and you do not follow my way; and if you persist, I will completely give you over to your vile affections for the destruction of the flesh that the spirit may be saved.

3. Let me open your eyes, you who are willingly ignorant and blind, you who sit in filth and darkness, rolling in the mire. You cannot give your consent to evil and think you are serving me, for I resisted evil and temptation until the very last drop of blood flowed from me onto the red earth, for I am the last Adam and I have been made a quickening spirit.

4. So many of you are blinded by good words and fair speeches and give your full consent to criminals and horrible people who prey on children. They molest children, they torture children for their own evil lusts: For so comes the wrath of God on Mystery Babylon, but so many of you persist in giving your consent to these brute beasts who are set aside for the eternal hellfires that will never be quenched.

5. Come out of her, my people, or you will share in her plagues and the awful judgment that is coming on her; and I have warned you. For what concord has Christ with Belial? If you share in her lies, you will share in her plagues; so completely separate yourselves in word and in deed, and do not agree with them in the least. Do not live careless, compromised lives; for I will punish all who do. You think because you have eternal life that you can't experience great loss and consequence? I will strip your rewards and give them away, and you will be the least in the kingdom of heaven if you persist, for so says Yeshua HaMashiach, the Bridegroom, to my Bride!

6. Be it known! Secret Babylon's enemies have no sympathy, no mercy, no grace, no remorse, and they utterly hate the inhabitants of Mystery Babylon for the awful sins she perpetrated on their lands. And all the while so many of you cheered on your unjust wars as you watched in amusement on your televisions, as you took great pleasure in the sins of your leaders. You have given your consent to your leaders whose sins you endorsed by vote, and so you will share in their judgment, for you have made yourselves worthy of a double portion of judgment, and it will overtake you suddenly.

7. Behold! All world leaders work together behind the scenes, and they all serve Satan. You do not have elected leaders, but you are given a false choice because you never selected those you think you elect by vote, but they are presented to you for your vote that they may gain your consent and your consent is sin because you cannot willingly choose the lesser evil and stand for me at the same time, that is delusion.

8. Secret Babylon, you willingly give your consent to your Satanic rulers, who know full well their plans and know full well they are in the process of fully destroying your once great nation and you.

9. For you Secret Babylon in your fornication and whoredoms, you sleep with the enemy.

10. For in such manner, you have lived deliciously while your leaders destroyed other nations with your consent.

11. For in such manner, Secret Babylon, you have cheered as your leaders brought calamity to the shores of countless nations in their unjust wars of which you were entertained as you watched on television.

12. Because it is the Synagogue of Satan that has made their choice and selected their new false Moshiach and Secret Babylon has once again given her consent to the dragon.

13. Even right in front of your very own eyes and by consent of your vote and by means of your slothful apathy, your entire nation has been dismantled in front of your very eyes.

And so shall it be done for it has been declared.

#### Golden Cup: Adulteries and Fornications, etc.

1. Be it known that judgment will fall on Babylon the Great shortly, and a terrible judgment it will be, but it is deserved. Oh, America, how long shall I endure you? You have gone from a nation of saints that served as a beacon to the world to come to me, to a nation of adulterous harlots.

2. I have separated my people from you, and the separation is nearly consummated as this age of grace comes to a close. Oh, America, why do you follow the evil one, accepting his worthless bribes over me, the eternal Christ, in all my splendor and glory. And the great whore has corrupted the earth with the golden cup in her hand, full of abominations and filthiness of her fornication.

3. Yet you, oh, America, who refuses the things of the spirit and despises their neighbors, you will now endure great judgment on your land, and Babylon the Great shall never be again. Babylon, you have become a nation of harlots who play the role with your skirts above your heads like a wild ass in heat waiting for the next passerby.

4. You have defiled yourselves with strange flesh, you have relished and loved your sins, and eternal judgment will fall on all the hard-hearted who count my sacrifice but a light and worthless thing to behold.

5. You have become a nation of evildoers and truce breakers who change wives like old garments for new until the new is soiled. Your great words you have spoken against my Father will be held to account.

6. For you were once a beacon of hope and a light to the world for a short season, but you have chosen greed, selfishness, and corruption as your bedfellows, oh, great harlot!

7. But you, oh, great harlot, you have prostituted yourself with many lovers for base greediness and the pleasures of sin.

8. Great destruction is on the harlot, Babylon the great, who has made the world drunk with her adulteries and fornications, for she has had many lovers. Those who will not separate themselves from her will share in her judgment, so why would you yet choose death over the life I have given you, paid for in my own sinless blood?

9. For you have become a nation of idolaters, a nation of warmongers, a nation who feasts on lies and who loves their delusions, a nation who has filled the earth with your abominations; and the nations drink of your golden cup which is full of abominations and filthiness of your fornication.

10. And the great whore has corrupted the earth with the golden cup in her hand, full of abominations and filthiness of her fornication.

11. You have lured the nations in your ways of evil and compromise, and have made them drunk with the filthiness of your fornication.

12. For you go from war to war, and you have utterly decimated the lands, both foreign and domestic.

13. The great whore who made war with all nations she was sent to conquer is now bound, and defenseless and ready to be fully conquered.

#### New Testament Rejection / Joining The Fallen Ones

1. You, Secret Babylon: you have denied your neighbor, and there is no fear of the Lord in your hearts. You have said, I am no widow, yet you are widowed and blind and deaf before me.

2. You have led my people away from me worldwide by the filth you have offered the nations to eat and drink, and you will be utterly cast down, and never again will you be.

3. For you, Secret Babylon, you have rejected my voice and set me, Jesus Christ the Righteous, aside for the pleasures of sin. For even the great warnings given over your nation in the heavens served only to provide entertainment for your faithless hearts and lustful eyes, and to you it was just another day as you lived deliciously in your sins that are leading you to your destruction. You should have repented!

4. Even all your apostate churches will be destroyed and that great harlot is to be cast down and the Queen of Heaven will burn! Behold! I have judged them all that are not of me, even all the fake churches who speak great lies in hypocrisy. Judgment Falls!

5. But you have shut your minds, you have stopped your ears, you have hardened your hearts, and you have opened your mouths in blasphemous unbelief, even blaspheming the peace treaty that Yahweh has offered you. For I Jesus Christ, I am your peace!

6. But, instead of making me Lord you instead use my holy name, even Jesus Christ, in vain as another word to express the filth in your own hearts.

7. You foolishly think you can prepare for the wrath to come by living off the land, someplace off the grid, except you will be utterly decimated, captured, killed, hunted, starved, sickened, and many plagues will befall all those who reject me Yeshua HaMashiach, for to reject me is to reject the great eternal God, even Yahweh himself and there will be no remedy.

8. Repent! Come out from among her and be ye separate! I, even the Lord Jesus Christ in the English tongue and Yeshua HaMashiach in Hebrew, have not provided a political solution and no world leader will arise for I have given none, and those who believe otherwise are sadly deceived.

9. Why do you yet seek world leaders instead of me, Christ Jesus? For I am your Lord, King, Messiah, and High Priest that Yahweh has provided, and I have purchased the earth and even the lives of the redeemed in my atoning sinless blood.

10. You have gone astray into the ways of Baal and you have become just as Satan has led you, for you are beyond all feeling in your nihilistic ways. Do what you will is the whole of their law that you have made your very own.

11. Truly, truly, to Secret Babylon and for many jubilees now have I sent my apostles, have I sent my prophets, have I sent my evangelists, have I sent my pastors, have I sent my teachers, have I sent my faithful disciples and brethren and I have even sent the widows in their solitude, and I have utterly poured out my spirit to the uttermost in these last days of grace and mercy!

12. But instead of the nations sitting in sack cloth and ashes they are entertained by the signs and warnings given of impending judgment as they take pictures and videos for their entertainment.

13. They have rejected my messengers who brought the light of my gospel of salvation, they have mocked and ridiculed my prophets, they have attacked my evangelists, they have corrupted my pastors, and persecuted and compromised my teachers.

14. Are you blind? Do you refuse to recognize their symbols so you can continue to sit in willful ignorance that your leaders are of the fallen ones? Do you not understand that your entertainers are of the fallen ones?

15. Do you not realize that they are not of the same nature as you, for many have forever altered themselves in their insanity and some are tares from birth and the Devil is their Father?

16. Yet you choose to willingly sit in darkness, and revel and bask in your sins as you roll in the mire with the pigs who have led you to the very gates of hell where many ignorantly parade themselves in vanity and pride.

17. Since she has given herself in service to her eternal enemies they will now bring about her eternal destruction for never again will Secret Babylon rise.

18. Behold! All the while secret Babylon's leaders have lied to the nations, claiming the great whore serves God, and speaks for me and called herself Christian, even while secretly serving the fallen ones since her beginning.

19. Secret Babylon, your times have come, and your days are at an end. I, Jesus the Nazarene, have shed countless tears over your impending destruction and I have sent signs above, and wonders in the skies, and signs in the earth and even many sudden cataclysms occur in real time and in her midst and still Secret Babylon stops her ears in stubborn rebellion.

20. But in place of a once great nation that respected the ways of Yahweh and where people followed Jesus the Nazarene and were not ashamed to love their neighbors will a wasteland remain where Secret Babylon will be laid waste in one hour because strong is the Lord God which judges her.

21. Since natural man loves darkness, I will now give him the darkness he so loves.

22. Even which judgments were announced in warning to the inhabitants of Secret Babylon, a warning they fully ignored as they faithlessly scoffed. Even my many, many warnings given in the mouths of my many prophets who have faithfully declared these Words of warning for many, many years now.

23. And so it is that Secret Babylon now declares her future to be free from Yahweh's judgment as they seek to escape as they scoff in their faithless ways.

24. Even a judgment they chose for themselves when they ignored my voice I sent by way of my apostles and prophets and servants both great and small: truly she has ignored one and all to her own demise and never again will she rise.

25. Because those who could have followed Jesus the Nazarene as their Lord have now been wooed into the arms of a deceiver because they love to live their delusions, thinking that as it is today, it was yesterday, and surely this great king will make me great once again!

26. But in truth she serves the fallen ones and her purposes are now over, and they do lust for her destruction so they can cover their crimes and so that their mangy shepherds may appear virtuous when they rise in order to hide their trap.

27. And the beast from the sea and the beast from the earth are evil abominations created for the destruction of mankind. Because they took up the Tabernacle of Moloch, and the star of their god Remphan, figures which they made, to worship them, and much much have they done that will be revealed fully at the proper times of revealing because every secret will come to light.

#### Entertained By Evil / Pharmakeia - Drugs / Pleasures of Sin

1. O' America: You foolishly think everything has gone back to normal, and the coming war can be watched on TV like the other wars your leaders unjustly waged. As you have been entertained by the death and destruction of other nations, so too will your nation be utterly destroyed, and your death and destruction will provide recompense to those destroyed with your consent.

2. Your time in the sun happened because for a season your Fathers followed the Son of God and kept my Words. But my Church age has come to a close because you traded the treasures of my mysteries, and even the well-being and love for my people have you merchandised for filthy lucre and acclaim before men.

3. For Mystery Babylon has led the nations in great sin and deception through her witchcraft and sorceries even her so-called ritualistic entertainment and for her abominable sorceries passed for medicines that are in truth deadly poison.

4. You sold yourselves in base greed and dishonesty, and you have forsaken me, even Jesus Christ, who died for the sins of the world. But you have refused my word, you have refused my reproof, you have refused my council, you have refused my ambassadors, you have refused my prophets, you have refused my apostles, and you have refused me, Jesus the Nazarene.

5. Oh, foolish idolaters of the land of Secret Babylon, if only you understood your scenario. If only you would've inclined your ears to my words for I have called, begged, pleaded, exhorted, shouted, shown signs above and signs in the earth and instead of clothing your heart with sackcloth, instead of sitting in the ashes of repentance you instead are entertained as if you were watching magic tricks.

6. You have unknowingly given your unborn to further the beast system, and the fallen ones have accepted your sacrifices. They have used the blood of the innocents as they always have in the making of their abominations, and so in the days of Noah so will it be. For when the restrainer is removed, then you will understand the sheer enormity and number of their abominations, for they will be released completely unrestrained.

#### Deliciously Sinful Lifestyles / Arrogance / Hardheartedness

1. For she lived deliciously in great sin; she sits in great arrogance thinking she can never fall and things will continue, yesterday as today, and tomorrow ever more the same and unchanging.

2. But in your arrogance and worldly ways, you have hardened your hearts against me and my salvation.

3. Oh, Secret Babylon, that you had understood the peace offering my Father has sent you, and you have now rejected me, Jesus the Nazarene, and it has happened according to the holy writings that evil men and seducers will wax worse and worse.

4. Sudden destruction is upon you and your enemies have readied themselves, yet you still live deliciously even though you are a nation in chains before me, Christ Jesus.

5. Secret Babylon you are a land of instant gratification, and you are most unwise.

6. Perhaps your national arrogance will blind your hearts to me, oh Mystery Babylon: even these United States. For you think you sit as a queen and no calamity will fall on you, and you say to yourselves, I am no widow!

7. For even your media seeks to soothe you to sleep and many sit in darkness blind to reality saying: I sit as a Queen and am no widow and will see no mourning.

8. Tomorrow will be as today, for today is as yesterday. In as much as she glorifies herself, and lives in pleasure, so much give to her torment and sorrow.

9. For in such manner, you have lived deliciously while your leaders destroyed other nations with your consent and with your money you are as guilty as these Edomite tares you have sold your posterity for the pleasures of sin.

10. Now comes your judgment in full Secret Babylon and you are a spectacle for all to see, yet you continue in ignorance and blindness saying in your hearts that calamity will never come on you.

#### Offenses Against The Innocents

1. Secret Babylon who traffics the little ones for merchandise into the hands of evil men, who will be stopped. It would be better that they had never been born than to be born and commit lawless and grievous sins against the children.

2. But you, oh, Secret Babylon the great, have desecrated my Father's bow of many colors that he gave to Noah and all mankind as a promise that he would never destroy the entire earth by water again, and he will keep his word. But you, oh, Mystery Babylon, will be laid waste in one hour.

3. And so I speak to you natural man, and I speak to you Secret Babylon. For you are guilty of the blood of the innocents, even those you have taken from the safety of their mother's womb. You have wrapped the smitings of the embryo in false justification and rationalization that make your selfish temptation to murder the innocents as common place as a doctor's visit, and your clinics of murder are a stench in my Father's nostrils, and a stench in my nostrils. For the blood of the innocents cries from the earth all the way to the throne of Yahweh in the heaven of heavens who sees all, even all you who seek to hide from his everlasting gaze.

4. For you have murdered the innocents, ignorantly thinking that this heinous act is a light thing. You have sold your unborn children for filthy lucre that you may advance your careers, even your careers in utter futility for they will all come to naught and your highly prized worldly endeavors of futility will all vanish in judgment never to be remembered. For you have willingly murdered your unborn children in an unwitting sacrifice to Moloch, and you murder your own unborn with great pride.

5. You have sacrificed the blood of the innocents on the altars of self gratification, and you shed your smitten embryos as if they were impure rags tossed aside into medical waste bins, and you have accounted the spirit of life that is in the blood an unholy thing and your judgment is on you. But your very own, even your unborn children, were out of style with your ever fading fashions and their lives were a hindrance to you fully enveloping yourselves in the pleasures of sins.

6. You justify and demand the blood of the innocents in your murderous political ideologies, and you knowingly have joined the fallen ones in their rebellion, for it was the Satans who taught the smitings of the embryo in the womb, even your precious murderous procedures you are so proud to protect and flaunt. And so the blood of the innocents cries from the earth and the weight of your sins have caused the earth to wobble like a drunken man, and great will be the shaking and great will be the fall! Babylon the Great is Fallen is Fallen!

7. For even your media seeks to soothe you to sleep and many sit in darkness blind to reality saying: I sit as a Queen and am no widow and will see no mourning.

8. Tomorrow will be as today, for today is as yesterday. In as much as she glorifies herself, and lives in pleasure, so much give to her torment and sorrow.

9. You have been led astray into the ways of the Canaanite, for they sacrificed their children as well, with great pride and joy, just as you continue to do! But in your arrogance you think you are nothing like those foolish and unlearned ancients and your ways are superior to these ancient barbarians, yet you practice the same.

10. But you foolishly think you are different, and you seek to use willing ignorance as a cloak, and you seek to rationalize and hide your sins in your spurious educations that have led you to judgment. For the weight of the innocent blood cries to the heavens even now and demands justice, and Yahweh has heard their cries!

11. Secret Babylon, you have sacrificed an entire generation of children who are now military aged men who could have defended you but instead now live on the streets of your disgusting cities and are hopelessly addicted to these sorceries and they have become zombies of the walking dead as these drugs rot their flesh even while they are still alive.

12. These evil beasts you serve are child molesters, and they collect and use the bodies of the little ones that they have killed to make their abominations and so all they destroy are given in sacrifice to their god.

#### Usury / Debt / Trafficking

1. I speak now to Secret Babylon though she is deaf, dumb, and blind and utterly bound in chains for her judgment. As they have prepared their surprise attack for many years now, and they have secured Secret Babylons destruction through usury, and other deceptive means.

2. Because even her monetary notes are nothing but an empty promise of debts incurred at the hands of your leaders who serve the money changers and secret Babylon is sold into the hands of their enemies by these crafty means. Do you not understand fractional reserve banking and fiat currency? Study to learn.

3. Oh Secret Babylon, since you have sold your children as surety in pledge for your debts so you could continue in the pleasures of sin (for even your money is usury), since you have murdered the innocents, and much more have you done.

4. You financed and supported and secretly coordinated the overthrow of many nations!

5. For the people of secret Babylon are sold into slavery by the mountainous debts she has incurred, for by usury the fallen ones work to destroy the masses.

6. And in so much as her people have pledged and signed their lives away for material gain and the pleasures of sin, so too will those whom they choose to enslave serve those they are indebted in forced labor and the mark will be enforced for all who survive, only take not the mark.

#### Communism / De Roth Schild / Martyrs

1. For from you, Secret Babylon, has gone forth the scourge of the Red Armies, even spreading world wide the red leaven of the great red Dragon, for you have served the fallen ones secretly since the beginning and continue to this day.

2. For you are guilty of the blood of the saints, and the blood of the martyrs cries from the earth for your judgment and if Yahweh were not to judge you he would have to repent to the nations he has taken in judgment in times past, even those who serve as a warning of your own impending judgment that you blatantly ignore.

3. From you, Secret Babylon, came the destruction brought on foreign lands by the Red Armies as the Edomites ingratiated themselves to the working class with their poisonous leaven, even their blasphemous manifesto financed by the Red Shield.

4. For the robber barons of times past, even your captains of industry of previous generations, (even those to whom you have sold your posterity) are the ones responsible for the scourge of the red armies.

5. Secret Babylon with her web of debt has financed and sponsored the Red Armies in their endeavors from the beginning, and Secret Babylon has been part of their network from the beginning as the Red Shield established itself worldwide.

6. Even the fiery dragon's breath that has come from the Red Shield, for they are the fallen ones who walk among you. (Communist Manifest)

7. From secret Babylon were their “revolutionary” leaders trained in secret for she sits on many waters, and they were sent secretly into foreign lands, even into Gog and Magog and their revolutions were great, and violent, and cruel and they now cover the earth.

8. They spread their satanic leaven across the lands of the east and utterly consumed all in their paths.

9. They went forth from Secret Babylon and have been a scourge on the earth, this violent overthrow of the old order has gone across the earth and now moves to its final stage.

10. And all nations who have been overthrown by the red armies with the backing of the Red Shield have been culled and persecuted and tortured and starved and murdered in the most grievous manner.

11. The saints who were in these lands you have martyred even untold millions. And all the while you danced and used Satans sorceries in celebration thinking it will never come to you, even the drugs given you for your deaths.

### Prophetic Trigger Event

Because They Received not the Love of the Truth, that they Might be Saved. (And it will yet be that his head will appear as it were wounded to death, but his deadly wound was healed, and all the world will wonder and follow the beast. And so this deceiver will rise.)

1. And many in Secret Babylon, even those who believe his lies and follow his good words and fair speeches are captivated and ensnared by a false peace where they imagine that their delicious and sinful lives will continue where today is as yesterday and tomorrow will be the same as today.

2. And many will scream, howl, and lament that their hope is now taken from them.

3. And they will fight their countrymen to the death and all the while their full surprise attack will be fully unleashed, even as my restrainer is lifted from the earth.

4. And Secret Babylon will fall to a double portion of judgment in one hour as many calamities fall.

5. And those who worship their black cubes will exhaust themselves in slaughter, even a slaughter that is brought about purposefully by great deception and from the ashes they will rise.

### Prophetic Judgments Underway / Soon to Fall

Then shall it happen, even as foretold, that sudden destruction will fall on Secret Babylon. And so it will be, even as declared and written!

1. Her coasts will be covered.

2. She shall be split along the middle from the gulf to the lakes.

3. Great fire will fall and their missiles will be launched.

4. And my mighty Angel will cast a great stone into the sea and Secret Babylons greatest city shall not escape, nor the city of Angels because truly, truly, will her sinful cities burn and be overthrown.

5. The armies of the beast will be released and they shall hunt every person and will cull multitudes, and they have orders to eliminate all who do not suit their purposes, or who could rise to fight them another day.

6. Hear my Words, my people, even all whom I am calling, and understand the times in which you live. For the world you now know will cease to exist, and in its place many wastelands will remain, even the ashes and ruins of Mystery Babylon, for war has come.

7. For as I snatch my Bride into the heavens, great calamity will engulf Secret Babylon, and she shall be destroyed in one hour, and in one hour shall she be destroyed, and nothing can change her fate, for Yahweh has so declared.

8. And so that finality will fully arrive when I gather the faithful of my Church to me in the clouds and when their departing shakes the entire world. It will literally shake the earth, and great shaking will consume Secret Babylon, and she will be rent up the middle as my saints depart.

9. She will be utterly burned with fire from the sky and their missiles will fall.

10. Her skirts will be covered with waters from the east and from the west! For a mighty angel will take up a stone like a great millstone, and cast it into the sea, saying, Thus with violence shall that great city Babylon be thrown down, and shall be found no more at all. For thus is it written and thus shall it be done!

11. For great is her judgment, and judgment has begun at the house of God.

Hear Me and Hear Me Well and Bow your Ears to the Words of Yeshua HaMashiach!

12. Secret Babylon, all your apostate churches will be destroyed, for I have judged them all that are not of me, even all the fake churches who speak great lies in hypocrisy.

13. Oh, Secret Babylon, your bridges will fall; your roads will be overturned, broken, and unpassable; your supply chains are already crumbling and will soon be desolate.

14. No provisions will be delivered to you, for nobody will come to your aid, and you will be alone in your hour of desolation, oh, great harlot.

15. You will have no happiness, and those who survive will find themselves fighting just to have a drink of water.

16. Starvation will overtake the land. And great pestilence will overtake you, and even the animals will attack, for the times are here.

17. The red armies that your treasonous government allowed into your borders will slay every man, woman, and child who does not fit their purposes. For they will kill and enslave all they find.

18. They are the armies of the beast that have been gathered from the four corners of the earth for this purpose, and the concealed beast and concealed false prophet have gathered them. They have no sympathy, no mercy, no grace, no remorse, and they utterly hate the inhabitants of Mystery Babylon for the awful sins your leaders have perpetrated on their lands.

19. As the gathering together happens, the restrainer is removed, and great destruction will overtake the earth, suddenly and in an instant. For as the restrainer is removed, nothing will remain to hinder the evil in the world and the lusts and evil passions of mankind.

20. Great war will break across the earth, and brother will once again rise to kill their brother, and great shall their destruction be.

21. Many nations will fall as Mystery Babylon, even that great whore who sits on many waters, will be made desolate in one hour. That great city, even that nation of many United States, will be utterly destroyed; for she has earned a double portion of judgment, and she is worthy.

22. Great fire will overtake her cities as their missiles fall!

23. Great shaking will occur, and that nation will split along the middle. Her coasts will be greatly flooded, and never will she rise again, for great are her sins and great is her judgment.

24. Secret Babylon! Behold! You are utterly surrounded by your enemies vessels, you have allowed millions and millions of the Red Armies, even the army of the beast to infiltrate your lands. You have allowed them to commit acts of sabotage, they have destroyed your supply chains, they have destroyed your food supplies, they have destroyed your economy, they have made camps to cull, torture and execute anyone who does not suit their purposes.

25. And suddenly will the fire fall!

26. Suddenly will the waters cover your skirts that are hiked above your waists, oh great harlot.

27. Suddenly violent shaking will come upon you and will tear you asunder.

28. Suddenly the command will be given and millions will break across the land to kill every and any living human that does not suit their purposes. They will have no mercy, they have no remorse, they cannot be pleaded with, they have no compassion, but they serve Satan and will fulfill the purposes given for them to fulfill, for they will fulfill the wrath of God on Mystery Babylon and never again will she rise.

29. Behold! I tell you a thing before it happens. Secret Babylon, even these United States who once served as a beacon of light to the world, is in chains even reserved for fiery judgment.

30. Her judgment and desolation will come suddenly and in one hour will she be burned with fire, in one hour will she be torn asunder, in one hour will her skirts be covered in water even from the east and even from the west.

31. The red armies of the beast have already invaded her borders and are already staging and awaiting orders, and they will kill every man, woman, and child who does not serve their purposes. For the beast and false prophet who are about to be revealed already work in tandem for the destruction of secret Babylon, and they are already in her borders.

32. When my Bride is taken into the heavens and the restrainer is removed sudden destruction will fall suddenly across the world and all nations that once pretended to be Christian will cease to exist in the manner they currently exist, yet there will be a remaining people that are conquered and culled.

33. Mystery Babylon will fall first and suddenly at the same time as their surprise attack commences, but she will not ever rise ever again, for Yahweh has declared a double portion of judgment on her.

34. And a wasteland will remain, though a remnant will be saved, for whosoever calls on the name of the Lord and loves not their lives to the end shall be saved. So understand the times you live and understand the coming order of events and understand that there is nothing that can change these events, for what Yahweh has declared can no one change!

35. The ten horns have prepared their surprise attack and their attack approaches and is at your door. For even your media seeks to soothe you to sleep and many sit in darkness blind to reality saying: I sit as a Queen and am no widow and will see no mourning.

36. Therefore shall her plagues come at one day, death, and sorrow, and famine, and she shall be burnt with fire: for Yahweh who condemns her, is the Almighty God and there is none greater and there is nothing that can stop El Shaddai's mighty hand!

37. And so the sun will soon rise on a day of calamity you do not expect, and that day is nearer than you imagine. And that day will bring utter destruction on Mystery Babylon, for she has a double portion of judgment declared against her.

38. Hear my words for I speak as if it is already happened for nothing will change, slow, hinder, nor stop Yahweh's judgments from crashing onto the earth.

39. In one hour she will be burned with fire, some of her cities will burn, some of her cities will be violently flooded, her towers will fall and break in many pieces, her bridges will fall, and much shaking will occur.

40. The earth will be torn asunder violently and much land will be covered over in violent waters.

41. Her skirts will be covered from the east and from the west in great waves and up the middle rushing waves and violent shaking.

42. Of what remains will be a wasteland and never again will she rise, for this nation of many states and many cities shall never rise again and great will be her fall!

43. For the earth is the Lord's and the fullness thereof, and all aspects of her evil influence will forever be erased from the nations during Daniel's seventieth week, for so I will cleanse the earth in my wrath. I, Christ Jesus, the Lion of the Tribe of Judah, have declared these words, and preparation for their fulfillment is already underway and will suddenly be fulfilled in one hour.

44. They have used the blood of the innocents as they always have in the making of their abominations, and so in the days of Noah so will it be. For when the restrainer is removed, then you will understand the sheer enormity and number of their abominations, for they will be released completely unrestrained.

45. You have sacrificed the blood of the innocents and the abominations they have made will hound you and pursue you to the ends of the earth for they have always eaten the inhabitants of the land and the evil tares made by the hands of the fallen ones have no forgiveness for their sins and crimes against Yahweh, for mankind is made in the image of Yahweh and to desecrate the life of the flesh that is in the blood is grave sin and will not be overlooked for those who have refused my salvation during my times of grace and mercy. Behold! I send giants to fulfill my wrath!

46. The armies of the great red dragon do surround you secret Babylon and are fully within your borders. For even your traitorous Zionist leaders have sold you for a morsel of bread to your enemies and also to advance their satanic schemes.

47. And El Shaddai has allowed these madmen to continue, even putting it into their hearts to fulfill his purposes.

48. Also, understand that the enemies of Secret Babylon have been given her resources and wealth fully, and Secret Babylon is now a looted shell of its former self that has no chance for survival, and never again will this sinful and abominable nation rise, even a nation that was made secretly by the fallen ones that served the unintended purpose of providing a refuge for the persecuted who served Christ Jesus (because even Yahweh's enemies obey his voice) and for the intended purpose that the beast from the sea and the beast from the earth could rise and be selected for their purposes by the fallen ones in their times.

49. Strong is El Shaddai who judges you, oh scarlet whore who sits arrogantly in pleasure even as you are stripped of all glory, stripped of all delicacies, stripped even of your homes for I have given your homes and lands into the hands of your enemies. Even into the hands of the beast and the false prophet, for they work hand in hand for your utter destruction.

50. Hear my words and understand what is happening right now, for their surprise attack is underway.

51. I speak now to Secret Babylon though she is deaf, dumb, and blind and utterly bound in chains for her judgment. As they have prepared their surprise attack for many years now, and they have secured Secret Babylons destruction through usury, and other deceptive means.

52. Since she has given herself in service to her eternal enemies they will now bring about her eternal destruction for never again will Secret Babylon rise.

53. I will now give you fully into their hands and Yahweh has even declared a double portion of judgment on you secret Babylon. And many of your children will be sent to their work and reeducation camps and many will be taken to foreign lands for the dragon is allowed claim on the lands and the people who have rejected me, Yeshua HaMashiach, in favor of Barabbas their false Messiah.

54. You no longer have the ability or resources to fight a war, for I, even Christ Jesus, have stripped your military might and given it into the hands of your enemies. Your once great cities now sit in ruins of crime and poverty, of which your entertainers and you both boast in great pride. The Edomites have long since removed their factories from your lands, and you lack the manufacturing power you once had and even the raw materials to produce what you need to fight your never-ending wars.

55. Behold! The great whore, even Secret Babylon a nation of many states, is that woman showed to John the Revelator, even that woman drunken with the blood of the Saints, and with the blood of my Martyrs and your judgment is upon you.

56. Secret Babylon, you have sacrificed an entire generation of children who are now military aged men who could have defended you but instead now live on the streets of your disgusting cities and are hopelessly addicted to these sorceries and they have become zombies of the walking dead as these drugs rot their flesh even while they are still alive.

57. Now comes your judgment in full Secret Babylon and you are a spectacle for all to see, even though you have cheered as your leaders brought calamity to the shores of countless nations in their unjust wars of which you were entertained as you watched on television.

58. You have been divided amongst your enemies and they already enjoy the spoils of war even before the missiles have fallen. For Secret Babylons defeat is guaranteed and given by Yahweh himself and nothing will stop her utter ruin and never again will she rise.

59. Her once great cities that were examples of hard work and production and the abundance of El Shaddai now sit in ruins with her posterity addicted to drugs and living in filth on her disgusting streets.

60. She is made naked as her defenses are off shored even further and her wealth and strength is given into the hands of her Edomite enemies who pretend they are allies.

61. The great whore who made war with all nations she was sent to conquer is now bound, and defenseless and ready to be fully conquered.

62. And all flesh will be consumed in misery and all who are captured will be culled and those who are able to serve the beast's purposes will be carried away into slavery and the rest will be killed, though a remnant will survive.

63. She is ablaze and there are many fires already in her borders and in the lands of her neighbors to the north who share in her plagues. And yet these are just the birth pangs and are not the final judgments but a warning to all of their impending destruction.

64. So understand, that as I suddenly gather the faithful to safety and reward, so too will sudden destruction fall on mystery Babylon as the restrainer is fully removed. Hear my words and understand my voice because the restrainer is the only thing keeping the destructive lusts of the fallen ones restrained until he who restrains no longer restrains and is taken from the midst.

65. And so famine will descend on the lands, for Secret Babylon has caused famine on many lands and now famine will be her dinner guest, for so she has given and so doubly she will now receive.

66. Water will be a sought after commodity, and many waters will be made bitter from the destruction and fires of war and from the plagues of the unburied that will pollute the land.

67. And so will secret Babylon be utterly split along the middle and the waters will rush where there was once fertile dry land, even the heart lands will be flooded up the center.

68. And so God's mercy and grace will be utterly removed from the earth when the restrainer is suddenly removed and destruction will marry destruction, for these are the times of destruction where Satan's kingdom will be fully judged and fully destroyed, but first they will serve Yahweh's purposes in utterly consuming mystery Babylon and so will she be utterly burnt and consumed in many raging fires that will engulf and begin to cleanse the land.

69. And so this once great nation of states and many cites will fall suddenly, and the angel of destruction currently hovers over her greatest and largest city on the eastern waters and her pride and joy and envy of the world will be utterly destroyed never to rise again.

70. And so too will her destruction be shared by all those who have joined her, for she is that great whore who sits on many waters that are peoples and multitudes and nations and tongues.

71. At which time the restrainer is removed, they will execute their secret attack that they have planned and coordinated for many years now, for so is given into their hands to accomplish, and Secret Babylon will utterly be destroyed in one hour.

72. And the ten horns will destroy the great harlot because they hate the whore, and they shall make her desolate and naked and will eat her flesh and will burn her with fire.

73. And great shaking will come on the earth, and she will be split, and the waters will cover her coasts, and the waters will cover her heart, and she will be divided asunder.

74. Then a mighty Angel took up a stone like a great millstone, and cast it into the sea, saying, With such violence shall that great city Babylon be cast, and shall be found no more.

75. And so will it be that this once great nation, of which I have redeemed many, will now be taken in judgment, even as my Church and my Bride are taken into the heavens, where I have prepared for them a place of safety and refuge where they will receive their inheritance. And never again shall Secret Babylon be, and her greatest city that arrogantly sits as though nothing will ever change will fall completely along with her, never to rise again.

76. Truly, truly, all of her sinful and disgusting cities will fall, and her towers will tumble, and great fires and destruction will make her roads impassable.

77. Then will the red armies, even the armies of the beast that he has imported for her destruction, be unleashed on what remains, and they will consume her flesh.

78. Those that remain are sold into slavery by usury because the leaders of Secret Babylon have betrayed her citizens and have given them as collateral, and payment is now due.

79. And so the mangy shepherds have delivered Secret Babylon into the hands of her enemies, for so they are sent. They have made the whore naked, for so was given them to accomplish, for even the enemies of Yahweh obey his voice. Understand they have purposely left her military might in foreign lands and given her secrets to the ten horns so they may rule in strength. It is the ten horns who will give their power to the beast, for so is given them to accomplish.

80. The great whore has fought endless and futile wars designed to wear down her strength.

81. Secret Babylon has by design instigated war with the Bear in order to grind down her strength and might so that she is now left naked and defenseless, and into the red dragon's hands is she now given as spoil.

82. And every facet of her empire that sits on many waters will likewise be given as spoil into their hands. Understand that they are at the ready and will move suddenly to execute in unison their worldwide attack, and on all fronts will they attack in swift destruction, and a very short victory will they have before judgment falls in great wrath on the earth.

83. They will have their surprise attack, and the time of their attack is now.

84. The ten kings have colluded among themselves, and they have surely set their hands to the ready; they have staged, they have prepared, and they have covered the earth in their lies, that they may seem justified in the genocide of millions and millions that will fall to the tragedy and pains of their war.

85. When the restrainer is removed, Secret Babylon will be destroyed as written. Even in one hour will her fate become final, and great misery and destruction will consume the earth, and great shaking will occur, and it will be plain to the world that the day of the Lord has come, though the fallen ones will lie and present themselves as benevolent aliens, and they will endeavor to cover my appearing for the faithful in war and a fake alien invasion.

86. Understand that there is no more time remaining to warn, no more time remaining to plead, no more time remaining to reason with secret Babylon because her judgment is final and cannot be altered.

87. In place of a once great nation that respected the ways of Yahweh and where people followed Jesus the Nazarene and were not ashamed to love their neighbors will a wasteland remain where Secret Babylon will be laid waste in one hour because strong is the Lord God which judges her.

88. Because it is the Synagogue of Satan that has made their choice and selected their new false Moshiach and Secret Babylon has once again given her consent to the dragon, and so they will fully be given into the hands of the dragon who empowers them to execute wrath and judgment that is even sent as a double portion from Yahweh himself, of which judgment lingers not and is imminent and so they have chosen to themselves their own destruction.

89. Because Secret Babylon is fully woven into the spider's web, and she cannot escape, and Secret Babylon is in chains awaiting her final judgment. And they will continue to spoil, rob, murder, plunder and take by force her prosperity and her posterity for so is given them to accomplish and a wasteland will remain where they will plunder the earth further for the resources they so lust.

90. And then sudden destruction will fall suddenly, and in one hour will she be destroyed. Again I say, that war will suddenly break free across the earth, and fire will fall, and many missiles will they send for her destruction.

91. Her greatest city will burn and great waves of destruction will overtake her east and west coasts.

92. The earth will violently shake, and she will be split up the middle and where a once prosperous heartland stood, waters will remain that will cleave her in two, and she will fully fall in her double portion of judgment.

93. Sudden destruction will overtake Secret Babylon who sits on many waters, which are peoples, and multitudes, and nations, and tongues. And as the ashes of war smolder and the current arrangement of nations is decimated and realigned to suit their purposes, the fallen one's final beast system will rise in full.

94. And yet these two evil beasts have spoiled Secret Babylon, even before her destruction has come and have taken her military might and abundance for the dragon's purposes in their coming final beast system. Because the war that is to come will devour Secret Babylon, and truly she will be destroyed in one hour, for so has been declared of Yahweh, even the Great I AM.

95. Even so, they will split the earth and great shaking will occur, and they have engineered her destruction that they may gather the resources of which they lust that are buried in the earth.

96. Even the resources with which they need to power and expand the fallen one's technologies; even wherewith the world is currently mesmerized and enchanted in its strong delusion, kept enthralled to their frequencies and manipulations wherewith they are stimulated and controlled.

97. And of the people that will remain after the coming destruction of Secret Babylon; the beast from the earth and the beast from the sea have imported an army of invaders and executioners into her borders whose numbers are as a mighty plague of locusts, and they will be unleashed at their signal!

98. Because these are the armies of the beast who have been gathered for Secret Babylon's destruction.

99. Many of these are from the lands of the dragon and the lands of the bear, and they will do as Secret Babylon secretly did to them in jubilees past: They will kill every man, woman and child with no remorse who does not suit their purposes and many who are allowed to remain alive will be forced into their slave camps to work in their mines to their deaths.

100. And they will toil and labor till their last breath; because all that Secret Babylon has secretly done to others will now be done openly to her in her judgment and punishment.

101. Yet these two evil beasts, even who currently work hand in hand for the full destruction of secret Babylon, even the beast from the sea and the beast from the earth; even these two who have both been ruling heads of Secret Babylon and who have ruled with many great and empty promises wherewith these two mangy shepherds have shepherded the lost sheep of Secret Babylon promising false material prosperity and abundance to those they shepherd. And in their hands and by their schemes they have surely arranged and will execute what has been given into the hands of the dragon to accomplish.

102. Because Secret Babylon, even that great whore who sits on many waters is a nation that was made, so these two evil beasts could rise from her ashes in their times of revealing. Even an adulterous nation, even a nation of fornication, a nation that is indeed a great harlot claiming herself a righteous follower of Jesus the Nazarene. But in truth is a nation whose builders are free from the true Rock of Foundation, even that great cornerstone of which the faithless stumble, even Jesus the Nazarene who is also Yeshua HaMashiach.

103. Judgment falls! Judgment falls! Judgment falls! Behold! Judgment falls on Secret Babylon, even as promised! And so it is coming to pass that judgment falls on Secret Babylon, and her pleasures are taken from her in judgment.

104. For in one hour so great riches are come to desolation. Therefore, riches and pleasures are being taken from the earth and will not return until my millennial kingdom has come and this is done in judgment and punishment on those who lusted after these delicacies with the intent that they may come to repentance should they turn with full faith in their hearts to Jesus the Nazarene by calling on my name at the expense of their own lives to obtain salvation from a judged and dying world that truly, truly will come to utter destruction and judgment and none shall escape except through the grace and mercy of Yahweh given in the face of Christ Jesus the resurrected and ascended King of Righteousness!

105. So I give you to understand, that Secret Babylon's judgment has been prepared and they stand at the ready.

106. Yet so will it be that when the restrainer is taken the evil that is latent within mankind due to the serpent's wiles will now go unrestrained and madness will overtake the earth as brother will kill brother and countrymen will fight their countrymen and extreme chaos and war will overtake the earth. And yet this event is the destruction and judgment of mystery Babylon, but the seals are set to be loosed, and the horseman will ride!

So says Yeshua HaMashiach, who is also Christ Jesus!

### Events

#### Waves / Water / Flood

- Great waves will overtake your coasts, and I will reward you according to your works, and great judgment is against you.

- Natural disasters will abound, and the earth shall quake, and great waves will crash on Mystery Babylon; for the earth will be ripped apart in many places.

- Her skirts will be covered from the east and from the west in great waves and up the middle rushing waves and violent shaking.

- Great waves of destruction will overtake her east and west coasts.

- Waters will remain that will cleave her in two, and she will fully fall in her double portion of judgment.

- (Even a judgment they chose for themselves when they ignored my voice I sent by way of my apostles and prophets and servants both great and small: truly she has ignored one and all to her own demise and never again will she rise. So says Yeshua HaMashiach.)

- You will fall greatly as the waters come on you.

- Her skirts will be covered with waters from the east and from the west! For a mighty angel will take up a stone like a great millstone, and cast it into the sea, saying, Thus with violence shall that great city Babylon be thrown down, and shall be found no more at all. For thus is it written and thus shall it be done!

- Suddenly will the waters cover your skirts that are hiked above your waists, oh great harlot.

-  And in one hour will her skirts be covered in water even from the east and even from the west.

- The earth will be torn asunder violently and much land will be covered over in violent waters.

- Her skirts will be covered from the east and from the west in great waves and up the middle rushing waves and violent shaking.

- Yet many of her cities along her sinful coasts will fall to the waters that will come suddenly and will crash on her shores flooding inland for many, many miles and this will happen from the east and from the west.

- And so will secret Babylon be utterly split along the middle and the waters will rush where there was once fertile dry land, even the heart lands will be flooded up the center.

- And the waters will cover her coasts, and the waters will cover her heart, and she will be divided asunder.

- And where a once prosperous heartland stood, waters will remain that will cleave her in two.

- Her coasts will be greatly flooded, and never will she rise again, for great are her sins and great is her judgment.

- And some of her cities will be violently flooded.

#### Fire
- Great fire will come upon you.
- Fire will burn you utterly and will cleanse the evildoers from the land, and my captives will be freed, and nothing can stop what is about to happen.
- Great fire will overtake the land, and the merchants will stand afar off for fear of her torment. Great destruction is on the harlot.
- They will utterly burn Secret Babylon with fire, and whoever does not succumb to the flames.
- She will be utterly burned with fire from the sky as the missiles will fall.
- And so her judgment will fall suddenly. Great fire will overtake her cities as missiles fall.
- And the ten horns, these shall hate the whore, and shall make her desolate, and naked, and shall eat her flesh, and burn her with fire.
- So know, that I, even I Christ Jesus, will utterly consume Mystery Babylon with fire and in one hour will your destruction come, for it is written and what Yahweh has declared can no one change.
- Suddenly will the fire fall!
- Her judgment and desolation will come suddenly and in one hour will she be burned with fire!
- The ten horns which you saw upon the beast, these shall hate the whore, and shall make her desolate, and naked, and shall eat her flesh, and burn her with fire.
- Therefore shall her plagues come at one day, death, and sorrow, and famine, and she shall be burnt with fire: for Yahweh who condemns her, is the Almighty God and there is none greater and there is nothing that can stop El Shaddai's mighty hand!
- In one hour she will be burned with fire, some of her cities will burn.
- For God has put it into the hearts of the ten horns to fulfill his will, and they hate the whore, and will continue to make her desolate and naked, and shall eat her flesh, and continue to burn her with fire.
- And she is ablaze and there are many fires already in her borders and in the lands of her neighbors to the north who share in her plagues. And yet these are just the birth pangs and are not the final judgments but a warning to all of their impending destruction.
- And so fire will fall suddenly on Secret Babylon and her cities will be destroyed.
- Fire will fall suddenly as the missiles crash across her lands, leaving her burnt and naked.
- For these are the times of destruction where Satan's kingdom will be fully judged and fully destroyed, but first they will serve Yahweh's purposes in utterly consuming mystery Babylon and so will she be utterly burnt and consumed in many raging fires that will engulf and begin to cleanse the land.
- Therefore, shall her plagues come at one day, death, and sorrow, and famine, and she shall be burnt with fire: for God which condemns her, is a strong Lord!
- And great fires and destruction will make her roads impassable.
- And fire will fall, and many missiles will they send for her destruction.
- And burn her with fire. For God hath put in their hearts to fulfill his will, and to agree, and give their kingdom unto the beast, until the words of God shall be fulfilled.
- Great fire will fall and their missiles will be launched.
- And the people who willingly followed them in pleasure will fall to the fires of war, pestilence, death and destruction.
- Therefore, shall her plagues come at one day, death, and sorrow, and famine, and she shall be burnt with fire: for that God which condemns her, is a strong Lord.
- And great fires and destruction will make her roads impassable.
- And then sudden destruction will fall suddenly, and in one hour will she be destroyed. Again I say, that war will suddenly break free across the earth, and fire will fall, and many missiles will they send for her destruction. Her greatest city will burn.
- And burn her with fire. For God hath put in their hearts to fulfill his will, and to agree, and give their kingdom unto the beast, until the words of God shall be fulfilled.
- Then shall it happen, even as foretold, that sudden destruction will fall on Secret Babylon and her coasts will be covered, she shall be split along the middle from the gulf to the lakes, great fire will fall and their missiles will be launched.
#### Shaking / Earth Quakes
- As the shaking comes on you.
- Great shaking will flatten you; your towers will fall; your infrastructure will disappear in ruins.
- And so that finality will fully arrive when I gather the faithful of my Church to me in the clouds and when their departing shakes the entire world. It will literally shake the earth, and great shaking will consume Secret Babylon, and she will be rent up the middle as my saints depart.
- Great shaking will occur, and that nation will split along the middle.
- Suddenly violent shaking will come upon you and will tear you asunder.
- And so the blood of the innocents cries from the earth and the weight of your sins have caused the earth to wobble like a drunken man, and great will be the shaking and great will be the fall!
- Babylon the Great is Fallen is Fallen!
- Her towers will fall and break in many pieces, her bridges will fall, and much shaking will occur. The earth will be torn asunder violently.
- Her skirts will be covered from the east and from the west in great waves and up the middle rushing waves and violent shaking. Of what remains will be a wasteland and never again will she rise, for this nation of many states and many cities shall never rise again and great will be her fall!
- And great shaking will come on the earth, and she will be split, and the waters will cover her coasts, and the waters will cover her heart, and she will be divided asunder.
- When the restrainer is removed, Secret Babylon will be destroyed as written. Even in one hour will her fate become final, and great misery and destruction will consume the earth, and great shaking will occur.
- Even so, they will split the earth and great shaking will occur, and they have engineered her destruction that they may gather the resources of which they lust that are buried in the earth. Even the resources with which they need to power and expand the fallen one's technologies; even wherewith the world is currently mesmerized and enchanted in its strong delusion, kept enthralled to their frequencies and manipulations wherewith they are stimulated and controlled.
- Even so, they will split the earth and great shaking will occur, and they have engineered her destruction that they may gather the resources of which they lust that are buried in the earth. Even the resources with which they need to power and expand the fallen one's technologies; even wherewith the world is currently mesmerized and enchanted in its strong delusion, kept enthralled to their frequencies and manipulations wherewith they are stimulated and controlled.
- Great shaking and total war will destroy many nations and cities and towns and the earth will be divided in many places, and the restrainer shall be suddenly removed, and the ice shall fall, and their abominations will be unleashed and the abyss will be opened and Satans full kingdom will be unleashed and united in evil in their war against the saints wherewith they shall overcome them even as written.
- And so will secret Babylon be utterly split along the middle and the waters will rush where there was once fertile dry land, even the heart lands will be flooded up the center.
- And great shaking will come on the earth, and she will be split, and the waters will cover her coasts, and the waters will cover her heart, and she will be divided asunder.
- The earth will violently shake, and she will be split up the middle and where a once prosperous heartland stood, waters will remain that will cleave her in two, and she will fully fall in her double portion of judgment.
- She shall be split along the middle from the gulf to the lakes.
- Even so, they will split the earth and great shaking will occur, and they have engineered her destruction that they may gather the resources of which they lust that are buried in the earth. Even the resources with which they need to power and expand the fallen one's technologies; even wherewith the world is currently mesmerized and enchanted in its strong delusion, kept enthralled to their frequencies and manipulations wherewith they are stimulated and controlled.
- And your land shall be cleaved asunder.
- The earth will violently shake, and she will be split up the middle and where a once prosperous heartland stood, waters will remain that will cleave her in two, and she will fully fall in her double portion of judgment.

#### Army / Armies
- Secret Babylon: You are utterly surrounded by your enemies vessels, you have allowed millions and millions of the Red Armies, even the army of the beast to infiltrate your lands.
- And as this final attack takes place, the hordes of the Red Army will be fully unleashed on the remaining inhabitants of the land. They will kill all who resist and will kill many who do not resist. For the people of secret Babylon are sold into slavery by the mountainous debts she has incurred, for by usury the fallen ones work to destroy the masses.
- (And in so much as her people have pledged and signed their lives away for material gain and the pleasures of sin, so too will those whom they choose to enslave serve those they are indebted in forced labor and the mark will be enforced for all who survive, only take not the mark.)
- And of the people that will remain after the coming destruction of Secret Babylon; the beast from the earth and the beast from the sea have imported an army of invaders and executioners into her borders whose numbers are as a mighty plague of locusts, and they will be unleashed at their signal!
- Because these are the armies of the beast who have been gathered for Secret Babylon's destruction. Many of these are from the lands of the dragon and the lands of the bear, and they will do as Secret Babylon secretly did to them in jubilees past: They will kill every man, woman and child with no remorse who does not suit their purposes and many who are allowed to remain alive will be forced into their slave camps to work in their mines to their deaths.
- The armies of the great red dragon do surround you secret Babylon and are fully within your borders.
- The red armies are already here, and they await their orders; for they plan a surprise attack, and many will be taken. The armies of the evil one will take everything from the land for their own and from those who reject me. They will steal your land, your homes, your posterity; and many lives will be lost in unbelief. War is coming from without as many nations are aligned against you; and they have your leaders' consent, and your leaders work for your deaths.
- You are utterly surrounded by your enemies vessels, you have allowed millions and millions of the Red Armies, even the army of the beast to infiltrate your lands. You have allowed them to commit acts of sabotage, they have destroyed your supply chains, they have destroyed your food supplies, they have destroyed your economy, they have made camps to cull, torture and execute anyone who does not suit their purposes.
- (Understand that even then anyone who calls on my name, even Jesus Christ, to the end shall be saved. Those who make their choice of refusal final will eternally live with the consequences of faithlessness in the great flames prepared for the devil and his angels, for there is no other choice but the second death.)
- The red armies of the beast have already invaded her borders and are already staging and awaiting orders, and they will kill every man, woman, and child who does not serve their purposes.
- The armies of the great red dragon do surround you secret Babylon and are fully within your borders. For even your traitorous Zionist leaders have sold you for a morsel of bread to your enemies and also to advance their satanic schemes.
- For you go from war to war, and you have utterly decimated the lands, both foreign and domestic. For from you, Secret Babylon, has gone forth the scourge of the Red Armies, even spreading world wide the red leaven of the great red Dragon, for you have served the fallen ones secretly since the beginning and continue to this day.
- From you, Secret Babylon, came the destruction brought on foreign lands by the Red Armies as the Edomites ingratiated themselves to the working class with their poisonous leaven, even their blasphemous manifesto financed by the Red Shield.
- For the robber barons of times past, even your captains of industry of previous generations, (even those to whom you have sold your posterity) are the ones responsible for the scourge of the red armies. Secret Babylon with her web of debt has financed and sponsored the Red Armies in their endeavors from the beginning, and Secret Babylon has been part of their network from the beginning as the Red Shield established itself worldwide. Even the fiery dragon's breath that has come from the Red Shield, for they are the fallen ones who walk among you.
- And all nations who have been overthrown by the red armies with the backing of the Red Shield have been culled and persecuted and tortured and starved and murdered in the most grievous manner. The saints who were in these lands you have martyred even untold millions.
- (And all the while you danced and used Satans sorceries in celebration thinking it will never come to you, even the drugs given you for your deaths. Secret Babylon, you have sacrificed an entire generation of children who are now military aged men who could have defended you but instead now live on the streets of your disgusting cities and are hopelessly addicted to these sorceries and they have become zombies of the walking dead as these drugs rot their flesh even while they are still alive.)
- Then will the red armies, even the armies of the beast that he has imported for her destruction, be unleashed on what remains, and they will consume her flesh.
- Because these are the armies of the beast who have been gathered for Secret Babylon's destruction. Many of these are from the lands of the dragon and the lands of the bear, and they will do as Secret Babylon secretly did to them in jubilees past: They will kill every man, woman and child with no remorse who does not suit their purposes and many who are allowed to remain alive will be forced into their slave camps to work in their mines to their deaths.
- The armies of the beast will be released and they shall hunt every person and will cull multitudes, and they have orders to eliminate all who do not suit their purposes, or who could rise to fight them another day.

#### Enemies / Usury / Debt / slavery
- Your walls are already breached, and millions have come for you to take from you what I have given them, because I will fatten the hand of your enemies in your judgment.
- Sudden destruction is upon you and your enemies have readied themselves, yet you still live deliciously even though you are a nation in chains before me, Christ Jesus.
- You are utterly surrounded by your enemies vessels, you have allowed millions and millions of the Red Armies, even the army of the beast to infiltrate your lands. You have allowed them to commit acts of sabotage, they have destroyed your supply chains, they have destroyed your food supplies, they have destroyed your economy, they have made camps to cull, torture and execute anyone who does not suit their purposes.

### Closing I AM Statement from YHVH, The Great I AM:

I AM he who is from everlasting to everlasting and there is none greater than the Great I AM!

I AM the Everlasting God of Righteousness who faints not, and I ask, is there anything too hard for my mighty hand to accomplish?

I AM he, even YHVH the Great I AM, who swears by my own name and does certify fully in eternal truth that Yeshua HaMashiach did fulfill the law of Moses as the perfect Passover for all time that I provided perfectly with my own hand, so there is no more need for sacrifice.

I AM YHVH the great I AM and I swear by my own name that it is I who raised Jesus the Nazarene from the dead after he sacrificed of himself as the lamb of God, even a sacrifice that I accepted for all time and forever more for the redemption of Adam as a new man in Christ Jesus who is Yeshua HaMashiach your true Messiah!

And I AM he who does certify the authenticity of these Words that I have sent in The Everlasting Gospel that has been revealed by myself, and Yeshua HaMashiach to our mighty messenger who has been prepared by Yeshua HaMashiach in much chastisement and purification for my eternal purposes and faithfully has he returned to Yeshua HaMashiach and so he is restored!

### 14 Closing I am Statement from Yeshua HaMashiach: 14 for the Order of 144 Thousand. Selah!

I am the Word of God made flesh who dwells amongst you.

I am he who sits with billow in hand stoking the flames of purification.

I am he who removes the unbelief.

I am he who removes your faithless ways.

I am he who fully purifies you of all manner of fleshly corruption.

I am he who has called you to virtue and truth.

I am standing over you, offering you a hand back on your feet. Will you accept my offer?

I am the Lion of the Tribe of Judah.

I am King of Kings and Lord of Lords!

I am he who speaks of things to come as if they have already occurred.

I am the Word made flesh who dwells among you by my holy spirit that is born within you forevermore.

I am forevermore the high priest after the order of Melchizedek.

I am he who is a light to the Gentiles and is the savior of the nations for all who have made me Lord.

I am he whom the Great I AM has sent for the salvation of Israel, for a remnant of Jacob will yet be saved.

I Yeshua HaMashiach have sent these Words by my servant, and by my servant have these Words been sent! The Season is Now!