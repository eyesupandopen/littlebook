---
Order: "32"
Date: 2024-04-12
Image: "[[every-secret-will-come-to-light.webp]]"
---
# Every Secret Will Come to Light!
![[every-secret-will-come-to-light.webp]]
[[In the Works of Peter]] | April 12, 2024

Have you not read? Every secret will come to light. Have you not read? Every hidden thing will be exposed. Have you not read? Every heart's intent will come before me. Every tongue will confess to me, says the Righteous Lord and Righteous King, who rules in righteousness. Oh, my people, why do you choose the error of Adam and Eve, who from the beginning tried to hide their shame in their own works, for they sewed fig leaves together and made themselves aprons. Yet, God saw what happened and knew they would stumble before he created them. And what did the Father do for them? HE MADE them coats of skins and clothed them apart from their own works.

Why do you think you can hide your sins from me, my children? I see all of you and know you better than you know yourselves. Stop listening to the wayward shepherds who preach another Jesus; indeed in broken cisterns they offer lukewarm water to a lukewarm church wrapped in false sincerity and so-called positive thinking. They lie to you with self-help Christianity, telling you out-of-context truths such as God loves you the way you are. While the Father's love is undying and white-hot for his children, true Christianity preaches repentance and remission of sins, sins that are confessed in honesty with a pure heart which leads to salvation and wholeness. Yet, many in my Church rationalize and justify their sins. They rationalize in their own philosophies and seek a false perch, looking down on their brethren in arrogant pretense as they wrap their iniquities in their own false justification. Is this not the knowledge of Satan when he offered the forbidden fruit to the mother of all the living? Are these not the works of the flesh?

I ask you a question; all of you know the answer. What are the wages of sin? What does the Holy Scripture declare those wages to be? Is it not death? Yet, many of you feel that your sins are justified and are even part of you and what makes you unique, as you abuse my grace. In dying, you shall die. Even though you have eternal life in me, and I will forgive you all and will not cast you away if you remain in me, in dying you shall die.

From your first breath, you are perishing due to the sin nature in you.

When you continue in sin and sow to the flesh, you will reap corruption every time, because in dying you shall die. Sin will eventually kill every aspect of your lives and even your flesh to your last breath if you continue. Not only that, but you will lose your reward and stand in shame in the heavenlies at my judgment seat as the wood, hay, and stubble you treasured to yourselves burns to nothing in front of you, and you will suffer loss as I will strip your reward and give it to another, for I am the righteous judge. Why come to me in repentance and then return to your own vomit? What do you accomplish? Do you not understand that you can't serve me and Satan at the same time? If you sin, you are the servant of sin until you come clean with me, and every tongue will confess! Why do you desire to return to the weak and beggarly elements? All they will ever do is seek to kill you as they carry you away as plunder.

Know that the evil spirits brag over my children they are able to capture. Why do you choose to bring shame to your own name and make yourselves a laughingstock? You have forgotten your first love, and many of you are involved in Christian witchcraft and self-help Christianity, a version of faith without me, for I will not enter the Laodicean church but stand at the door and knock. I say to you plainly, your positive thinking controls nothing, and you are deceived.

Are the pleasures of sin for a short season that important to you? Do you not understand that I will reward you richly with heavenly things for your troubles and trials? I will recompense what you sacrifice for me in my name. Return to your first love, my children, and come to me and come out of Babylon. For the great harlot's days are numbered, and there will be no remedy for her; therefore, come out from her, my people, and be ye separate that you share not in her plagues. Depart from lust and the works of the flesh. For all that is in the world, the lust of the flesh, and the lust of the eyes, and the pride of life, is not of the Father, but is of the world and the world is passing away.

Flee fornication and share not in their shame and consequence. My children, it's as if you are doing the deed yourselves when you draw pleasure from perverseness and depravity. Forsake your greedy ways, for I will punish those who heap riches to themselves, and soon your money will be worthless. Push into my spirit, for my spirit is life and peace. Depart from evil and sin not! Reap the fruit of the spirit in me, for I have empowered you over your sins if you will come clean with me. Do you think you can hide something from my gaze? I have been empowered to see, and I and my Father are one in unity and purpose. It is impossible to hide, and it is impossible to hide your sins from me. Many of you have no idea how ridiculous you appear when you self-righteously act as if you have no sin, and yet your eyes burn for lust that sets your loins ablaze.

Understand that the thief uses many vices and ploys against you. If you follow my will to resist and turn to me, I am an ever present help in time of need and I will succor you, I will protect you, I will purge you and make a way to escape the many temptations you face, but you have to resist with everything in you. It means nothing when you say you are sorry and go right back to your vomit, but you would cringe to see a dog do the same, yet in your arrogance you think you are different, so don't act like a wild dog.

Sin is sin. The only way to beat sin is by my atoning blood and to rest in me. The spirit I have poured on you will empower you. I have created a new nature in you, and if you but ask, I will create a clean heart in you.

So stop your filthy mouths, close your lustful eyes in prayer, and depart from iniquity, and I will cleanse you. Yes, I will cleanse you fully as white as fresh snow when you confess and also change and turn from your filthy ways. As many as I love, I rebuke; and as many as I love, I chastise. What father chastises not his own child? Though many do just that, these are not my ways, and these are not the ways of my Father. Since God deals with you as children, he will also chastise you as children; for if he chastises you not, then you are not his children but bastards.

But you are his children, so give ear to my words and endure chastisement, and heed the warnings, for life and happiness awaits. No chastisement seems joyous at the time, but it will lead to the peaceable fruits of righteousness. Come to me, and I will purge you of your old ways, and I will teach you my ways that you may walk in righteousness and peace. Help your brethren and become an example of repentance, for in your stand you will break many chains and many bonds, even the bonds you grasp in your own hands and hold tightly to yourself. I counsel you to let them all go. Sin leads to bondage, and it pays death; therefore, come out of her, that you share not in her judgments.

I am holy, so be ye holy.

I am he that justifies my children.

I am he that sanctifies my children.

I am he that makes my children righteous in me.

I am he that redeems my children in my grace and mercy.

I am he that washes you clean in my sinless blood.

I am the righteous judge.

Time is short, my children, and your courses will very soon be finished. Think not that unrighteousness will enter my kingdom, or that you will stand before me in your sins and carry off reward. Only those who overcome will stand with me. You will be saved, but why would you want to suffer the loss of the greatness I have prepared for you, for you cannot even comprehend what you are sacrificing for your own lusts.

Come to me, for I am rich in mercy.

Come to me, for my grace will sustain you.

Come to me, for I am he that walks among the seven lampstands and he that will preserve your reward if you but come to me in humility, forsaking your worthless pride. I love you, my children, and very soon you will be with me. Behold! I stand at the door and knock for just a short time longer. I tell you these things not to condemn you, but so that you may have oil in your lamps and be ready for me when I come. I am coming at a time you do not expect, and I am coming sooner than you can fathom. Time is almost up.