---
Order: "33"
Date: 2024-04-10
Image: "[[be-of-good-cheer.webp]]"
---
# Be Of Good Cheer!
![[be-of-good-cheer.webp]]
[[In the Works of Peter]] | April 10, 2024

My little ones, be of good cheer; have I not overcome the wicked one and redeemed you by my own blood? Why should you be discouraged? Why are you heavy of heart; do you think I have forgotten you? No, instead of looking to your own understanding, seek my wisdom, which is from above; for by godly wisdom shall you be led, so forsake her not! Doesn't wisdom still cry aloud in the streets? So fear not and be of good cheer, for I have overcome and you too will overcome, so as yet by my own blood. Allow my peace to comfort your hearts and allow my words to soothe your soul, for I am with you.

Who will separate you from my love? Will peril, or will the sword, or will famine separate you? I say not, and look and know that you are secure in me. Know that I have sealed you with my Father's seal, and that seal cannot be broken or stripped away from you, so remain in me, your Lord, strength, and redeemer. Behold! I have purchased you in my own blood, I have called you by name, I have sealed you according to your faith in my name, and whosoever believes therein shall be saved by faith, for the just shall live by faith! Keep your hope alive and let it strengthen you, and add endurance to your love and faith, for you are saved to hope. Great hope and great expectation are yours, for I have declared it.

Why are you cast down and sad? Behold! I have overcome, and soon you will be with me, and you will see me with your own eyes, and you will know as you are known.

Look! Says the great Lord, the mighty Lord who is Lord of Lords. Look to me in your sadness and troubles. I know your hearts, and I know full well that you love me and long to be with me as I long to be with you; only faint not. Answer me this, the short time left in your wait — will it compare to eternity with me, my bride? No, your sufferings and tribulation on earth are not worthy to compare to the glory that I am about to reveal in you, for you will be as I am, and you will see me as I am, so do not allow your hearts to be troubled. Understand your times and always be on the ready, for my appearing will happen suddenly, and it will exceed your expectations.

Behold, my children! The world will know that I love you and that you are mine, and Satan will cause great deception to deceive those who perish, but it will not come near you. No, judgment is not for you, and neither is my wrath. Understand, my children, that in me, you are righteous, not righteous in your own works, but righteous in the righteousness I have clothed you with. Cast not away the garments I have clothed you in, and quench not my spirit. Though it is the end times, I will pour out my spirit, and your sons and daughters shall prophesy, and your old men will dream dreams. There is yet work to be done, and my final move in these times of grace will outpace the day of Pentecost when I first poured out on my chosen the spirit I received of my Father. Great works are at your fingertips and there are many yet to be saved, so do my work and minister to my children and seek my lost sheep. Ask of me and I will commission you, as I have enabled you with a great enabling and I have given gifts unto men. Who can stand against you, though you have this treasure in earthen vessels? Why do you yet doubt me? In your own weakness is my strength perfected in you. Therefore, abound in the work of the Lord, my children.

Check my Holy Word, for as I raised the dead, so you can do the same. Anoint your eyes with eye salve that you may see the many mighty healings I did to set the captives free when I came to my own; so too can you do the same. Have I not stated that he that believes on me, he shall do the same works, and greater works shall he do because I have gone to my Father and your Father, and to my God and your God: You are kings and priests before me and you are seated in the heavenlies, so why do you still doubt? Have but the faith as a grain of mustard seed, for it is a very small seed that produces a mighty tree, so shall you be if you continue steadfast in me.

Why do you confuse my words and ignore the details in my speech? I lie not: you can do what I have commissioned you to accomplish if you remain faithful. Speak my Word with great authority and boldness. Say to those mountains, Be cast into the sea! My words are truth and life, so believe not the lies of the wayward shepherds who say you cannot do what I am telling you. Take the lesson. You want to heal the sick? Command the sickness to depart in my name, and say the words with faith in me and faith in the words I will give you. Speak it to become so, for life and death are in the power of the tongue; how powerful are your tongues as you speak the power of God and command the impossible.

Speak with boldness. Speak with confidence. Speak in faith, doubting nothing; for I have sent you and empowered you. Why do you ask a spirit to depart in my name with trepidation on your lips? Command it to leave in my name with all boldness and confidence, because greater is he that is in you than he that is in the world. Behold! The evil spirits fear you and shrink from your words, so why do you fear the weak and beggarly elements that are defeated and awaiting the fire? Fear not, but only believe!

Go forth in my name and do my mighty works. Remember your first love and rest in the rest I have given you. Cease from your own labor and burdens, and take my yoke upon you; for my yoke is easy, and my burden is light. Do the works I have prepared for you and walk in them, for in so doing you will save many from the flames, and fruit will abound to your account. The time is at hand, my bride, and the end of your course is near, nearer than you think. But hear me, my children; hear me, my bride! Intercede while there is yet time. Heal the sick while the Son shines in your life, empowering you with my power.

Seek my lost sheep; call them, for there are many yet to save in these final seconds of refreshing. For soon you will come to your inheritance in me, and you will realize your full life in me; for your lives are hidden in me, and when I will appear, so too will the fullness of life that the Father has bestowed on you in me. I love you dearly, my little ones, so love the lost in the same manner. Do not judge them or disparage their plight, for they are overcome by Satan as you once were; so remember the deliverance I did for you and give it to the ones in need. Though many will resist you, do not stop until my sheep are gathered, for very soon my wheat will be gathered safely in my barn. Those who deny my appearing deny me and deny my word; so strengthen yourselves in my word and stop believing the thieves, for thieves are also liars.

I am he that endured to his last breath, striving against sin with my own sinless blood.

I am he that was raised the third day and ascended to my Father.

I am he that walked amongst my disciples and apostles for forty days, even seen above five hundred brethren at one time, and seen and handled by many, for a spirit has not flesh and blood.

I am he that was taken up, while they watched me, into the clouds.

I am he whose brightness is brighter than the sun, for I reflect my Father's glory.

I am about to reveal great glory in you.

I am with you always, even until the end of the age.