---
Order: "41"
Date: 2024-03-17
Image: "[[the-earth-is-the-lords.webp]]"
---
# The Earth is The Lords!
![[the-earth-is-the-lords.webp]]
[[In the Works of John The Baptist]] | March 17, 2024

The earth is the Lord's and the fullness thereof: Though the usurper and thief have set his claim, he can only do what my Father has given for his hand to accomplish in his holy plan of redemption for mankind. Fear him not! He must continue for a season, as his hour has come; but fear him not, my righteous, faithful ones; fear him not! Have I not given you victory over him? Jacob's trouble is not for my faithful, and the ones who have come to me in the times of refreshing shall be highly exalted in the very throne room of God. Yea, my faithful people, great reward is treasured up for you on account of your faithfulness that you have faithfully shown toward me.

I have made you kings and priests to me in my coming Kingdom and before our Father, so stand fast, my children, in these final minutes of the final hour. My appearing is at hand, and your redemption is as near as your next breath, so stand faithful before me, knowing that I am your strength and salvation and you are sealed in me, as I have purchased you with my blood as I gave my life for you that you may be reconciled in love to our Father in heaven. I long for the day, and our Father longs for the day, when you stand before him in the bodies I have for you in your full redemption, and there will be no more a curse on my chosen.

Oh, man, who are you to stake a claim on my inheritance? Know you not that I purchased the earth and all therein with my own sinless blood? The earth is the Lord's and the fullness thereof, and righteousness is coming to the earth! Though you would destroy the earth and make it a desolate habitation for your abominable abominations, though you would swear fealty to my eternal enemy and seek your own torment for temporal base gain, you understand not that you make war against your own souls as you treasure up wrath against the day of wrath, when I shall reward every man according to his works.

Oh, foolish man, you say to yourself that your gods will save you, when they have no reward for you, and you are deceived and deceiving others in your delusions. Your gods of stone cannot speak; your idols in your hearts cannot hear; they cannot save you, oh, idolatrous one! It would be better for you that you should have never been born, for the wrath of God abides on you for your hard-hearted ways. Though your mouth has become an open sepulcher, spewing great things against the Lord of Lords, your words will come home to you, and your evil desires shall be turned upon you in your coming eternal punishment. Oh, that you had turned to me and accepted salvation from your present fallen state. Oh, that you had simply confessed my name from your lying lips. But no, you have loved your lies, and you have loved your delusions, and you have sold your souls to eternal damnation for a morsel of bread that cannot sustain you; for I am the bread of life! Your calamity shall come on you suddenly and without remedy. I will rend your nation; I will destroy your commerce and economy; in an instant I will snatch your wealth from you; truly, I will strip all pleasure from you in an instant, and your poverty and misery will consume you. The wrath of the Lamb approaches, when my vengeance that my Father has given to me shall be executed, for I am worthy to open the books and loose the seals.

You have mistakenly assumed my long-suffering and patience for weakness and neglect. You have said in your hearts: Where is the Lord? He is but an ancient myth. We have learned so much more than the saving ways of the Lord; in my knowledge, I am superior, for my technologies are mightier than some old book of contradictions and legends. Truly, many of you do not even believe that I ever came in the first place and shed my redeeming blood for the sins and salvation of mankind. It is better that you had not even been born, for the wrath you have treasured against your own soul will come upon you without remedy, and you will know full well your sins, and your utter misery and desolation will be your spouse. You will eat of your own filth, and your filthy ways will ever be with you, as you are buried in the fruits of wrath in your evil deeds that you have committed in great evil against my name. Depart from me; I know you not!

Who is he among you that falsely speaks in my name? You claim to know me, to represent me; some of you even think you can command me to do your very bidding and bring material gain to yourselves by your own good works, which are nothing more than filthy rags. How can you speak for me when you know me not? How can you speak for me when I have not given you the words? How can you speak for me to my people when I have not sent you? No, you have sent yourselves, peddling your corrupt wares for greedy base gain and for the adoration of men that you so desperately crave. You fool! Depart from me, as I never knew you!

You false prophets, who declare me Lord in name only; you false prophets, who speak great lies against your own souls; you shall utterly perish, and I will spew you out of my mouth. Therefore, repent! Return to me and I will return to you. Come out from among your idols and depart from your accursed cults and come to me and make me your Lord! Oh, that you would accept my salvation; yet you persist in your sins and excuse your own guilt as you quote my sacred Word from an empty heart, a heart full of adultery and fornication as you run to your idols. Who will save you from my wrath when you have led astray my people for your own base gain? Had you made me Lord as your lying mouths have declared, I would have saved you from your sins and made you whole in me. I would have pastored the hurts the evil one inflicts on you. I would have given you a path and a purpose and sent you on the earth with mouths full of blessings and truth as you would have led my people to me.

Think not that I need your help, as I am the true Lord of heaven and earth, and I am King of Kings and Lord of Lords. Those I have ordained in ministry are given a great honor to speak for me and care for my flock, an honor that I will reward with eternal treasures; yet, you have exchanged me for a false version of Christ. Another Jesus have you made for yourselves; you have loved the spirit of antichrist, and you have sinned eternally against your own souls by declaring me absent from my own Church that I purchased with my own blood, a sin you shall not recover from. Truly, all of these things and more will come on you in my wrath unless you humble yourselves before me and truly make me Lord by repenting in sackcloth and ashes. Do not rationalize away my words as you play semantics with my speech! Repent! Seat yourself in sackcloth and ashes and weep over your iniquities, and I will receive you to me and restore you to your reward that I would otherwise bestow on another.

I am the righteous Lord.

I am the savior of the world, even King of Kings and Lord of Lords.

I am he who walks among the seven lampstands and who commands the seven angels of the seven churches.

I am the lamb who was slain from the foundation of the world, and in me is life eternal.

I hold the keys to death and hell, and my Father has shared his throne with me, that I may share my throne with my faithful, called, and chosen. I walk with my people and I talk with my people, and I am the true shepherd who shepherds that flock my Father has given me. You are the apple of my eye, my faithful, and you are the apple of my Father's eye, and for this time and hour have you been restored to righteousness and true holiness.

The hour approaches, and you should cease from your own works and watch for my appearing, for it is about to come on the world as I gather you from the four corners of the earth. Truly, truly, I will gather my true sheep into my barn before the storms come that will destroy this present evil world, for Satan's kingdom will be torn asunder and totally destroyed to make way for the righteous Lord who will rule the earth from the throne of David in righteousness and true holiness, and I will greatly empower my bride in the coming kingdom, for they are my kings and priests, and they shall rule in true righteousness and holiness, for my reward is in my hand for the faithful.

I am your strength and salvation, and you are sealed in me.

I am the bread of life!

I am worthy to open the books and loose the seals.

I am the true lord of heaven and earth.

I am the king of kings.

I am the righteous Lord.

I am the savior of the world, the King of Kings and Lord of Lords.

I am he who walks among the seven lamp stands and who commands the seven angels of the seven churches.

I am the lamb who was slain from the foundation of the world.

I am the true shepherd who shepherds that flock my Father has given me.