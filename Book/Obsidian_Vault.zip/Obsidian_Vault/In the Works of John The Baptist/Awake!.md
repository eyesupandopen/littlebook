---
Order: "52"
Date: 2024-03-02
Image: "[[awake.webp]]"
---
# Awake!
![[awake.webp]]
[[In the Works of John The Baptist]] | March 2, 2024

Awake! Awake! Awake! My people, awake, for I the Lord Jesus Christ am calling my people back to me. Do not resist the voice of the Lord when I call you and offer mercy, forgiveness, and peace. There is no peace in this world; though they shall cry peace and safety, do not believe them. There is no peace outside of me, Jesus Christ. Awake! Awaken your brethren! Many will fall to the left and to the right, but it will not come near you if you stay faithful to my voice, the voice of the Lord.

My Bride shall be taken to the inner chambers of the heavens in peace and safety, as they have washed their garments in my blood, the blood of the Lamb! Those who reject me and count the sacrifice of Jesus Christ, the perfect Passover, for the sins of mankind as a worthless thing will have no peace. Repent and turn from your sins, as this is the last hour. Do not give yourselves any longer to rationalization and unbelief, as no man can stand before me, Jesus Christ, unless they have washed their garments in the blood of the lamb and purified themselves from sin.

Come out from among her, my people, as the great whore shall be judged suddenly and without remedy. The time of Jacob's trouble is nearly here, and great judgment and calamity will come to the earth. You have an escape right on your lips if you will confess me, Jesus the Nazarene, as your Lord and believe that God raised me from the dead. Are your sins so precious to you? Are the pleasures of sin important enough to risk eternity in outer darkness? Do you desire the lake of fire? Call on the Lord while I may be found, and call to me when I will hear you, because the hour approaches when no man can work.

Though the Lord will send his prophets during the time of Jacob's trouble, where will you stand when the Lord raptures his people? Who will minister to you when the Church is taken from the midst? There will be a dearth of scripture in the land, and you will have to find Christ by enduring till your last breath, if you are blessed enough to make it that far. Repent and return to the Lord! Come out from her, my people, and be ye separate. I stand at the door and knock.

The spirit of prophecy has descended on my people over the world, as I promised in holy scripture.

>**Acts 2:16-21**  
But this is that which was spoken by the Prophet Joel;  
And it shall come to pass in the last days (saith God) I will pour out of my Spirit upon all flesh: and your sons and your daughters shall prophesy, and your young men shall see visions, and your old men shall dream dreams:
>
And on my servants and on my handmaidens I will pour out in those days of my Spirit, and they shall prophesy: And I will shew wonders in heaven above, and signs in the earth beneath: blood, and fire, and vapor of smoke: The sun shall be turned into darkness, and the moon into blood, before that great and notable day of the Lord come. And it shall come to pass, that whosoever shall call on the name of the Lord shall be saved.