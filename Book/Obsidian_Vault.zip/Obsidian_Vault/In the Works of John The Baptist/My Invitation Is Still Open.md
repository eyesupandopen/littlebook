---
Order: "49"
Date: 2024-03-07
Image: "[[my-invitation-is-still-open.webp]]"
---
# My Invitation Is Still Open
![[my-invitation-is-still-open.webp]]
[[In the Works of John The Baptist]] | March 7, 2024

The word of the Lord came upon me, and I present it without adding or taking away anything.

Behold! My invitation is still open! Come all, and come whomever may, for I the Lord Jesus Christ am set for your rock of defense and am a strong tower for you. There is no other name given under heaven whereby men may be saved, except my name, Jesus Christ. I am the chief cornerstone they reject, thinking they are free. Freedom is found nowhere except in me, Christ Jesus. Why do you let the hirelings lead you astray? Why do you let the worthless ones corrupt you from the single-mindedness found in me? Many paths lead to destruction. But I am the way, the truth, and the life, the true way to the Father that brings salvation and freedom: salvation because I offer remission of sins through my redeeming blood, and freedom because the son shall make you truly free indeed.

Why are you weary, my people? Why do you faint? Have I not provided you rest? Have I not overcome all things, making a way for you to follow my victory and share in my sufferings? Only through accepting my sacrifice of myself can you be redeemed from certain destruction. Only through my blood do you have remission of sins, and through my broken body is healing given, and a new body shall I give you on that day even to my faithful and chosen. For so has your Lord provided for you. I made a path where there was no path: a path in the wilderness that culminates with your glorification, if you will but cease from sin.

This world is corrupt, its knowledge is corrupt, its sciences are spurious, and a web of deceit ensnares my people, leading them out of the way I have chosen for them. Do you not understand that I have called you? That I have chosen you? Do you not understand that you must die to self to find life in me, as your true life is hid in me, the faithful Lord? When I shall appear, so too will you appear in glory; therefore, with singleness of heart, follow me. With singleness of mind, come to me in humble faith. It takes only faith as a grain of mustard seed, and the tree will grow greater than them all.

The times of the Gentiles are drawing to a close, yet Jacob will be saved so as even by fire. In an all-consuming fire shall this world be judged. Verily, the prince of this world is judged and is a defeated enemy. Judgment has been pronounced on him, his kingdom, his followers, and the world he tried to take from my Father. Truly, he desires to rob you of your inheritance, as I have laid a path for you to share in the glory of my throne as I share in the glory of my Father's throne. I went to prepare a place for you. Do you not understand there are many mansions in my Father's house? Is anything too hard for me? Have my promises failed you? Or have you been led astray from the single-hearted purpose that I have given you? Why do you yet choose your own ways?

Repent, oh, my children! Confess your sins to me and even the sins of your fathers, as I will hear you in the time appointed. I will glorify you; I will give you newness of life in me. Come to me and receive garments of fine linen! Come to me and receive a new name that I will give you on a stone I have made for you. Let no man beguile you of your reward. Great destruction and calamity is at your door. The world is about to shift into unrestrained evil. The abyss will be opened, and Satan's full kingdom will be unleashed. I will shake the heavens, I will shake the sea, great shaking will come over the earth. The son of perdition walks among you as a wolf in sheep's clothing, waiting for his satanic kingship to come into full view so that he may be revealed in his time. Follow him not!

Run to me, my children, as great wrath and great destruction shall come upon your nation, and many nations shall soon be shaken to the ground. Oh, that you would turn to me and understand your times. Out of the coming destruction the false one will rise, as he seduces many with a lying tongue and will show many false wonders and lying signs. Even now his armies have walked into your cities and filled your streets. Fear them not. Some of them will achieve salvation. The chaff shall be given to the fires. Great trouble shall come on this world suddenly. Suddenly shall their calamity fall on them, and they shall not escape. It is the last hour. Be ye not partakers of her plagues; come out of her, my people, as the great whore has been judged, and her calamity shall come upon her in one hour. The great merchants who trafficked her sorceries shall fall into great distress, and the smoke of her burning will be for all to see. The world's merchants will bewail her calamity from afar off.

But I have plans for you, my people. Your life is hid in me. Though I have tested you for a season, I have refined you as gold in a refiner's fire. Come out of her! Awake to righteousness and sin not. Purify yourselves in my atoning blood. Weep and howl over your transgressions; turn from your sins with your full heart. I am he that tries the hearts of men; you can hide nothing from me. Come to me without deceit. Come to me honestly and openly, and I will sup with you and will set a place at my table for you. Soon the Bride shall be gathered, sooner than you may think.

When my Bride is caught up in the air, the restrainer shall be loosed, and no evil thing shall be withheld from natural man. And they will openly follow the lusts and evils in their hearts; therefore, great judgment shall come upon them, and it shall not be remedied. Turn to me, Jesus Christ! Call upon my name while I may be found! Even during the great day of destruction, my name will bring salvation to those who call. Come to me now and come out from her, as time is almost out. The armies of heaven are readied, waiting for the trumpet.

I am the chief cornerstone they reject, thinking they are free.

I am the way, the truth and the life: the true way to the Father that brings salvation and freedom.

I am he that tries the hearts of men; you can hide nothing from me.

>**Acts 2:16-21 **
>But this is that which was spoken by the Prophet Joel;  
And it shall come to pass in the last days (saith God) I will pour out of my Spirit upon all flesh: and your sons and your daughters shall prophesy, and your young men shall see visions, and your old men shall dream dreams:  
And on my servants and on my handmaidens I will pour out in those days of my Spirit, and they shall prophesy:  
And I will shew wonders in heaven above, and signs in the earth beneath: blood, and fire, and vapor of smoke: The sun shall be turned into darkness, and the moon into blood, before that great and notable day of the Lord come. And it shall come to pass, that whosoever shall call on the name of the Lord shall be saved.