---
Order: "51"
Date: 2024-03-03
Image: "[[night-approaches.webp]]"
---
# Night Approaches
![[night-approaches.webp]]
[[In the Works of John The Baptist]] | March 3, 2024

![[night-approaches.opus]]

The Word of the Lord came upon me.

Night approaches where no man can work. Prophesies shall cease, tongues shall cease, the gifts to the Church all shall cease when my Bride is snatched away. Then a day of darkness where there will be a famine in the land, a famine of my Word shall there be. Yet even then my angels and prophets of the elect shall still speak for me. A time approaches when the wild beasts shall attack and many shall perish. The day of the Lord has been declared in my Holy Word, and soon it shall be so. Judgment shall break forth suddenly; therefore, turn from your sins to me, the Lord Jesus Christ, as I have paid for your sins, and you can be white as snow before me in fine linen if you would but give up your own garments. Turn to me in repentance. Humble yourselves before the Lord while there is still daylight, for soon the night shall fall and no man can work. Yet even in those times, anyone who calls on the name of the Lord shall be saved, as so yet by fire.