---
Order: "42"
Date: 2024-03-15
Image: "[[something-wonderful.webp]]"
---
# Something Wonderful
![[something-wonderful.webp]]
[[In the Works of John The Baptist]] | March 15, 2024

The Word of the Lord is upon me, behold the word of the Lord!

Behold! I am doing something wonderful before you, and many of you refuse to see!

Behold! I am doing a mighty work in your midst that will soon consummate!

Behold! I am doing a mighty work in you, whereby you are saved and made whole!

I have done more than mend a few broken pieces. I have done more than mend you together again, where the seams and scars are present. I have made my chosen and faithful whole in me, the living Christ, and I have created you anew. Know that your lives are hidden in me, and when I appear, so shall you also appear with me in glory and will henceforth be with me forever. You are my bride and you are my body; have I not called you by name? Have I not made a path for you to return to your Father, the Father of lights?

I am he who was known by my Father before the world began, who was commissioned and born for your salvation, who was crucified, giving my last drop of blood for your sins. Nothing is left out and nothing is left undone, and what has been said will be performed and consummated to the uttermost. I have created you with my holy spirit that the Father gave to pour out on my apostles on that long-past day of Pentecost, when they spoke the wonderful works of God in tongues they themselves could not comprehend. I have called, and even though many have rejected me, a remnant of grace and election has responded, and I have done a mighty work in them that is soon to be revealed. Truly, when you look in the mirror, your true self you do not see. I have made you mighty in your weakness, and at the appearing so shall you appear. You will be like me, and you will evermore be with me. I am the firstfruits of the dead, and the harvest is nearly upon you. When I shall appear, you will rise to meet me, and you will be in my Father's house as I snatch you away to your home in the heavens.

Truly, truly, in my holy Word (as I am the word made flesh who is holy and walks among you), yea, in my holy word, have you not read that judgment starts with the house of God? I am about to complete a work in my chosen, righteous, and elect, whereby you will be completely re-created in me and will be as I am, for you have been conformed to the image of the only begotten son of God. My reward is with me, and I will not judge you on account of your sins; have I not already paid for them? By your acceptance of my Lordship and your identification with me, you are forgiven and righteous in me, for I paid a terrible price that was not mine to pay as I am sinless. No, I took your sins, iniquities, sorceries, and wrath and punishment from you so that you may be united with the Father and with the Son. No, I will judge your works carried out on earth.

And with my judgment is great reward, and many works will survive that are gold, silver, and precious stones. Verily, the wood, hay, and stubble will but burn away as chaff, and you will experience loss, though you will be saved so as yet by fire. For my fire for you is a refiner's fire, in which I have purified your souls as a goldsmith purifies his gold, removing the dross. Stand firm and be still in me. Who is he that should trouble you, though verily you are persecuted and endure tribulation? Fear not, they hated me and they also hate you. Yet, in your redemption you will come to be greatly admired in the glory with which I will clothe you on that near and fast-approaching day. My Father longs to see you before him in his throne room, where your seats await you, for my Father has seated you in the heavenlies. Are you not his chosen, his ambassadors, his glory, crown, and prize of inestimable worth? Truly, you are priceless.

Judgment will fall on Babylon the Great shortly, and a terrible judgment it will be, but it is deserved. Oh, man, how long shall I endure you? You have gone from a nation of saints that served as a beacon to the world to come to me, to a nation of adulterous harlots. I have separated my people from you, and the separation is nearly consummated as this age of grace comes to a close. Oh, man, why do you follow the evil one, accepting his worthless bribes over me, the eternal Christ, in all my splendor and glory.

My Father gave time for all nations to repent, and many people, even a great multitude, have accepted my offer in my saving grace showered on them.

Yet you, oh, natural man who refuses the things of the spirit and despises his neighbor, will endure great judgment on your land, and Babylon the Great shall never be again. Babylon, you have become a nation of harlots who play the role with your skirts above your heads like a wild ass in heat waiting for the next passerby. You have defiled yourselves with strange flesh, you have relished and loved your sins, and eternal judgment will fall on all the hard-hearted who count my sacrifice but a light and worthless thing to behold. You have become a nation of evildoers and truce breakers who change wives like old garments for new until the new is soiled. Your great words you have spoken against my Father will be held to account. Your worthless imaginations will be laid in front of you, and you will give an account. But your account will never be enough to stand righteous before me. Your very existence has been corrupted, and in your insanity you have chosen your decaying flesh, for as my Father said, ye shall surely die. Yet, it still seems strange to you that in dying you shall die. Although your full expiration was not instant, you have been dying since the day of your first breath. Judgment has been declared on your nation, and do not the heavens shout the same? I will utterly destroy your land, and your great towers shall fall, and thick blackness shall cover the earth. Your walls are already breached, and millions have come for you to take from you what I have given them, because I will fatten the hand of your enemies in your judgment. Your time is nearly over, and you are a chained nation before me, waiting for my angels to come in judgment. You will fall greatly as the waters come on you, as the shaking comes on you, as the armies are unleashed, and your land shall be cleaved asunder. Famine shall settle over the world, and war will come to the entire world as the beast rises from the ashes in their long-planned schemes.

Time has been given for repentance, and many have answered in faith, the great mercy that I have given before judgment is executed. I have no pleasure in the coming destruction, but even now, many live in great sin, even preying on your own children, and you could not care less as long as your money is near. I will take all riches, delicacies, pleasure, and happiness from you. You will shrivel before the heavens, searching for a morsel of sustenance that many will not find. Yet, those who call on the name of the Lord shall be saved.

My little children, it is the last hour of the last time in this age of grace. I have sent my prophets in the work of my dear friend John the Baptist. Have they not become a voice crying in the wilderness? Are they not my shepherds, calling and searching for the last of my lost flock? Truly, I have another fold as well, and the time of their salvation is at hand, as Jacob shall be saved and a remnant of Jacob will accept me as their Lord, as all the chosen become one new man. I have sent many across the earth, heralding my arrival.

Though many of my people have been deceived and are lukewarm, my spirit shall awaken in many, and many shall return to me. My appearing is at hand. Stand strong and shout my arrival and shout my words of salvation to all. The time is almost at hand, and silence is on the deep as the hosts of heaven await the trumpet blast that is nearer than you can imagine. Yet, a very short time remains, and many more shall yet be saved, so faint not.

I am he who pastors my church and has given gifts unto men.

I am the great and mighty Lord, slain from the foundations of the world.

I am he who gave his life for the flock, the living Christ whom God has raised from the dead.

I am the Word made flesh who dwells among you.

I am the only begotten son of God come in the flesh, even the mighty Messiah of the Israel of God.

I am near, and my appearing is at hand.

I am the righteous judge who is worthy to open the seals.

I am the lamb of God, slain for the sins of my people.

I am the sinless savior who saves to the uttermost.

I am a man acquainted with much grief and sorrows, yet my joy remains full.

I am the living Lord, the righteous shepherd.

I am the one prophesied of by all the prophets and I have the keys to death and hell, and the Father has put all things in heaven and earth into my mighty hands.