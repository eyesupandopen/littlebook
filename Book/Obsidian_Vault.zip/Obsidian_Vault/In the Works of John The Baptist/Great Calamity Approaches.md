---
Order: "46"
Date: 2024-03-11
Image: "[[great-calamity-approaches.webp]]"
---
# Great Calamity Approaches
![[great-calamity-approaches.webp]]
[[In the Works of John The Baptist]] | March 11, 2024

The Word of the Lord came to me; please hear.

Hear my voice, saith the Lord of Hosts! My people, return to me, as great calamity is about to come upon your nation. Great calamity is at your door, and great calamity shall come upon your shores. Return to me and fear me, says the Lord of Hosts. God has passed judgment on America on two fronts. There will be judgment from within and there will be judgment from without. From within will be great shaking, great shaking, and America will fall mightily by great shaking. From without, his armies have come to steal and to kill and to destroy all that is in their paths. No mercy is in their hearts. They have one mind. And they shall take your abundance from you; they shall take your goods from you; they will seize your posterity; and great famine will come on your land. He that is not killed by war shall be killed by disaster; he that is not killed by disaster shall be killed by the wild beasts; he that is not killed by the beasts shall starve. Yet even in your calamity, whosoever calls on the name of the Lord shall be saved.

And I will save my people, even so by great tribulation and by the refiner's fire. Come to me, my people, while there is still time. Come to me, the Lord Jesus Christ, as I am the righteous Lord. I am the King of Kings. I am the good Shepherd, and none is able to pluck my sheep from my hand. Come to me! Come to me while there is yet time, and confess your sins; confess my mighty name as Lord, for there is salvation in no other name. For I, Jesus Christ, am set for your salvation that I have purchased in my own blood. Come to me, yes, come to me in my love that I have for you. Do not resist me, but come to me, that I might yet save you and give you eternal life so that I may bless your posterity. Come to me, my people, and harden not your hearts, as the fathers did in the wilderness. For the Lord your God has pronounced great judgment against your nation, for her sins are many and terrible.

Yes, I have paid for those sins and all the sins of mankind, but my offer and my arms shall not always be outstretched. In the day of calamity, salvation will be obtained through great distress and great tribulation that I will bring on the world to test the hearts of men, and he that endures to the end shall be saved. Follow not the man of sin. Take not his mark and take not his medicine, for a serpent's bite is therein, and you shall not be healed from the poison of it. Whoever shall take the mark of the beast will have their portion in the lake of fire with the beast and the false prophet. Is it not written in my Holy Word? Have you not read? Have you not heard? Return to my love and come to me, my children, for I call you in this last hour, for great calamity is at your door.

Hear me, says the Lord of Hosts:

For I am he, the Son of Man who was crucified under Pontius Pilate, who died for your sins and was raised the third day. I was raised and I was glorified.

I am the Lord of Lord and King of Kings.

I am the Son of Man, the righteous Lord, the true Lord who is faithful and true, and not one of you can be plucked from my hands.

I am the good shepherd, and none is able to pluck my sheep from my hand.

All that the Father has given to me, I shall present to him, and I desire to present you to the Father without fault, blemish, or blame, clothed in white linen dipped in my blood. The only way any man can stand before me is to accept my sacrifice for your sins. Tarry not with the sinners! Tarry not; tarry not! Come out from among them and separate yourselves from their sins. Confess your own sins to me and confess the sins of your fathers to me, for they pass on to you. Live the life I have given you, and walk the path I have laid for you, as I have called you by name. Turn not to the left and turn not to the right, but give attention and singleness of mind to my words. Yet, many shall refuse my invitation, and many shall perish. Have faith in me, as the love of God shall save all who call on the name of the Lord. Have faith in me, and rivers of living waters shall flow from your belly as your sins are washed clean and your spirit is made whole. Come to me while there is yet time; confess my name; make me Lord, for there is salvation in no other name given under heaven whereby men may be saved.