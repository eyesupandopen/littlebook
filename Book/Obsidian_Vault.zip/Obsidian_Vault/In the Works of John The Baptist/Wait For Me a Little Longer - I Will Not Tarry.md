---
Order: "38"
Date: 2024-03-23
Image: "[[wait-for-me-a-little-longer.webp]]"
---
# Wait For Me a Little Longer: I Will Not Tarry
![[wait-for-me-a-little-longer.webp]]
[[In the Works of John The Baptist]] | March 23, 2024

Wait for me a little longer, my children, and I will not tarry. I will never leave you nor forsake you, for you are the apple of my Father's eye and the very apple of my own eye. You are my Bride, and what bridegroom leaves his bride to the judgment of sinners?

Know that I, the Lord Jesus Christ, will rescue my people. Have you not read in Holy Scripture? Did my Father not snatch Enoch to the heavens? Did my Father not snatch Elijah to the heavens? Did my Father not deliver the children of Israel from Egypt? Did he not deliver Lot from Sodom before fire fell on those cities, destroying them all? How much more will I deliver my bride that I have purchased with my own blood from the hands of judgment that is about to pass on this world? How long will you attribute folly to me, your Lord, and to my Father, your God?

I have given you eternal life, and there is great reward treasured for the faithful in heaven, so fear not, as your inheritance is about to be realized. I am the righteous Shepherd who saves the flock from the ravenous wolves. These same wolves will soon hear, "Depart from me, you workers of iniquity; I never knew you, though you say, Lord, Lord!" I am the faithful Shepherd who has lost none the Father has given me, but the son of perdition who betrayed me for thirty pieces of silver and scripture was indeed fulfilled by his transgression and refusal. What lessons are therein for you, my children, except you cannot be lost from my hand and none is able to seize you from me?

Fear not the judgment of evildoers, my faithful ones, and know that your Father's wrath will not touch you. What father amongst you would give just one of his children into the hands of the enemy? Though this is a common sin amongst the men of earth, there is no shadow of turning for the Father of lights! So fear not and be at peace. Cease from your own works and rest in me. Pursue my works and enjoy rest in me, the Lord Jesus Christ, who gave himself as a sacrifice for the sins of all once and forever.

Oh, you children of the earth, your sins are before me, and you have treasured up great wrath and judgment against yourselves! Instead of treasuring an inheritance of blessings, you have treasured wrath against wrath for this great day that is about to overtake you. Oh, your idle words you have spoken, saying, "Where is the Lord; he is but a myth who never was and tomorrow will be the same as today and yesterday." Your judgment will overtake you suddenly, and events will move so fast that you will be lost in suffering. Your evil words and evil ways will bring great destruction on you in an instant. All you hold dear will be taken from you, and all your treasures will vanish from your hands as I have given them into the hands of those who hate you, for you have hated me without cause.

The wrath of the Lamb is about to be delivered upon you, and the birth pangs are closer together now, so close that you mistake them for the wrath of the Lamb. Know, oh, foolish man, that in my long-suffering I am warning you of your own demise, and still you scoff in unbelief. Very soon I will remove the restrainer from your midst, and I will remove my Bride from your midst, and utter destruction will come on you suddenly. Satan has moved his armies and his pieces in place, ready to unleash his full anger and wrath on you, and I have given you into his hands. Your great nation is crossed out and marked for utter destruction; oh, that you understood the words, Mystery Babylon. Yet there is still time to repent, but most of you will not in your stubborn heard-hearted ways of heretical rebellion.

Your judgment will come on you in two major ways: from within and from without. The great whore will be rent in pieces; she shall be consumed in water and burnt with fire and covered over in pestilence and famine. Yea, oh, earthly man, who will deliver you from my hand? No one is coming to save you. Your destruction is imminent. The red armies walked into your nation right under your nose, and you could not have cared less as long as you were entertained and fat with temporal wealth that was never yours to begin with, for the earth is the Lord's and the fullness thereof. Not only have you sealed your own destruction, but you have sold out your children and grandchildren to utter destruction, and still you scoff. Your posterity is lost. You will not scoff much longer as all of your evil and perverted ways will engulf you in misery, torment, and destruction, though a great multitude will be purified through tribulation.

All those who turn to me and call on my name and love not their lives to the end, I will reward eternally! Never will they suffer again, but your suffering will never end, oh, evil ones. But you, oh, God-rejecting natural man, who declared war against your Creator and lusted after rebellion against me and my ways. Your destruction will come suddenly and without relief. You have become a nation of whores, and how appropriate that your nations are referenced as a harlot in Holy Scripture. The armies will consume what's left of your once great and mighty nation, and a great cleansing will come over the land, and great punishment will consume you on account of your evil ways.

I have taken everything from you on account of your rebellious and hard-hearted ways; and though I paid for your sins, you have rejected my offer, choosing instead to pay for them yourselves, and you will regret it for all eternity. When the restrainer is lifted, instant destruction will be your companion; and you have sacrificed your children to the same fate as you, though many will be saved. Even some of your children will turn to me, and I will receive them into glory, though you kept them from me, and you will go into perdition in that great lake that awaits the Devil and his angels.

My little children, fear not. Continue to stand faithful for me here in this last minute, yea, your last minute in this dying world. I have called you, I have chosen you, I have hand-picked you on account of your love for me and your faithfulness, and great treasures await you in my Father's house. You will be taken to safety and great reward; though some will suffer loss, all of my chosen ones shall be saved fully and to the uttermost.

Focus on me, commune with me; I am nearer than your next breath. Know, my chosen, that I do fight for you; and though persecution and tribulation abound, you will be saved from wrath. Therefore, purify yourselves by coming out of this world and rejecting her evil ways. Wash your hands of her sins and depart from her iniquities, for anyone in the harlot's bed will suffer anguish. Cleanse yourselves in my atoning blood and wash yourselves fully. Behold, I have sealed you with my Father's seal, and I will fully redeem and re-create you after my own image. Yea, you will be a new man and are a new creation in me, and soon there will be a new heaven and a new earth, for my Father is making all things new. So stand fast and know that my love is a burning fire, and you are greatly treasured and longed for. Soon you will be with me.

I am your living Lord and savior, Jesus Christ.

I am the righteous judge who weighs all in the balance.

I am the root of Jesse who will sit on the throne of David in my approaching Kingdom.

I am the son of God who came in the flesh and was crucified for your sins, taking your place in judgment.

I am the son of man prophesied of old.

I am he that walks amongst the seven lampstands.

I am the light of the world.

I am the bread of life.

I am he from whose belly flows rivers of living waters.

I am he who has made you anew and created you afresh.

Remain steadfast, my faithful, for your redemption is nearer than you imagine.