---
Order: "50"
Date: 2024-03-05
Image: "[[to-whom-will-you-turn.webp]]"
---
# To Whom Will You Turn?
![[to-whom-will-you-turn.webp]]
[[In the Works of John The Baptist]] | March 5, 2024

The word of the Lord came to me.

The Lord Jesus Christ says: To whom will you turn to escape my wrath? Will you place your faith in evil men sent to deceive the very elect if possible? Will you place your faith in the Babylonian beast system, that great whore? Have you been deceived into thinking you can choose your king by election? Do you not understand that Satan is god of this world and deceives the entire world? Will you place your faith in man-made organizations and the houses of false prophets sent to deceive my very elect? To whom will you turn? Where will you go when nothing can be hidden from my sight?

You are seeing the evil ones prepare to hide themselves in their caves in the earth that they have hewn for themselves to escape me, but they have hewn in vain. My wrath approaches and no man can stand. Call on my name while there is still time. The Father has placed all things in my hands, both on heaven and earth, and I will fulfill his plans. There is nothing and no one that can stop me because my Father has empowered me, and I cannot be stopped. The wrath of the Lamb is at your door, even though I still stand at the door and knock. I am eager to come in and sup with you if you will but answer your door.

My people awake!! Awake!! AWAKE!! Awake to righteousness and sin not. I have heard your prayers, and I have seen your vexation of spirit and distress. Come to me with your whole heart and depart from sin. Depart from the sins of Babylon and her leaders; I tell you plainly depart from her fully, even from her apostate churches. For Babylon's judgment is at hand, and it will come suddenly, leaving her desolate in one hour. For great are her sins; therefore, great is her judgment.

Your only escape is in the safety of my arms and nobody is able to pluck you from my hands. Do not be lukewarm, as the times of separation are already underway. To the people: where will you turn when I gather my bride from among you? Have you not read? Have you not heard?

I am eager to come in and sup with you if you will but answer your door.

Verse I was inspired to share:

>**Revelation 18**  
And the light of a candle shall shine no more at all in thee: and the voice of the bridegroom and of the bride shall be heard no more at all in thee: for thy Merchants were the great men of the earth: for by thy sorceries were all nations deceived.
>
The voice of the bridegroom and the bride shall no longer be heard because I will gather my bride and hide her in the chambers that I have prepared for the coming time, for in my father's house are many mansions.