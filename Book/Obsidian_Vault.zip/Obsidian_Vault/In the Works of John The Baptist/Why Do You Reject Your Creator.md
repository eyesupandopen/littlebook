---
Order: "48"
Date: 2024-03-09
Image: "[[why-do-you-reject-your-creator.webp]]"
---
# Why Do You Reject Your Creator?
![[why-do-you-reject-your-creator.webp]]
[[In the Works of John The Baptist]] | March 9, 2024

The Lord gave me these words. They are not of me, and I am giving them nothing added and nothing removed to the best of my ability.

Why do you yet reject your creator and his ways? Has he not offered you eternal life? Has he not given you the bread of life, freely for all who ask? Has he not offered you freedom from this fallen creation in me, the great and faithful Lord Jesus Christ? I am the way, the truth, and the life. I am King of Kings and Lord of Lords, and I gave my life on the cross for you, that you may indeed walk in my kingdom if you will but accept the gift of eternal life. Have I not called you by name? Why do you yet count yourselves unworthy of eternal life, when my atoning blood will make you worthy if you but yet call on my name and make me Lord? I am the Son of God, the Son of Man, the Christ: Jesus the Nazarene, the faithful Lord, even the great Lord! There is none greater but God, who has given me all things.

Behold! A day of calamity is on you, a day of judgment and distress. America's sins are as the sins of Sodom and Gomorrah, and if he were to not judge the great whore, he would be unjust to the generations he took in judgment. That great whore, who lusts after strange flesh, who has been integral in building the beast system for that son of perdition, verily, who walks among you deceiving my elect even before his time. Great judgment and calamity will fall suddenly. America, you are judged from without and judged from within.

The hand of your enemies is about to be on your neck, and you will be violently overthrown, and the nations shall drink no more of your adulterous fornications wherewith you have enchanted all. Your enemies have been given victory over you, though you blindly trust in your military might that I have taken from you. You are a nation in chains, awaiting your final remembrance before the Lord! There is nothing great about you, but your sins and iniquities are a stench in my Father's nostrils.

You will be judged from within, as a mighty, violent shaking will decimate you suddenly and without remedy. The great whore will be cast down as a warning to all and will be the start of the darkest hour ever. No more will she unjustly overthrow nations.

No more will she plague the world with her iniquities. No more will her abominations seduce my people. The great whore has defiled my Father's covenant, that glorious rainbow that he gave to Noah as surety to never flood the world again. Though the world shall never again be flooded, the waves of destruction will fall on many, and an all-consuming fire approaches.

My people, be ye not partakers of her sins, plagues, judgment, and calamity. I will still yet set a place for you at my table if you will yet turn to me with your whole heart.

Repent! Confess your sins to me, Christ Jesus! Have you not read that the unrighteous shall not inherit the Kingdom of God? Do you desire your reward to be stripped and given to another? Think not that you will enter into my presence in a state of willful disobedience; has not my Father declared, "I am holy, so be ye holy?" Run to me and submit yourselves to my salvation, for I am Lord of Lords and King of Kings, and the days of pleading with a stiff-necked generation are coming to a close.

How long have I outstretched my saving hand to you, and yet you reject the God of your fathers and my saving grace that is able to save you to the uttermost? Come to me and hide yourself in my bosom; truly, I will hide you from the great day of calamity that is upon you. Do not join those who have rejected my name; Christ has no concord with Belial, yet my people are still bewitched by his false light. Weep and howl and repent of your lukewarm ways. Return to your first love and seek my face while there is still time.

My atoning blood will wash you if you will but come out of your sins. I am the Son of Man, the high priest forever after the order of Melchizedek. I am he who kept himself pure in the face of all temptation, even tempted by Satan himself and still victorious. I am the only begotten Son of God who has poured out holy spirit on all who have turned to me and all who will yet turn to me. I, Jesus Christ, am all of these things and more, and I chastise those I love so that their calling may be sure and complete.

O man, your sins are many, yet you declare your own holiness! Sins of adultery and fornication. Sins of pharmakeia, witchcraft, and many sorceries. Greedy, unmerciful, lovers of self, lovers of pleasure, and lovers of money. What will become of your faith in riches when your riches become worthless instantly and poverty and great desolation comes on you suddenly? Will you blaspheme in the face of mercy? Will you yet choose your sins? They who stubbornly choose their sins shall perish in them. Think not that God is mocked, as he is about to make a mockery of the mockers; be ye not partakers with them.

The hour is late, and the final minutes are approaching and time is nearly finished in my age of grace, and wrath will overtake the earth as the true Church is taken before your very eyes. I have no pleasure in seeing my creation destroyed on account of transgressions and unrighteousness; but have I not given you a choice to live in my kingdom, and yet many stubbornly refuse? Come out of her! Rebuke and abandon your ways; confess me, Jesus Christ, as Lord, and cease from sin.

Have I not given great peace to my sons and daughters, who have overcome their sins by my very blood? Yet many still reject their witness and testimony and still refuse to believe, choosing instead their arrogance over my humble ways. Your own ways are a snare and will lead you to utter destruction, whereof you can never be healed. Turn to me while there is still but a few minutes left to do so. The hour is late, and all who call on the name of the Lord shall be saved!

I invite you to share in the glory of my throne and accept life with me. Turn from your ways and return to me, as I am the eternal Lord and there is salvation in none other but me! I, Jesus Christ, am the Son of God and have come in the flesh, was crucified, was raised the third day, has been made a life-giving spirit and received into the heavens until times are consummated. Truly, the night is far spent and the hour late, and the times of restitution approach.

My people, stand fast in my might and be at peace. Rest in me and yet a little while your glorification will come instantly, and great reward is laid up for you in my Father's house. The things I have prepared for you have not even entered your heart, truly, not the heart of any man. Peace and safety you will find, and you who have been faithful over a few things I will reward richly. Rest in me and keep your focus on me. Declare a fast among yourselves and renew your vigor in this last hour and declare my righteous ways and declare my approaching judgment, as even yet many shall be saved.

I have showed you great mercy, great long-suffering, great abounding grace, yet you no longer extend these things to others. Will you sacrifice your reward and force me to give it to another? Or will you love God with all your heart, soul, mind, and strength and your neighbor as yourself? Why do you set at naught your neighbor and erroneously judge them unworthy of eternal life as you stand there in silence? Have I not given you my mysteries to declare to all? Stand strong in me, and I will empower you to reach those whom the evil one would yet try to hide from my saving hand. Open your mouth and declare all the words of this life and the very words to speak I will give you. Share your love until the last second, for that last second steadily approaches as the trumpet is about to call my children home.

I am the faithful Lord who fails not.

I am the light of the world, and whosoever calls on my mighty name shall not perish in the unquenchable flames; on such, the second death has no power.

I am the mightiest among the mighty, and all things in heaven and earth are given into my hands until restoration is complete, when my enemies are my footstool. I am the way, the truth, and the life.

I am King of Kings and Lord of Lords.

I am the Son of God, the Son of Man, the Christ: Jesus the Nazarene. I am holy, so be ye holy.

I am the high priest forever after the order of Melchizedek. I am he who kept himself pure in the face of all temptation.

I am the eternal Lord, and there is salvation in none other but me!