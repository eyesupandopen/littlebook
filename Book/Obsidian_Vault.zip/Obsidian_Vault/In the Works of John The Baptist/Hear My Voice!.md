---
Order: "43"
Date: 2024-03-14
Image: "[[hear-my-voice.webp]]"
---
# Hear My Voice!
![[hear-my-voice.webp]]
[[In the Works of John The Baptist]] | March 14, 2024

The Word of the Lord came upon me. Hear my voice, my little ones, and come to my outstretched arms. Know that my love for you is unbreakable and cannot be conquered, for it is the love of my Father in that he has given of his nature to his children, and in me all fullness dwells. I have called you by name and I have invited you to stand before me. My sheep hear my voice, as they know the voice of their shepherd. Do you not yet hear my voice? Have you closed your ears to my voice? I cry aloud in the streets and in the alley ways; I have even visited your prisons and brought salvation to the abused and forgotten.

Oh, man, why do you forsake your Lord? Why have you turned from my ways? Yet, you will say, I have not turned from your ways; I am he the Lord has called. Verily, I have called, and you did respond for a season, a season of youth with great excitement. Some of you were taken to where the wolves dwell, and many of you have been led astray through good words, fair speeches, and lying tongues that are soon to be stopped.

Remember your first love, and repent; confess your sins to me, as I am always ready to cleanse your sins in my atoning blood.

Hear my voice, my children, as many voices sound similar and many false Christs try to counterfeit my voice. Verily, I do care for and pastor my church with my own hand, that I may present you to God pure as a virgin and dressed in fine white linen, with the stains of your sins forgiven, removed, and forgotten, as I have cast them into the deepest depths, never to rise again. Yet, many of you are distracted and even enchanted by this present evil world. They have attacked with their sorceries through the serpent's bite, but understand that though a serpent bite you, no harm shall come to you, for my Father's seal cannot be broken. Focus your attention on me, his only begotten son, whom he gave willingly to atone for your sins that we may be reunited, never to separate again. Let me heal you; let me heal you to the uttermost and remove your scars so that you are sound and whole before me. Follow my ways and follow my Word, for:

I am the Word made flesh who dwells amongst you.

I am the bread of life, and whosoever eats thereof shall never hunger again.

I am he whose kingdom is not of this world, and my reward is with me for my faithful and chosen.

I am he who walks amongst the seven lampstands and commands the seven angels of the Church.

I am the holy one of God.

I am your intercessor.

I am he who tries the hearts of man.

I am always ready to cleanse your sins in my atoning blood.

I am the righteous judge.

I am the very Christ foretold from the beginning.

I am the son of God come in the flesh.

I am he who gave my sinless blood for the sinners, that they may inherit eternal life.

I am the son of God come in the flesh.

I am the good shepherd.

I am he who came to my own and was rejected by my own.

I am the very Christ, chosen by my Father from the foundations of the world.

I am that I am.

My children, I tell you truly that I have outstretched my hand to a dying world for many Jubilees now, and my hand shall not always be outstretched in mercy and grace, though mercy and grace are ever with me. I have called many, and many have refused. However, the ones I have called and chosen and sanctified and washed and cleansed and healed, those very ones will stand before my judgment seat and carry away great reward for their faithfulness.

Though I have many works for you yet to accomplish, and though you have done much for me and my name, I desire your full heart over your works. I desire that you turn to me and depart from your sins. Come clean to me, as your Lord is at the ready with my healing hand outstretched that I may make you clean as the fresh snow. Though my hands were pierced, my atoning blood poured from them and from my body to the last drop. I gave my all so that you may live before our Father for all eternity.

Verily, I didn't atone for only one sin; verily, I didn't atone for only a few sins; verily, I didn't atone for many sins, but I atoned for all sins for all time if you will but respond to me when I convict your hearts through my mighty spirit. Do you not understand that I have no desire to condemn you? There is one who has that desire and lusts for your demise and accuses you day and night before my Father, though I am your intercessor. He is cast down and defeated; yet, why do you elevate the thief to a lofty place in your hearts when I have complete and utter victory over him and his kingdom that is soon to come to naught? Be still and be at peace and come to me with a humble heart. Know ye not that if you would judge yourselves, you would not be judged? Ask me to show you your life, as I will reveal many things to you so that you may confess your faults and be made whole.

Fear not, my little ones, as it is not me that condemns you. Listen to your conscience and do not rationalize away my voice. This world is about to be cast down, and as this world is forever changed, you will be lifted into the heavens above, that I may present you to the Father, that you may realize your inheritance and receive your rewards of faithfulness. I have longed for the day when we see each other in the heavens that you may finally have your true life revealed to you as you have escaped this temporal life of evil, sin, and wickedness. I am he that tries the hearts of man, not that I would condemn you, but that through the refiner's fire you may be purified of your old ways and realize my ways of love, light, joy, peace, long-suffering, and gentleness.

Hear my rebuke and accept my chastisement because your Father deals with you as children, and what child that a Father loves is not rebuked and chastised in turn. My chastisement yields the peaceable fruits of righteousness, as my chastisement is to purge you fully from your sins if you will but hear my words and follow my voice. Go, stand, and speak all the words of this life. Some will still come to salvation in this last hour, and only in the name of Jesus Christ, my mighty name where there is salvation, for in no other name is salvation given. My mighty name stands firm, waiting for you to bring them to me, that I may present the penitent to the Father as a newborn baby freshly delivered into eternity. I have great love for you, and as the Father has given me, I will give to my faithful and chosen.

I am the son of God come in the flesh, sinless and pure for all eternity. Likewise, I am he who gave my sinless blood for the sinners that they may inherit eternal life. Aren't you, my faithful and chosen, amongst the inheritors of eternal glory? Why do you yet stand silent as if you are waiting for the right words. Speak! Open your mouth and speak, as I will guide your speech to minister to the very hurt that my called still suffer, and many will still respond. Join me in my work in this final hour before I shake the foundations of the world and rend it in many places and great judgment engulfs the earth. I will restore this earth to you in my coming Kingdom, but first the kingdom of the wicked will be destroyed and taken in judgment to be chained in the abyss, and they know that the white-hot lake where they will spend eternity awaits.

I will utterly destroy their seats of power; I will utterly decimate all their principalities; I will utterly burn them to the ground with a fire that cannot be quenched, as even I, the faithful Lord, have told you before it happens. In my Father's house are many mansions, and great majesty and splendor awaits you. Therefore, let no one beguile of your reward and stay faithful to me. Keep your focus single-minded on me, the everlasting Lord, even the Lord of glory. I am the good shepherd; I am the very Christ chosen by my Father from the foundations of the world. I am he that came to my own and was rejected by my own, though through great testing Jacob shall be saved by my mighty hand. The consummation of all things is at hand, and the end of the prince of this world is nigh. Though he shall be loosed for a little season, his eternal judgment follows, whereof he can never be delivered and there will be no remedy. Return to me, talk with me, minister for me, as my Father has given me all things, and my reward for you is treasured up in the heavens for my faithful and chosen and is as sure as my Father's seal that I have sealed you with. There is, but a few minutes left of the age of grace, and my judgment will fall suddenly as the wrath of the Lamb comes on the earth. Prepare your hearts and prepare yourselves, for the time is at hand.