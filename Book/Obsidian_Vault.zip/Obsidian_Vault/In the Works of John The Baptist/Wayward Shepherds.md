---
Order: "47"
Date: 2024-03-10
Image: "[[wayward-shepherds.webp]]"
---
# Wayward Shepherds
![[wayward-shepherds.webp]]
[[In the Works of John The Baptist]] | March 10, 2024

The Great Lord, Jesus Christ, says to the wayward shepherds:

You claim to speak in the name of the Lord, me, Jesus Christ; yet you only know my name and do not live my ways nor speak for me. You build broken cisterns that hold no water for my people, and they thirst. Furthermore, you have greedily served your own belly as you rejoice in the lusts of your hearts, and you give all satisfaction and reverence to your flesh. In your hearts you are deceived as you think you fully follow me and represent me to my people, and yet you speak shallow lies, lies that should be cast into the great deep, faithless words not given by me, words of darkness and self-empowerment when you are quite powerless, powerless to lead and powerless to shepherd. Buy eye salve of me and anoint your eyes. Open your ears and be attentive to my word.

Great calamity and destruction is upon the great harlot, and her times have been appointed and her days numbered. Her judgment will come suddenly and without remedy. Yet you have said in your heart, I am God's representative. I am the just shepherd. I am the glory of God, and by the works of my hands I am the great example of God's love. You fool! How can you shepherd my people when you don't even know me, Jesus Christ, the true and righteous Shepherd? Depart from me, as I know you not! You have become a hireling, craving the adoration of men. You have forgotten your first love. Repent and return to me. Stand for me. Shepherd my people in sackcloth and ashes of repentance. You serve your own belly and would sell my Word for your greedy base gain as you lecture my people in sin.

Verily, judgment is upon your nation, and though I would set you apart for a people of my own, you run from my voice and reject my ways, and yet in your deception you declare yourselves holy and an example to the flock. Focus your attention and ears on my voice. Repent and come to me, that I may yet save you and the people who follow you; I would save you from calamity and distress! Those who take salvation as a license to sin will bear their judgment, and your works shall be burned. They who live such will reap outer darkness. You say you are rich, but you are in poverty. You say you are powerful, commanding the very power of God by your words, but your good words and fair speeches are quite powerless. Have I not called you? Have I not given you purpose? Yet you count me absent from my own Church, yet you make yourselves absent from my Lordship. What a man soweth, that shall he reap.

Judgment will come suddenly on your nation, and you will either stand with me so that I may rescue you, or you will stand with the judged and partake of her sins and coming plagues of judgment. Sin has consequence even to those who carry the seal of the living God. Verily, the time is upon you when judgment will begin at the house of God. Wash yourselves from your sins in my atoning blood! Repent publicly of your ways. Turn to me because time is almost out. Any man who reckons himself something when he is nothing is deceived and caught in a web of iniquity that has blinded their eyes and closed their ears. Repent and turn to me with your whole heart before it is too late.

I am the merciful Lord. I have been given a name above every name, and I am the preeminent one, slain from before the foundations of the world. I am the righteous judge, your Lord and redeemer, Christ Jesus! I am the son of God who was made after the flesh yet took only part as I remained sinless. I was crucified under Pontius Pilate and died as your sinless Passover. No man took my life, but I gave it freely. I was raised the third day and ascended into the heavens. I am the Son of God who came in the flesh. I am the righteous Shepherd who has lost none given to me. Hear my words and doubt them not. Do not set my words aside as if that is a light thing.

As many as I love, I chasten. As many as I love, I rebuke. If the Father deals with you as sons, then blessed you are, because a father chastens his children so that they may stand firm and upright and may receive great reward. Rewards of faithfulness and many crowns shall be placed on their heads for obedience. Turn to me with your whole heart and hear my words. I see your works, yet I desire your full heart over your works. Warn my people of the coming storm, that they may make themselves ready and pure for my impending great escape, when I will gather my Body to me and hide them in my Father's house from the day of trouble. Depart from sin and return to me, Jesus Christ, my people, as I have called you and desire to make your election sure.

I am the merciful Lord, and I have been given a name above every name. I am the preeminent one, slain from before the foundations of the world. I am the righteous judge, your Lord and redeemer, Christ Jesus!

I am the Son of God who was made after the flesh yet took only part as I remained sinless.

I am the Son of God who came in the flesh.

I am the righteous Shepherd who has lost none given. I am all of these and much more.