---
Order: "34"
Date: 2024-04-05
Image: "[[watchman-awake.webp]]"
---
# Watchman Awake!
![[watchman-awake.webp]]
[[In the Works of John The Baptist]] | April 5, 2024

Watchman, awake, and gird your loins with truth, and have on the breastplate of righteousness!

Watchman, awake, and take to yourselves the helmet of salvation and the sword of the spirit, which is the Word of God!

Watchman, awake, and have your feet covered with the preparation of the Gospel of peace!

Warn my people and hold not your tongue, as I have loosened it! Fight for my people and warn my chosen, for a prophet's reward will you have if you but speak the words I will give you. AWAKE! Have I not told my people to watch for my coming? Aren't the times and seasons discernible and upon you? Therefore, look for my appearing, for it is at hand. Look to the signs and wonders in the sky, for my Father has arranged their orbits from the beginning, and the day is marked. Look for my brightness in the sky as the trumpet is about to sound; behold, I have declared it.

My people, check my Word and look to my Holy Scripture to understand that I will snatch away my bride from the judgment of evildoers. I will protect my bride and my body; for what man ever hated his own flesh, but nourish and cherish it? Look, pay attention, observe the seasons, and know that the times are here and the day will break forth suddenly as a great sun rising suddenly over the horizon. I will not be denied, and I will not be stopped. Though the thief will try, he will roar as a lion; but a toothless lion is all he is. He will not stop me, and I will not be denied my possession, for I have purchased the earth and especially my people in my own sinless blood. And my name stands above all except my Father's, who is greater than I; and I will not be denied, hindered, or stopped.

I am coming, and I will not hold my peace, and my anger is hot against Secret Babylon, yea, Secret Babylon who traffics the little ones for merchandise into the hands of evil men, who will be stopped. It would be better that they had never been born than to be born and commit lawless and grievous sins against the children. It would be better that a millstone were hung around their necks, and they were cast into the seas; but they are reserved for everlasting fire, and justice will soon be done, as the wrath of the Lamb is about to cover the entire earth and Jacob's trouble breaks loose when the restrainer is removed.

Steady yourselves, my people, and stand firm in me with a single heart and single-minded purpose. Forsake the worldly things you have desired, and set me, the Lord Jesus Christ, as your desire; for I am your strong tower, rock of defense, and rearward. Who will come against you that can withstand my mighty hand? My chosen and faithful are in my outstretched hands, and no one can take you from me. You are mine, and you are secure in me; so rest in me from your own labors, for the times of recompense will break free suddenly. A recompense of judgment on the evildoers is here, and the recompense of my faithful is upon my chosen, as I will reward them with their inheritance, for I have made them worthy.

Oh, you worthless, toothless dragon; you ancient serpent: your time has come and judgment is upon you. Though you arrogantly think you will be victorious, I will take everything you have gathered into your thieving hands, and those who follow you in their lustful greed will share in your inheritance in the lake of fire, where everyone will be rewarded according to their works many times over. The wrath of God will abide on you for all eternity, and rest you will never have.

Great punishment will be your comforter, and the acrid smoke of burning brimstone will forever be in your nostrils, and you will pay for all eternity. And the smoke of your torment will rise forever, and all who follow you from the least to the greatest will have their inheritance and reward with you in white-hot flames of blue that will forever cover you as you will be bound and cast to your fate. There will be great weeping and gnashing of teeth. And you thought yourselves able to stand against Yahweh and his Christ, yet you will be brought to nothing but everlasting contempt in your unending torment, and forever will you be sealed away. And never will you harm my creation again, and you will be utterly forgotten about, and you will not come to mind.

So my people, my faithful bride whom I love dearly, what is there for you to fear? My wrath and the wrath of your Father is not for you and will not come upon you, and never will you be in danger of the second death. So fear not as I will exact perfect vengeance on your adversaries, for vengeance is mine, saith the Lord! Know ye not that you will judge angels? Know ye not that you will judge the world? So purify yourselves in me, for it is only my atoning blood that will make you worthy to stand before me in glory. Bind my word in your hearts, and keep my writings in your forehead, and rest in my sayings of old; for life they are unto you, and your life is hid in me, and I will reveal it!

Oh, Secret Babylon, that you had understood the peace offering my Father has sent you, and you have now rejected me, Jesus the Nazarene, and it has happened according to the holy writings that evil men and seducers will wax worse and worse. But you, oh, Secret Babylon the great, have desecrated my Father's bow of many colors that he gave to Noah and all mankind as a promise that he would never destroy the entire earth by water again, and he will keep his word. But you, oh, Mystery Babylon, will be laid waste in one hour.

Great fire will come upon you; great shaking will flatten you; your towers will fall; your infrastructure will disappear in ruins, and great waves will overtake your coasts, and I will reward you according to your works, and great judgment is against you. For you were once a beacon of hope and a light to the world for a short season, but you have chosen greed, selfishness, and corruption as your bedfellows, oh, great harlot! Who will save you from me and my anger and my approaching wrath that is hot on you? You stand in chains, awaiting your final judgment, which will be evident for the world to see, and great fear will come on many.

Behold! Many nations my Father has overthrown in judgment, for he sets up one and brings down another, for Yahweh is sovereign and there is none greater than the great eternal God who stands for and saves his own from the fires reserved for the evil ones. Behold! The nations that made up great empires still remain, yet in a diminished way, but continued they have. But you, oh, great harlot, you have prostituted yourself with many lovers for base greediness and the pleasures of sin. You have led my people away from me worldwide by the filth you have offered the nations to eat and drink, and you will be utterly cast down, and never again will you be. And of your ashes a great nation will not arise, yet a remnant will be saved. The hand of the enemy is on your necks, and I have brought the dregs into your borders. They will pillage, plunder, and seize what remains. Who will help you?

For you have denied your neighbor, and there is no fear of the Lord in your hearts. You have said, I am no widow, yet you are widowed and blind and deaf before me. There is no salvation for you on account of your adulterous fornication that you have committed with the world; therefore, I will bring you to utter ruin. Coming events will happen faster and faster; then a great deluge will cover your skirts. Fire will burn you utterly and will cleanse the evildoers from the land, and my captives will be freed, and nothing can stop what is about to happen. I am the Lord Jesus Christ, and I tell you before it happens, and I declare what is about to happen as if it has occurred already, for certain are these sayings, and nothing can alter them, as prophecies shall be fulfilled.

Stand firm, my people, as I will catch my bride away; for I have plans and purposes for her in my coming kingdom. She will always be with me, and she will never depart from me. I love and cherish her in perfect love and compassion. I will make you mighty in my glory, and you will do mighty works in your coming inheritance, so fear not. Know that my heart breaks, and I am saddened by my people who have not readied themselves. Some will be left behind because the god of this world has blinded their minds, and many are not ready. Fear not, though you will endure much for me, all of you will be saved who carry the seal of the living God. I will provide for you if you do not deny my name, if, and you labor for me in the work I have given you.

You will do mighty works if you but ask me to commission you. I have called you and I love you dearly, and those who call on my name and endure to the end will be saved and resurrected into great glory and rewarded for all eternity for your stand, as I love you and have spoken it for your ears. There are several harvests and each in their own turn, so fear not; for desperate times always are given great men of God to shepherd the flock, and I have called you. My angels will seal the 144,000, and some of you will help them in their works and commission that I have given them. Fear not, for I will do many signs, miracles, and wonders by your hands, so rest in my love and rest in my strength; for I am with you and I will never leave you nor forsake you.

You will know that I have snatched my bride away, and I will have gathered the faithful to me to engender repentance for many in a dying world. So let the world pass and share not in her calamity and fate for it is not for you if you will yet sanctify the Lord in your hearts and live set apart for me. For great evil is approaching, and never has it risen in this manner, and never again will it arise, my little ones, for I have declared it. Take comfort in the path I have laid for you, and keep your feet steadfast in the way. I will be with you and will give you a peace that passes comprehension, and you will have peace amongst a world of chaos, a peace that will keep you if you turn not to the left nor to the right.

Take not the mark, and don't believe the lies. They will offer peace and health and safety for those who take the mark, and they will tell you that you are entering a new world of peace and prosperity and safety. Believe not the lies of the snake, for their king will surely not keep his word. That man of sin has but one mission, and that is: destroy.

There is no truth in him, and Satan himself will control his reins. There will be no peace from him, but every word will be a soothing lie, designed to lead the world into utter destruction. And had I not shortened the days, no flesh would be saved from the scourge he will bring on the land, for he will be empowered to complete my purposes for a short time. Then he will be bound in heavy chains of darkness in the abyss to be loosed a little season to deceive the world one last time. When he has gathered them to himself, they will mount an attack against that great city, and fire from God will destroy them all. Then the final judgment, yea, the great white throne judgment will break forth on them all, and they will be without remedy. I tell you these things to give you hope and prepare my people, for the Great Mystery of God will even be brought to consummation.

I am the way, the truth, and the life.

I am the King of Kings and Lord of Lords.

I am he that is worthy to open the seals, and the times are here.

I am he who tries the reins of my chosen ones so that I may purify you and cleanse you in my atoning blood.

I am the Son of God come in the flesh, crucified, and resurrected the third day, seen by many, and received into the heavens before their very eyes.

I am the son of David, and I will gather the remnant of Jacob under my arms of comfort and strength.

I am he that will fulfill all of my Father's will.

I am about to make my enemies my footstool, and woe to those who oppose me, for great is the wrath of the Lamb.

I am he who will subjugate my Father's creation and give all things into his hand, that God may be all in all.

I am he whose kingdom is for everlasting to everlasting, and I will give to my chosen to eat from the tree of life and to drink of the rivers of living waters, and you will never hunger or thirst again, and I will wipe all tears away from your eyes.

I, the Lord, have spoken it, and I will make it so. The time is here, so watch for my appearing, as nothing can stop my mighty hand.