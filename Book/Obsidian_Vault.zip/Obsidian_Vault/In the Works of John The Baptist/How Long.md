---
Order: "53"
Date: 2024-03-02
Image: "[[how-long.webp]]"
---
# How Long?
![[how-long.webp]]
[[In the Works of John The Baptist]] | March 2, 2024

The Word of the Lord given by Jesus Christ.

How long, how long, will my people ignore my call? How long will they cleave to their sins? How long will they live in the pleasures of sin? Repent. Repent. Repent! Turn to me with your entire heart. Turn to the Lord your God and to my outstretched arms!

To my Bride: I have given you life, yet your life is hid in me; and when I shall appear, so too shall you appear in the life that I have given you. You have freely received, yet it cost me a great price for your ransom. Will you use my grace as a time to slumber? Or will you use my grace as a time to purify yourselves by virtue of my blood that I shed for you at Calvary? Will you accept my invitation to preach to a dying world and save many of your brethren? Or will you ignore my invitation and instead prefer the pleasures of sin for a closing season?

To all, I say: Return to me with your whole heart; repent with your entire being! Seek my face and accept my forgiveness, as the day of the Lord is at hand, as I have warned my people. I will not be quiet, and I urge you to open your mouths to save those you love and those I will bring to you. Remember your first love, and come to me before the trumpet sounds.