---
Order: "37"
Date: 2024-03-25
Image: "[[have-faith-in-me.webp]]"
---
# Have Faith in Me
![[have-faith-in-me.webp]]
[[In the Works of John The Baptist]] | March 25, 2024

Hear my voice, my children, and have faith in me, the Lord Jesus Christ. I have called you to glory and virtue and to stand before me purified from your ways in my atoning blood, for the blood of the lamb washes all impurities away. You are cleansed in me. Know, my children, that there is no condemnation to them which are in me, that is, in Christ. To be united with me and my purposes is to come into communion with the Father, Yahweh, and me, his son Yeshua. I am the Lord who has called you by name and given you an invitation to eternal life where there will be no more trouble, nor anguish, nor sadness; for I will wipe away all tears from your eyes in my salvation for you. Will I start a work and not finish it? Will the God of heaven and earth leave something undone or default on his promises and word? Have you not read, it is impossible for God to lie? Verily, every promise will come to pass and be fulfilled, so know that your redemption draws near — not a partial redemption, but a full redemption with nothing left undone and nothing incomplete.

All of these things have been fulfilled, and the impossible has happened in me because I defeated death to die no more. Know that every evil work that Satan has tried to build in your lives I will undo. Yea, I will destroy all the works of the Devil; for this purpose was I made manifest. I have given you wholeness, and I will yet heal you to the uttermost from your corrupted bodies, and you will be like me. Check my Word, hear my Words, compare them with Scripture, and know that your full redemption is as close as your next breath and will happen instantly. Stand firm for me; speak for me. Have nothing to do with the idolaters and adulterers who have infiltrated my Church and who would endeavor to lead my little ones astray. My wrath abides on them and on anyone who attacks my people to lead them astray.

For it is impossible that you should be plucked from my hand, and those I have shown mercy to are those who have made me their Lord by confessing my mighty name, Jesus Christ, as Lord. I will not disappoint, and it has not entered into the heart of man the things that are waiting on you, as I will catch you away soon. Do not let evil words trouble your hearts, my children, as you are saved from the wrath of God, and my faithful will not endure the seven-year period of wrath that is about to be unleashed. Let your hearts be at peace and rest in me, even in your tribulation and persecution rest in me, and I will give you indescribable peace. My mercy and grace endures forever, and I have paid the price for your sins, so continue to come out of them. I see the turmoil you endure. I hear all the harsh words spoken to you and about you. Furthermore, I strengthen you in your weakness, and I have given you of my spirit, and you are mighty and powerful in me. In your own strength you will fail, so rest in my strength, for my Father has exalted me above all else.

I will take vengeance on the wicked very soon, my children, so fear not. This vengeance is not for you, and it is not intended for God's children but for his enemies who have wronged mankind and for evil men who murder and plunder their neighbor and brother.

Yea, many evil men have joined Satan for greedy gain, and they have their portion and reward in the lake of fire prepared for the Devil and his angels. Are you not all one race, the human race? Yet, know that great wrath is about to be unleashed and heaven is about to be revealed to the earth. Every deed is recorded. Every idle word spoken has been written down. There is no secret that can be kept from me, and there is nowhere to hide from my gaze. Though the wicked tunnel into the earth to escape my approaching wrath, they will meet their end trying to hide from me.

I will repay, and I will take vengeance and establish justice for the wronged. I have a sharp two-edged sword proceeding from my mouth, and nothing and nobody can stop me, as I am King of Kings and Lord of Lords. Who can separate you from the love of God that is in me? I did not pay for your sins and give you life eternal to unleash wrath and condemnation on you, my faithful. Nothing and nobody can separate us, and soon you will look on my Father and me with your own eyes. Though you have built great trust and faith in me, never having seen me with your own eyes, soon you will see, and you will know as you are known. Who is he that troubles you? Will he not come to nothing and his evil works returned to him double? Evil men have treasured up great wrath, yea, great wrath for abusing my Father's creation, and I will repay, saith the Lord.

Stand before me and continue to separate yourself from this evil, dying world and allow my atoning work to wash over you, cleansing you to the uttermost. Behold! I make all things new, and your sins and iniquities I will remember no more. So come out of your own works and take up my works, for in so doing you will bring wholeness to your own souls. Fear not the wicked! For soon their works will disperse as dust before a great wind, and I will make all things clean and new. There is great reward for my faithful and chosen; and soon, yea, very soon you will reap the rewards for your works if you faint not.

Stand for me to the very end, as he who loses his life in me shall find life and will reap great joy and salvation and rejoicing forevermore before my Father. I have made you kings and priests before my Father, as I am the eternal high priest forever after the order of Melchizedek. Stand firm in my grace and know that very soon the door shall close, just as God shut Noah and his treasures inside the Ark. So too will I assemble you unto myself in the heavens. There is an open door that no man can open or close, and I will receive you to myself, my Bride. So watch for me as time is nearly up.

I am the faithful Lord.

I am the way, the truth, and the life. I am the head of the body.

I am the bridegroom to the bride, and I say come!

I am he who dies no more, for it is impossible that death should hold me.

I am he who has called you to glory, virtue, and truth.

I am the Lord Jesus Christ, the son of God manifest in the flesh who has died for your sins.

I am he that has been resurrected the third day to die no more.

I am he that God has received into the heavens as my apostles and disciples watched me go into the clouds.

I am the eternal high priest forever after the order of Melchizedek.