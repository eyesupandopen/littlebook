---
Order: "36"
Date: 2024-03-28
Image: "[[look-to-me-the-lord-jesus-christ.webp]]"
---
# Look to me, the Lord Jesus Christ!
![[look-to-me-the-lord-jesus-christ.webp]]
[[In the Works of John The Baptist]] | March 28, 2024

My children, open your eyes and look to me, the Lord Jesus Christ. Awake out of sleep and return to me; return to me, for my arms are outstretched to you, my chosen. Soon you will be with me, as the hour is down to the last minute and the times of grace are nearly completed, and I will bring it to full consummation. Awake out of sleep, and I will break the enchantments of this world's spells from your very eyes. Weep and howl over your sins and your refusal to come to me, and know that I am calling you at this last minute. I am calling you back to me, your first love, though you have taken others into your heart.

Run from them all, as they are imposters; yea, wolves in sheep's clothing they are, and you have fallen asleep in their wicked embrace. Slumber not, my children, but awake and watch for me, as my signs are already in the skies and I come as a thief in the night. What will I find when I return for my Church? Will I even find faith? Oh, Laodicean church, you are lukewarm, and I would that you were cold or hot. Turn to me yet again, and I will cleanse you from your sleep, and I will soothe the wounds inflicted on you by the evil ones. I have no desire to spew you out of my mouth, so come yet again to me, and I will receive you. Know that my love for you is undying and is always strong and unchanging.

There is none but me who can save you, none but me who can make you whole and heal you, none but me who can protect you and give you life eternal, none but me who can save you from your sins, because there is no other name given whereby men can be saved. I am your eternal hope who has created you anew in my new birth that I have poured out onto you. Know that you are my Father's children, and you have a mighty inheritance for your faithfulness. Yet, though I will judge your works for reward or loss, you have passed from unrighteousness into life eternal by your faith in me and my eternal Lordship. Behold! I have made you kings and priests before my Father, for I am the high priest forever after the order of Melchizedek.

Who is he that would array himself against you? For to come against my brethren is to come against me, and I will repay, says the great eternal Lord of glory from on high! All things in heaven and earth are given into my hands, so know that I have supreme authority, and no one is greater than me except my Father, who has elevated me above all. So who is he that you should fear him? Doesn't persecution and tribulation cause you to become stronger in me? Is it not so that when your own power fails you, I am right there to strengthen you in your weakness?

So stand strong and be mighty in me! Why do you doubt my words? But instead, have faith in me and speak the words I give you, for these words are mighty and powerful if you will but speak them in faith. Speak in confidence and authority, and command the beggarly elements in the name of Jesus Christ, my mighty name above all. Soon you will see me with your own eyes, and your presence in heaven is greatly desired by me and my Father, yea, even by Yeshua and Yahweh. You are my Father's greatest treasure, and you are priceless. For where else is sinless blood given for your sins except in me?

Oh, you wicked ones who sit and gloat, thinking you have great victory. I will disrupt your plans of evil, and you will be able to accomplish only what my Father has determined you can do in accordance to further his own plans. You are weak and beggarly and utterly defeated. Oh, natural man, why do you yet choose the wicked ways of the wicked ones who wickedly lead you astray? Are the pleasures of sin worth eternal separation from the glory of the eternal God? Where will you find life outside of me? Who will rescue you except the one you still reject? Hasn't my grace and mercy even held back the hand of the enemy?

Anything good you have has descended from the Father of lights, with whom is no variableness nor shadow of turning. But no, you have rejected my grace and used my mercy to revel and bask in your iniquities. Behold! Great destruction shall overtake you. You have been betrayed by your own leaders, who plot your destruction and have allowed the red armies entrance. Destruction and great evil will come on you suddenly, and it will come just as I snatch my bride from the midst of your evil ways. Then sudden destruction will ensnare you, for what fowler sets the snare in the bird's sight? No, a thinly veiled trap is ready to spring, and it will happen as my restrainer is removed, and you will not escape.

Then your hearts will melt within you and your strength will flee as you see with your own eyes the creatures about to be unleashed from the depths of the earth onto you. I will open the abyss, for I even have authority over it; for I have the keys to death and hell, and no one can snatch them from me. Had you only understood that you own nothing on the earth, and all is but a gift of grace and mercy, because the love of God leads men to repentance. But no, you greedily hoard God's goodness to yourselves and slay your neighbor instead of loving them as yourselves, as I have commanded. God so loved the world that he gave his only begotten son, Jesus the Nazarene, to reconcile you to him in love through me.

But in your arrogance and worldly ways, you have hardened your hearts against me and my salvation. Therefore, utter destruction will come upon your nation in one hour, and Mystery Babylon shall be no more. Yea, Babylon the great, your secrets will be yet exposed for all to see, and those who cling to you will suffer the same judgment.

Therefore, oh, God-rejecting man, humble yourself and come to me now! Your hour of need is now. Turn to me; I'm begging you, and I'm calling you by name! Come out from this dying world, for there is salvation in me if you will but accept.

I have no pleasure in your judgment, and my Father desires you to live before him, and in his love he has given his creations a choice: I set before you this day life and death, therefore, choose life that both you and your seed may live! So come to me before it is too late and know that this evil world you cling to will be utterly destroyed, and it will happen through the wrath of the Lamb. Shall God not judge evildoers who have killed his children, who have maimed and abused the innocent, who have killed the only begotten son of God? Though I gave my life willingly for you and no man took my life, there is great judgment and justice to be served by me. For I purchased the earth in my blood and atoning sacrifice, and it is mine. I will set up a kingdom of righteousness and true holiness, where the lion and lamb shall lie down together, where no evil thing shall enter. Therefore, come out your of your sins, as I love you, and I am calling with my last breath before the last grain of sand drops. And it is almost here.

The Spirit and the Bride says, come!

I am calling you at this last minute.

I am calling you back to me.

I am your eternal hope who has created you anew in my new birth that I have poured out onto you.

I am the high priest forever after the order of Melchizedek.

I am right here to strengthen you in your weakness.

I am calling with my last breath before the last grain of sand drops, and it is almost here.

I am that I am, and the Great I AM has sent me.