---
Order: "45"
Date: 2024-03-12
Image: "[[the-faithful-shepherd-says.webp]]"
---
# The Faithful Shepherd Says
![[the-faithful-shepherd-says.webp]]
[[In the Works of John The Baptist]] | March 12, 2024

The faithful shepherd says to the faithful: Verily, verily, I say to you, depart from iniquity and sin not. For my reward is with me to give to every man according to his works. I have called you in the love of my Father that you may have life and have it eternally. I have called you to walk in my Kingdom, to serve me and to dwell on the earth in righteousness. I have given you my grace that you may grow into me, your Lord Jesus Christ. Faint not at my chastisements, for as many as I love, I rebuke, that my saving grace may take root in the depth of your being so that you may do mighty works, works of blessings, works of healing, and that you bear much fruit in me, my people.

For my Father is a loving God, and my Father's love cannot be conquered. In me, the righteous Lord, resides all fullness that the Father has given me. He has given all things into my hands, and as Pharaoh elevated Joseph and gave into his hands all of Egypt, so my Father has elevated me and given all things in heaven and in earth into my hands. He has given me a name above all names, that at the name of Jesus should every knee bow, both on heaven and earth, and every tongue shall confess my Lordship, both in heaven and earth.

I have given you eternal life, and I have made a path for you to escape the wilderness and to escape that approaching great day of wrath, so faint not! Do not grow weary in well doing, yet stand before me, and I will continue to draw you into my presence. You are seated in the heavenlies and will take part in my throne as I take part in my Father's throne. I have many crowns and many blessings that are stored up for you, my faithful people. Stand before me and be perfect in me. Depart from your sins and allow the times of refreshing to blow the chaff from your life. In me is eternal life, and in me is the new creation, the new man, even Christ in you, the hope of Glory! Depart from evil and depart from sin. Continue to declare me among the heathen, as there are still people to save in this final hour. Continue to declare my name, for there is no other name under heaven whereby men may be saved. Take comfort in the rest that I have given you, and lay your burdens at my feet; for my burden is easy, and my yoke is light.

For the faithful (those who have overcome sin and adversity by my atoning blood) to the faithful, I say: I have great reward treasured up for you in my Father's house. Eye has not seen, ear has not heard, and neither has it entered into the hearts of men the things that are prepared for them. I will reward you richly with many crowns, so stand for me and be faithful to my voice and my words; for in those words you will find life. Am I not the Word made flesh who has dwelt among you?

I am the righteous judge.

I am the good shepherd who shepherds the flock.

I am your healing, and I will heal you to the uttermost.

I was born of a woman and made flesh, though no sin is in me.

I was crucified for your sins, and truly, no man took my life, but I willingly laid it down for the love I have for my Father's sons and daughters.

I was raised to life the third day, for it was impossible that death should hold me. My Father broke the bonds of death with the power of my resurrection.

I am the firstfruits of the dead.

Soon you will meet me in the air, and the very pains of death will release those who have fallen asleep, and then you which are alive and remain shall be caught up together, and forevermore will you be with me. I am the Son of God, and in my hand is my reward for my faithful. Stand strong, my children, and faint not. Be strong in the Lord and the power of my might, for only my Father is greater than I. I have heard your petitions, and I have received you as my own.

Be patient and continue to labor for me. For soon you will be home with me, and forevermore we will be about our Father's business. Be strong and be of good cheer. I know that many of you see the tribulation and calamity approaching, and many of you have seen the armies of the wicked one crossing your borders. Fear them not! Fear them not, even though they would destroy you if only they could, but they are not here for my faithful, as the great escape and the great gathering will yet save my faithful ones from the hour of trying and temptation that is about to come on the entire world. Rest in my love, knowing that I will never leave you nor forsake you, just as my Father never left me nor forsook me in my hour of sacrifice. For your salvation is secure in me; therefore, push into me, as I will strengthen you yet even more than I have. Great is the Mystery of godliness!