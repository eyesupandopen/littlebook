---
Order: "11"
Date: 2024-05-23
Image: "[[hear-my-words-and-understand-the-times-in-which-you-live.webp]]"
---
# Hear My Words and Understand the Times in Which You Live!
![[hear-my-words-and-understand-the-times-in-which-you-live.webp]]
[[In The Works of John The Revelator]] | May 23, 2024

Hear my Words, my people, even all whom I am calling, and understand the times in which you live. For the world you now know will cease to exist, and in its place many wastelands will remain, even the ashes and ruins of Mystery Babylon, for war has come. For as I snatch my Bride into the heavens, great calamity will engulf Mystery Babylon, and she shall be destroyed in one hour, and in one hour shall she be destroyed, and nothing can change her fate, for Yahweh has so declared.

For you, Secret Babylon, you have rejected my voice and set me, Jesus Christ the Righteous, aside for the pleasures of sin. For even the great warnings given over your nation in the heavens served only to provide entertainment for your faithless hearts and lustful eyes, and to you it was just another day as you lived deliciously in your sins that are leading you to your destruction. You should have repented!

For you have become a nation of idolaters, a nation of warmongers, a nation who feasts on lies and who loves their delusions, a nation who has filled the earth with your abominations; and the nations drink of your golden cup which is full of abominations and filthiness of your fornication.

Therefore, I am against you, and your destruction is here and has already begun, for you have ignored the call of Yahweh given through me, Yeshua HaMashiach, and I would have saved you. And I have wept over your hard-hearted ways, but you still will not turn from evil; so I have turned away from you, and the times of the Gentiles are about to be brought to full completion as I catch away the faithful in my Church at the trumpet's call.

But you are a nation bound in chains, and you will utterly be destroyed, and you will never rise again. As my Bride is taken, the world will wonder in great astonishment at what they witnessed, for this event will not happen in secret, but openly, that all the world may know that there is a God in heaven and that he has sent me, Christ Jesus, for the gold, silver, and precious stones of the earth. For the Father's greatest treasures, even the pearls of great price, will be taken away from the judgment and destruction to come.

For my Bride is saved from wrath on account of my sacrifice, and I will rescue the faithful and those found faithful in Christ at the time of my appearing and all who have died faithful in Christ, even sealed by me, Christ Jesus, for I have been made a life-giving spirit. And I will resurrect the dead in Christ, and those which are alive and remain shall be caught up together with them to meet me in the clouds. So understand that this event is to reward the faithful and to consummate the marriage of the Bridegroom to my Bride, for we will be forever joined in covenant and never will they depart from me. And I am he who will make them kings and priests before my Father.

And so they will leave the earth, and so the world will see, and many will wonder in great astonishment. For in part, the reason for this event is to engender repentance among those who are left behind, even those who refused my call during the age of grace, and also many who have not heard enough to believe who will be saved during Jacob's trouble, especially those of the land of promise.

For I am calling you, oh, Israel: are you ready to hear the voice of your true Messiah, the Lion of the Tribe of Judah? For the voice of your true Messiah is calling, and I am he who will rule from the throne of David in the holy city, even I, Yeshua HaMashiach; only ignore not the words of my call! And so the age of grace, even the times of refreshing, are now closing out in finality. And so that finality will fully arrive when I gather the faithful of my Church to me in the clouds and when their departing shakes the entire world.

It will literally shake the earth, and great shaking will consume Secret Babylon, and she will be rent up the middle as my saints depart. She will be utterly burned with fire from the sky as the missiles will fall. Her skirts will be covered with waters from the east and from the west! For a mighty angel will take up a stone like a great millstone, and cast it into the sea, saying, Thus with violence shall that great city Babylon be thrown down, and shall be found no more at all. For thus is it written and thus shall it be done!

For great is her judgment, and judgment has begun at the house of God. Her apostate churches will be destroyed, for I have judged them all that are not of me, even all the fake churches who speak great lies in hypocrisy. Mystery Babylon, oh, that you had turned to me, Jesus Christ, from your evil ways, for I would have saved you, and neither me nor Yahweh have any pleasure in the judgments that are about to be unleashed.

But nevertheless, judgments will fall as pronounced, and that judgment will be severe and everlasting. For I had turned to the Gentiles for a season, and now I will turn away from the Gentiles and will turn to the flock of which I arose, even Israel. Though whosoever calls on the name of the Lord to the end will be saved, whether Judean or Gentile, for salvation is not bound by international borders.

Oh, Secret Babylon, your bridges will fall; your roads will be overturned, broken, and unpassable; your supply chains are already crumbling and will soon be desolate. No provisions will be delivered to you, for nobody will come to your aid, and you will be alone in your hour of desolation, oh, great harlot. You will have no happiness, and those who survive will find themselves fighting just to have a drink of water. Starvation will overtake the land. And great pestilence will overtake you, and even the animals will attack, for the times are here.

The red armies that your treasonous government allowed into your borders will slay every man, woman, and child who does not fit their purposes. For they will kill and enslave all they find. They are the armies of the beast that have been gathered from the four corners of the earth for this purpose, and the concealed beast and concealed false prophet have gathered them.

They have no sympathy, no mercy, no grace, no remorse, and they utterly hate the inhabitants of Mystery Babylon for the awful sins your leaders have perpetrated on their lands. And all the while so many of you cheered on your unjust wars as you watched in amusement on your televisions, as you took great pleasure in the sins of your leaders.

You have given your consent to your leaders whose sins you endorsed by vote, and so you will share in their judgment, for you have made yourselves worthy of a double portion of judgment, and it will overtake you suddenly.

And so my Bride will appear at my judgment seat, and some will suffer loss, some will carry away great reward, and all will receive fully of the down payment they have already received: For I will give them new, sinless bodies that will never corrupt! And so the seals will be loosed, for though tribulation and anguish have abounded on the earth for many years now, they are not the wrath of God nor the wrath of the lamb.

So many of you foolishly think you have to endure the wrath of God, arrogantly thinking you are able to bear what is coming. Understand that I have saved my Church from wrath, for I came to my own and to the Gentiles during the age of grace as a peace treaty, offering peace and reconciliation to the Father of Lights, even El Shaddai! And those whom I have saved have by their free will accepted my unmerited favor, so follow their example!

And I will seal my 144,000 from the following tribes, even 12,000 from each of the following: Judah, Reuben, Gad, Asher, Nephthali, Manasses, Simeon, Levi, Issachar, Zebulon, Joseph, and Benjamin. So hear my voice!

And you will do many mighty works for me, and you will lead many to salvation out of a dying and violent world. For Satan already has prepared a great deception and will do his best to lie, cover, and hide the great gathering in the clouds that is about to happen. His lies are already rooted in your minds and hearts through your Jesuit educations that deny my Father and are brought to you by the fallen ones. They have made spurious all things, even leading many of you to believe that above the earth is an endless void of planets and other life, and many will be so naive as to swallow these lies. Even those whose names have never been entered into the Book of Life, for they will accept their mark.

Know, my people, and hear my warning. There is no life on other planets! Study to learn, for planets are wandering stars ordained to declare the handiwork of Yahweh in the expanse under the firmament. These will not be aliens from other falsely rotating worlds; however, they are not of the earth, for they are fallen angels who are of the heavens, and many abominations have they made for themselves. Believe them not!

So from the ashes of the horseman and out of great destruction will the beast and false prophet arise, for the mystery of iniquity is already at work. For Mystery Babylon is given into their hands and the confederation that is forming, even the ten horns will destroy her, for they are ten kings who give their all to the dragon, beast, and false prophet. For once the restrainer is removed, they will fully rise according to Scripture; for out of chaos rises their new order, even the order of the Dragon, for he is their power and authority, for so has been given him in a limited way for a very short time.

The dragon has great wrath and will move in the spirit of Haman to make all things of Christ illegal, and anyone who is associated with my name, even Jesus Christ, will be hunted and killed. And those who love not their lives to the end will be saved and have great reward. So keep your mind and heart on the joy set before you, for in such manner I secured your salvation in the agonizing torment that was yours, except I willingly took your punishment and paid fully for the sins of mankind once and for all, even for all time.

The beast will move swiftly, for he will continue for 42 months speaking great blasphemous things. He will make war with the saints, and it is given to overcome them. He will behead many. He will do many lying signs and wonders, and out of the ashes will arise his new order. And the false prophet will point to him and praise him and cause all to worship his image, for these things are recorded plainly in Scripture. And so the beast will purge the earth of anything good, holy, and precious. Yet, I will hide my faithful, and many miracles will they do, and many will be saved.

But the false prophet, even the beast from the earth, will cause all, both small and great, rich and poor, free and bond, to receive a mark in their right hand or in their foreheads: And that no man might buy or sell, save he that had the mark, or the name of the beast, or the number of his name. So understand that to participate in their new false society of lies will require the mark, and all who take the mark never have forgiveness. And they will have their part in that great lake which burns with fire and brimstone forever and ever, and so will the smoke of their torment rise.

My two witnesses will rise, and they shall prophesy clothed in sackcloth! These are the two olive trees, and the two candlesticks standing before the God of the earth. And none will be able to stand against them, for they will prophesy for 42 months. And if any man will hurt them, fire proceeded out of their mouth, and devoured their enemies: and if any man will hurt them, he must in this manner be killed. These have power to shut heaven, that it rain not in the days of their prophecy: and have power over waters to turn them to blood, and to smite the earth with all plagues, as often as they will.

And when they shall have finished their testimony, the beast that ascends out of the bottomless pit shall make war against them, and shall overcome them, and kill them. And they will leave their bodies in the streets for three and a half days, and the entire world will rejoice, and then they will be resurrected and caught away to the heavens.

The false prophet has already ingratiated himself to those in the land to think he is their Messiah and king. He is a fake temple builder and comes from the tribe of Dan, and he is no Cyrus. He will give all support to the first beast who rises out of the sea. For the first beast will brutally enforce Noahide on the nations in great lawlessness, and the false prophet will reign in the throne that is not his, for it is mine, even Yeshua HaMashiach's. And so the temple will be built, and the false prophet will do many lying signs and wonders, for he is empowered the same as the first beast, and so the two will work with one mind and one purpose, even with the mind and purposes of that great lying dragon, but he is worthless and toothless, so fear him not!

For he knows that I am coming to destroy his kingdom, for he is no king but an utterly defeated enemy, who has absolutely no hope. So fear him not and stay single-minded on me. For behold, I tell you these things before they happen that you may have faith in me and have faith in my Father who has sent me, even Yahweh the great eternal God, and even me his son, Yeshua HaMashiach, who will fulfill the promises made to the fathers.

And so at the end of the first 42 months the abomination of desolation will take place at the hand of the false prophet, even the beast to rise from the earth. During the second 42 months, even during that time will the greatest tribulation ever occur and the abomination of desolation, and he will declare himself God! Many will be crushed and many shall perish, but those who are obedient to my voice will be taken to a place in the wilderness where they will be hidden away and kept safe for a season, as these will be the most brutal times, and these times of trials and testing will be the most severe. Then you will see the heavens opened, and you will see me, Jesus Christ, lead out from the heavens that great and mighty heavenly host, and it will be an army like no other, ever! For my Bride will be with me. And I will crush the beast and the false prophet and all their armies and all their abominations that they have abominably made, and so will they be destroyed even by the brightness of my coming and by that sharp double-edged sword proceeding from my mouth, and they shall not stand but will be utterly destroyed. And the beast and the false prophet will be cast alive into that burning lake of fire and brimstone, and never will they be released from their torment, for they have made themselves worthy.

And then will the resurrection of the just occur, when the saints of old and the tribulation saints will be raised from the dead to newness of life, and they will die no more, and I will bestow great reward on them, of such that has not even entered into the hearts of men at this time. For I am a merciful Lord and a merciful King, and I am the fullness of the Godhead bodily.

And so my thousand-year rule on earth will begin, and righteousness will rule on earth, and I will rule the nations with a rod of iron, and the earth will abound with the ways of Yahweh. For I am coming with a multitude of kings and priests, and they will rule in my throne, and they will rule in righteousness. And the lion will lie down with the lamb.

I am calling you to understand the times in which you live.

I am a life-giving spirit, for so have I been made.

I am he who will make them kings and priests before my Father.

I am calling you, oh Israel.

I am coming to destroy Satan's kingdom, for he is no king.

I am a merciful Lord and a merciful King.

I am the fullness of the Godhead bodily.

I am coming with a multitude of kings and priests, and they will rule from my throne, and they will rule in righteousness.

I am calling you; only ignore not my call!