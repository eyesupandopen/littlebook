---
Order: "8"
Date: 2024-06-01
Image: "[[to-the-144000-for-just-such-a-time-you-have-been-called-and-sealed.webp]]"
---
# To the 144,000: For Just Such a Time You Have Been Called and Sealed
![[to-the-144000-for-just-such-a-time-you-have-been-called-and-sealed.webp]]
[[In The Works of John The Revelator]] | June 1, 2024

Stand for me and follow my example, for what says Hebrews regarding my stand for Yahweh? Who for the joy that was set before him, endured the cross, and despised the shame, and is set at the right hand of the throne of God. So in my love for the Father, which is unbreakable, and in my obedience out of love, and in my love for mankind and my desire to sacrifice myself to save you, I endured terrible punishment, agony, and suffering and I did it willingly, with joy in my heart. I knew that by my sacrifice and death, many would be made righteous and alive by the power of my resurrection because Yahweh himself raised me from the dead, for it is impossible that death should hold me. And by that same power, so too will you be raised to newness of life, for I have paid the price by offering my sinless blood as a ransom for all who will believe on my name, and whosoever calls on the name of the Lord will be saved, who love not their lives to the end!

And so now I ask you, my faithful and chosen, even my kinsmen, to stand for me and do not withdraw yourselves. For I plainly stated in my treatise to the Hebrews: Now the just shall live by faith: but if any withdraw himself, my soul shall have no pleasure in him.

Let that sink in, and read it again, and do not withdraw to Torah, for Torah is kept by faith in me; therefore, the just shall live by faith. You are identified with me, and I am he who has justified you in my atoning works and by my sinless blood.

So very many of you struggle with the concept that I took your place in condemnation on the tree for sins that I didn't commit, and I did so willingly and joyfully to bring salvation to corrupted natural man, that I may redeem them to Yahweh, even your God and your Father, even the Father of Lights with whom is no variableness nor shadow of turning. For Yahweh changes not; he is the same yesterday, today, and forevermore!

He is the same God on whom your fathers agreed in covenant, even at Mount Sinai when Moses received the law from Yahweh himself. And even though the law is holy, and the commandment holy, and just, and good, mankind could never live up to its standards because the law was given to convict sin in the flesh, and you are all born dead in trespasses and sins because sin is in your flesh. Torah was not given for the righteous but for the unrighteous, that sin may appear sin in the flesh. Torah was given as your schoolmaster to bring you to me, even Christ Jesus, the ascended Lord of Lords and King of Kings!

And so I willingly took the consequences of sin on myself, for so was I born to redeem mankind from the curse of the law. For the law was not cursed; yea, let the law stand and every man be accursed who curses the law of Moses, for I did not come to abolish the law, but to establish the law and even exceed the law of Moses. Blasphemy you say?

The witness of the Hebrews stands in mediation between us: For if the blood of bulls and of goats, and the ashes of an heifer sprinkling the unclean, sanctifies to the purifying of the flesh: How much more shall the blood of Christ, who through the eternal Spirit offered himself without spot to God, purge your conscience from dead works to serve the living God?

Since you love Moses (as I do), I counsel you to lovingly obey Moses’ instructions; for he said: Yahweh your Elohim will raise up unto you a Prophet from the midst of you, of your brethren, like unto me; to him, you will listen. So hear the voice of Yeshua HaMashiach! You are purged of sin and all sins you commit by my sinless atoning blood that I offered to Yahweh as a ransom for your lives, and I have even redeemed you from the hand of the enemy. Sin not! And if any man sin, confess your sins to me, for I am he who cleanses you in my atoning blood.

I didn't atone for your sins and their inherent consequences with a scapegoat, nor did I offer a lamb of the first year; for I am the Lamb of God of the first year, and I am he who offered himself without spot and without blemish, even holy, pure, and consecrated to Yahweh himself (even my Father) for your sins once and for all, even for all time. I atoned for your sins in my sinless blood; therefore, there remains no more sacrifice for sin. And to reject me, Yeshua HaMashiach, even Yahweh's perfect peace treaty to mankind, is to reject Yahweh and join Satan's rebellion, because Satan rebels from God's order from the beginning.

For I told the Hebrews: For if we sin willfully after that we have received the knowledge of the truth, there remains no more sacrifice for sins. So to sin willfully by rejecting my atoning blood, and thereby rejecting the peace treaty sent by Yahweh, is especially grievous, and there is no more sacrifice. For it is written in Hebrews: He that despised Moses' law died without mercy under two or three witnesses: Of how much sorer punishment, suppose you, shall he be thought worthy, who hath trodden under foot the Son of God, and hath counted the blood of the covenant, wherewith he was sanctified, an unholy thing, and hath done despite unto the Spirit of grace?

So I encourage you all to accept my sacrifice and understand that no more sacrifices are necessary and there is but one true Messiah, even me, Yeshua HaMashiach. And it is written of me: But this man, after he had offered one sacrifice for sins forever, sat down on the right hand of God; From henceforth expecting till his enemies be made his footstool. For by one offering he hath perfected forever them that are sanctified.

So understand that I have cleansed you in all respects and aspects pertaining to sin and its consequences. You are sanctified in me; you are justified in me; you are made the righteousness of God in me; and I have fully redeemed you to myself, even I, Yeshua HaMashiach, whom Yahweh has sent as your Messiah. And so understand that there are no more Levitical High Priests, and the Priesthood of Aaron has come and gone, for it was a shadow of things to come. For I am your high priest forever after the order of Melchizedek.

Because the law made nothing perfect: but was an introduction of a better hope, by which hope we draw near to Yahweh. And again: Such an High Priest it became us to have which is holy, harmless, undefiled, separate from sinners, and made higher than heaven. And again: For the law makes men priests, which have infirmity: but the word of the oath that came since the law, makes the son priest, which is perfect forevermore. Have you not read what scripture states concerning me? Yahweh swore and will not repent: You are a Priest forever after the order of Melchizedek.

Understand that there is nothing lacking in my sacrifice, and you are secure in me, Christ Jesus. Torah is kept by faith in me, Yeshua HaMashiach, and it is impossible for you to violate any of the laws of God by walking in me, Christ Jesus. For you walk in the law of the Spirit of life, and I have made you free from the law of sin and death. So have faith in me, for the just shall live by faith. I have many mighty works that I have called you to, and you will help bring salvation to many. There is great hope and reward laid up for you in the heavens for your stand and your faithfulness.

For I send you forth, sealed in your foreheads with the seal of Yahweh himself, into a world that will utterly hate you, and no marvel, for the world utterly hated me first, and the servant is not above his master. You are my witnesses and prophets and my healers and my providers. I send you into the darkest darkness ever to overshadow Yahweh's creation. For such a time as this you have been called, chosen, and sealed, and these times will be the most perverse and evil the world has ever seen, even worse than the days of Noah. Into their midst I send you, and I tell you to fear not! Fear not their threats; fear not what man can do to you; fear not their faces; fear not the spirits that empower them; fear not the beast and false prophet; and fear not Satan himself: Even that great dragon. For you will trample on every aspect of Satan's kingdom, and nothing shall by any means stop you if you stay faithful to my voice and let me direct you step by step. For of a truth, you are fellow workers with me in this time of Jacob's trouble, and I have empowered you.

You are mighty and powerful, and I send you forth in meekness and humility. I send you forth to keep the law by your faith in me, and so love Yahweh with all your heart, soul, mind, and strength, and love your neighbor as yourself. Who is your neighbor? All those in need of your help to whom I am sending you, and I am not restraining you by national boundary. Go forth and shepherd my flock, for I am the Chief Shepherd who has your reward in my hand for faithfulness. Go tend to my flock, tend to their wounds, feed them, heal them, lead them, and above all bring them to me; for of yourselves you are nothing, but in me, you are my powerful, mighty men of God. Teach them to call on my name till the end, for whosever does will be saved.

Keep your eyes on the prize and the joy that is set before you, and press forward toward the mark for the prize of the high calling of God in Christ Jesus. For your reward will be great, and you will be astounded at what is laid up for you in the heavens. And my reward is not temporal but eternal, and your rewards will not perish but serve as an everlasting inheritance in fulfillment of the promises Yahweh made to the fathers; every yod or a thorn of a yod will be fulfilled. You will not realize the magnitude of your labors until that day of reward, but Scripture is clear as to the fruit of your labors.

For John the Revelator faithfully wrote what I showed him: After these things I beheld, and lo a great multitude, which no man could number, of all nations and kindred, and people, and tongues, stood before the throne, and before the Lamb, clothed with long white robes, and palms in their hands. And they cried with a loud voice, saying, Salvation comes of our God, that sits upon the throne, and of the Lamb. For a great multitude will you help save and minister, and great will be your rewards of faithfulness.

And you will follow me wherever I go, and you are the first fruits bought from men, and you will sing a new song before the throne that only you can learn. You will also reign with me in my Kingdom a thousand years and will ever be with me in eternity. For yours is an eternal joy, for you will be with me in my Kingdom on earth as I rule the earth in righteousness from the throne of David, and my Kingdom has no end. And no evil thing will enter, and there will be no more trouble, and mine is a kingdom of righteousness where the lamb and the lion will lie down together in peace. And at the end of my thousand-year reign, Satan will be loosed a little season to gather his final attack, and fire will come down from Yahweh and utterly destroy them. Satan will be cast into the lake of fire, never to rise again, and Yahweh will create a new heaven and a new earth, and he will make his dwelling amongst men, and so you will dwell in New Jerusalem, even that holy city created by Yahweh himself. And Yahweh himself has stated: He that overcometh shall inherit all things; and I will be his God, and he shall be my son.

I am he who sends my Angel to seal 12,000 from the tribe of Judah.

I am he who sends my Angel to seal 12,000 from the tribe of Reuben.

I am he who sends my Angel to seal 12,000 from the tribe of Gad.

I am he who sends my Angel to seal 12,000 from the tribe of Asher.

I am he who sends my Angel to seal 12,000 from the tribe of Naphtali.

I am he who sends my Angel to seal 12,000 from the tribe of Manassas.

I am he who sends my Angel to seal 12,000 from the tribe of Simeon.

I am he who sends my Angel to seal 12,000 from the tribe of Levi.

I am he who sends my Angel to seal 12,000 from the tribe of Issachar.

I am he who sends my Angel to seal 12,000 from the tribe of Zebulon.

I am he who sends my Angel to seal 12,000 from the tribe of Joseph.

I am he who sends my Angel to seal 12,000 from the tribe Benjamin.

For to you, my 144,000, it is given to stand on mount Zion having my Father's Name written in your foreheads.