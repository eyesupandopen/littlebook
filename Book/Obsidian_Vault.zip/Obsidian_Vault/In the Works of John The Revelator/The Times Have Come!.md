---
Order: "13"
Date: 2024-05-16
Thunder: Thunder 3 & 4
Image: "[[the-times-have-come.webp]]"
---
# The Times Have Come!
![[the-times-have-come.webp]]
[[In The Works of John The Revelator]] | May 16, 2024
### [ Thunders 3 & 4 ]

#### From Yeshua HaMashiach:

Behold! The times of separation draw to a close, and my appearing has almost arrived now. It is very close and even the angels and host of heaven are at the trumpet's call. I have reached my outstretched arms to a dying world for many jubilees now, and many have accepted the peace treaty that my Father, Yahweh, sent to mankind, even me, Christ Jesus, for I am your peace. Yet many more have rejected my offer and my Father's grace and mercy that has been poured out on the earth.

Those who have been sealed and redeemed are those chosen from the foundation of the world. For my Father knew you from eternity to eternity, and you have always been at the center of his heart, as I have also been in the center of his heart, for I, Jesus the Nazarene, am Yahweh's only begotten son. And yet by my accomplished works as the perfect Passover and by the obedience of the only begotten, many, many sons of God have been born again into all eternity, even taken from the sons of men, for I am the Son of Man!

These times of grace were a mystery hidden in Yahweh's heart that he told nobody until he revealed it to me, and I have revealed it to my holy apostles and prophets and have preserved my holy Word for the ears and hearts of the chosen and faithful. For you, my Bride, are part of the great mystery of God, and your lives (which are hidden in me) are about to be revealed. And I will reward the faithful for all their faithful works that they have faithfully done in great faith to me, Jesus Christ.

And so have I saved great multitudes by my atoning blood, for my blood was sinless and to this day I am sinless, for I will never sin. Those who have lived their lives faithfully in Christ will receive great reward, and they will shine as the stars in heaven, and great glory is theirs to be had, for they did not glorify themselves as if they were some great ones. But they have glorified me, Yeshua HaMashiach, and I will present them to my Father without stain or wrinkle, and their garments will be snow white and never will they be soiled. And they shall all live and never again sin, either through ungodliness or through pride. And they will be glorified in me.

For I am the chief shepherd, and I have led my flock to green pastures until the times of consummation, which are quickly coming upon the earth, for there is no more sand remaining to pass through the glass. And I will reward all, from the least to the greatest, in such a manner that you cannot comprehend at this time; but that comprehension is at your doorstep, for you will be taken into the heavens so very soon. And so shall my Bride be taken into glory, where I will judge her works and fully redeem every last man, woman, and child. I will reward them richly for even the smallest things that have been accomplished in service to me. For God is not unrighteous, to forget your work and labor of love, which ye have shown toward his Name, in that you have ministered to the Saints, and do minister.

Fear not, my Bride, for God does not judge as man judges, for man is unjust and a respecter of persons. Man glorifies those whom man deems important, and natural man most always ignores humility and virtue in favor of the haughty and self-accomplished. For natural man cries out to be accounted righteous before God, but natural man cannot overcome his sin nature and refuses to believe that he is corrupt, even denying the Lord of Lords, who would save him.

And so pride goes before destruction, and a haughty spirit before a fall. Instead of bowing their hearts to my words and wisdom and love that I have flooded on the earth, natural man instead chooses to follow his lusts and passions, for the courses of the world are designed by Satan to tempt and incite those passions, even the rewards of unrighteousness. And so the times of the Gentiles are coming to a close, and it is time for Jacob's trouble; for I will redeem Israel, even my faithful elect, who will come to me in repentance for their sins and the sins of their fathers who rejected me. And as it has been written, so let it be done.

Oh, natural man, why do you yet choose your sins and ignore my grace and salvation as if that is a light thing? Neither Yahweh nor I, Christ Jesus, have any pleasure in the coming judgments and the utter terror that will soon be unleashed. But God has not chosen this part of his plan so that he could be cruel to his creation: for God is love, and God is light, and in him is no darkness at all. The coming great trouble is designed to give mankind one last chance before it is too late for him. A great multitude will be saved out of the tribulation, even those who hold my name to their last breath and love not their lives to the end.

Natural man, you are so stubborn, and you will not listen, and you foolishly reject my grace, and I still pray the same: Father, forgive them, for they know not what they do. For those who are left to great trouble, even those who have rejected my offer of peace, many will be lost to destruction, for they have rejected the Lord Jesus Christ. Yet, many will be saved, even all that call on the name of the Lord will be saved. And so yet the trials of fire are about to begin, for judgment approaches.

Great judgment is coming on Satan's kingdom! And you, natural man, even in your stubborn unbelief, refuse even the easiest request. For in my times of grace, salvation has been free and easy, and all one had to do was confess Jesus as Lord and believe God raised me from the dead. And so now there will be a famine of all things good in the land, even my Holy Word. A great, great time of trouble is approaching, and Satan foolishly prepares to make his stand, even arrogantly thinking he can win so that he and his angels can have a world of their own, a world without God, because their ways are perverse. Verily, that which has made itself crooked cannot be made straight, and there is no forgiveness nor peace to Satan and his angels, nor their offspring.

I am the son of God who has come in the flesh.

I am the Lion of the Tribe of Judah.

I am he who will rule the nations with a rod of iron.

I am he who will unleash the seals so very soon.

I am he who is coming for my Bride.

I am he who shall meet you in the air.

I am that I am, and the trumpet is about to sound.

I, Yeshua HaMashiach, have sent these Words.

#### From Yahweh, the Great Eternal God:

Now comes the judgment of the eternal God, even Yahweh, for I am sending my Son, and there is no time remaining. Oh, you worthless ones who thought you could defeat Yahweh, even the great eternal God! Oh, you worthless ones who foolishly thought you could defeat my only begotten Son, Yeshua HaMashiach. You have heaped to yourselves eternal wrath, and my anger is fierce against you, for I am a jealous God. For from the beginning you have withstood my plans, and you have vexed, distressed, persecuted, tortured, and destroyed my creation. You have no peace.

Hear me and hear me well, for I declare what will become of you, and what Yahweh declares can no one alter, not once, not ever. And so your judgment comes. I will send my Son to gather my chosen and faithful, even the sons of Adam who have now become sons of God. You have failed, oh, you worthless serpent, who slithers in dishonesty and falsehood. For you are no gods, and you cannot ever deliver yourselves from my hand. For I will repay!

I will return to you every evil work and all the pain and suffering you have caused the innocent, and you will burn forever in the hottest flames of blue, and acrid poisonous smoke shall be your air, and in great torment will you forever be. For you caused me to destroy my creation, even the earth as it was before the flood of Noah, even on account of your worthless seed that you made for mankind's destruction; and so on account of these things, I will destroy you in your inheritance of fire.

And you tried to destroy the world after the flood of Noah, even making your abominations once again, but they will have no root nor branch; for all the tares will be plucked up, bound, and cast into the fire. And so will I destroy the earth in fiery judgment, for I promised never to flood the entire earth again. But in fire my judgment comes, for I am an all-consuming fire, and my anger boils over at the wicked. And so on account of these things, I will destroy you in the hottest fire and burning brimstone.

Hear me and hear me well, for I declare what will become of you, even you worthless watchers who left your first estate. You have no peace, and though I have unleashed you from your bonds for a short season, I have only done so in order that you may serve my purposes. Then great judgment is on you, and you have no peace. For you caused me to flood the earth on account of your abominations. Who are you to play creator with Yahweh's creation? Who are you to desecrate the garden of God with your unclean ways? You made your bastards and reprobates by defiling yourselves with women, and they will share in your inheritance of fire. For what did I tell Malachi: For behold, the day comes that shall burn as an oven, and all the proud, yea, and all that do wickedly, shall be stubble, and the day that comes, shall burn them up, says the Lord of Hosts, and shall leave them neither root nor branch. Behold that day surely approaches, and all of you will pay according to your own evil ways.

For I have given men wives that they may be lacking nothing, wives for companionship and to bear them children. But you descended on Mount Hermon, even leaving your first estate of glory, and you have defiled yourselves with women, and you have no peace nor rest. As I had Enoch the scribe tell you in the age of your offense: You have no peace: a severe sentence has gone forth against thee to put thee in bonds: And thou shalt not have toleration nor request granted to you, because of the unrighteousness which thou hast taught, and because of all the works of godlessness and unrighteousness and sin which thou hast shown to men. And in bonds you shall go as you are cast into the lake of fire.

You harmed my creation for your own lusts, even forcefully taking many you chose as your wives, and you will pay. You have joined the Satans, even the princes who arrayed themselves against me, and you chose the lies of the seraphim. Therefore, you will join them in the great eternal lake of fire, and you will forever burn, and never will you have rest. You have hurt my creation and killed so many, and you have no regard for the lives I have created. Therefore, I will have no regard for you, and I have created you, and now comes your judgment and eventual destruction.

I say to the Satans, the watchers, the fallen cherubim, the fallen seraphim, even all who have joined the Satans' rebellion: you will utterly burn, over and over again for all eternity; for I will bind you and cast you into the fire where your worm dies not, even the flames reserved for you worthless ones that will burn the hottest flames just for you, for you are worthy. For I will do to you exactly what you have done to others. All the pain, sadness, regret, suffering, even every detestable act will be recompensed to you for all time, and you will not escape. I will lay you bare before the nations and expose you for the frauds you are, and they will say to the little gods (who are no gods): Art thou also become weak as we? Are thou become like unto us?

I will utterly recompense your evil ways back into your own bosoms, and you will forever pay. You will be cast alive into the flames, and you will burn in the presence of the Lamb, and the angels and all the righteous ones you have wronged will receive from me a multitude over what you took from them. For when you are recompensed of your evil, I will have recompensed my chosen and faithful children with great reward that will exceed what you have taken a multitude over and above your worthless actions.

And so shall it be. I will create a new heaven and a new earth wherein dwells righteousness, and my children will live with me, and I will make my dwelling among men, and so shall it be. But you will burn in your evil ways, and every evil thing you have done will be returned to you for eternity. And so I will set the seal, and you will be forgotten, and you will not come to mind. And all shall dwell in peace, and you will never have peace.

Behold, time is up, and I am sending my Son for his Bride, even Jesus Christ the Righteous! For in him I am well pleased! And all that he has saved and made whole from your worthless ways, even those you have accused unjustly, will rest in me and have perfect peace, joy, and love. For I will make you as them and make them more glorious than you once were, and you have no kingdom, for you are no king.

Woe to the inhabitants of the earth, for great wrath is on you. For you have rejected your creator and you love death. For to reject me is to love death, and in dying you shall die. My wrath is hot against you, and I will take all pleasures away, all joy, even your basic needs will go unmet. For when I showered you in grace and mercy, you chose instead to use grace as an occasion to join the worthless ones, even Satan's kingdom, when you could have escaped. And so now many will perish, whose names were never written in the Book of Life from the beginning. My Son, Jesus Christ, is approaching, and he will snatch his bride into the heavens, and I will remove the restrainer. Behold! I send giants to fulfill my wrath! You took my grace and mercy in vain and have lived lives of sinful pleasure, and I will repay.

For when you could have had peace for all eternity, even an eternal life of full joy and happiness, you chose your own deaths, and I will give you what you desire. You want a world of evil and darkness; I will give you exactly what you desire, and I will also recompense you for all the pain you caused others as you lived in great sin. I will strip from you all pleasure, and you will eat of the filth of your ways. Great judgment is on the earth, and there will be no more delay.

Behold! All who call on the name of the Lord shall be saved. For a great multitude will be saved from the tribulation that is coming, and I will receive them to myself. For it is written: These are they which came out of great tribulation, and have washed their robes, and made them white in the blood of the Lamb. Therefore are they before the throne of God, and serve him day and night in his Temple: and he that sits on the Throne shall dwell among them. They shall hunger no more, neither thirst any more, neither shall the sun light on them, nor any heat. For the Lamb which is in the midst of the throne, shall feed them, and shall lead them unto living fountains of waters: and God shall wipe away all tears from their eyes.

I urge you all to call on the name of Jesus Christ, the true Messiah, even the only begotten son of God, for he is coming. and the wrath of the Lamb and the wrath of Yahweh are about to be unleashed.

I am Yahweh, the great eternal God.

I am El Shaddai, God Almighty.

I am Jehovah Jireh.

I am the great Elohim, the God of Israel.

I am he that sent his only begotten son to redeem those who would be redeemed.

I am he that has raised Christ Jesus from the dead and given him a name above every name, that every knee should bow and every tongue will confess.

I AM the Great I AM, and my wrath is soon to be fulfilled, and there is none greater, and I have spoken.

I, Yahweh, the great eternal God, have sent the words I have sent, and I have sent these words. I have sent my son, Yeshua HaMashiach, and he has sent his words to the faithful. Time is up.